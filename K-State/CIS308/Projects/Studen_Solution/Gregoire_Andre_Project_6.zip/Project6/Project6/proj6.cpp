/**********************************************
* Name: (Andy Gregoire) *
* Date: (April 15)
*
* Assignment: Project6
: Four Square Cipher
**********************************************/
#include <iostream>
#include <algorithm>
#include "cipher.h"
using namespace std;

int main()
{
	string key1, key2, s1;
	char c;
	//First key
	cout << "Enter First Key: ";
	getline(cin, key1);
	transform(key1.begin(), key1.end(),key1.begin(), ::toupper);

	//Second Key
	cout << "Enter Second Key: ";
	getline(cin, key2);
	transform(key2.begin(), key2.end(),key2.begin(), ::toupper);
	
	//Operation
		cipher *a = new cipher(key1, key2);
		while(true){
			cout<<endl<<"Enter (e)ncrypt or (d)ecrypt: ";
			cin >> c;
			cin.ignore();
			if(c == 'e'){
				cout<<endl<<endl<<"Enter the message to encrypt (no Q's): ";
				getline(cin, s1);
				s1.erase( remove( s1.begin(), s1.end(), ' ' ), s1.end() );
				transform(s1.begin(), s1.end(),s1.begin(), ::toupper);
				if(s1.length()%2 !=0 || !s1.find("Q")){ cout << "Error, make sure there is no 'Q' and there is an even number of letters.\n"; break; }
				cout <<endl<<"Encrypted message: "<< a->encrypt(s1)<<endl;
				break;
			}//end if
			else if(c == 'd'){
				cout<<endl<<endl<<"Enter the message to decrypte (no Q's): ";
				getline(cin, s1);
				s1.erase( remove( s1.begin(), s1.end(), ' ' ), s1.end() );
				transform(s1.begin(), s1.end(),s1.begin(), ::toupper);
				if(s1.length()%2 !=0 || !s1.find("Q")){ cout << "Error, make sure there is no 'Q' and there is an even number of letters.\n";break;}
				cout <<endl<<"Decrypted message: "<<a->decrypt(s1)<<endl;
				break;
			}//end inner else
		}//end while
		delete a;//calls destructors for cipher/square
		system("pause");
}//end main