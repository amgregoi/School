/**********************************************
* Name: (Andy Gregoire) *
* Date: (April 15)
*
* Assignment: Project6
: Four Square Cipher
**********************************************/
#include <string>
using namespace std;


class square{
public:
	char alph[26];
	char plain[5][5];
	square();
	square(string s);
	~square();
	char getChar(int i, int j);
	int* getPos(char a);

};