/**********************************************
* Name: (Andy Gregoire) *
* Date: (April 15)
*
* Assignment: Project6
: Four Square Cipher
**********************************************/

#include "square.h"

//square constructor for plain
square::square()
{	char x = 'A';
	for(int i=0;i<5;i++)
		for(int j=0; j<5;j++)
		{
			if(x == 'Q')
				x++;
			plain[i][j] = x;
			x++;
		}
}//end square constructor
	
//square constructor for cipher
square::square(string s)
{
	char alph[26] = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P',0,'R','S','T','U','V','W','X','Y','Z'};
	int k=0;
	for(int i=0;i<5;i++){
		for(int j=0; j<5;j++){
			if(k >= s.length()) break;
			else if(alph[(s[k]-'A')] != 0)
			{
				plain[i][j] = s[k];
				alph[(s[k]-'A')] = 0;
			}
			else j--;
			k++;
		}
	}
	k=0;
	for(int i = 0; i<5; i++)
		for(int j=0; j<5;j++){
			if(plain[i][j] >= 'A')
				continue;
			else if(alph[k] == 0){ k++; j--;}
			else{
				plain[i][j] = alph[k];
				k++;
			}
		}

}//end square constructor

//destructor
square::~square(){}

//returns character in the parameter position
char square::getChar(int i, int j)
{
	return plain[i][j];
}

//returns position of parameter character from square
int* square::getPos(char a)
{
	int *loc = new int();
	for(int i=0; i<5;i++){
		for(int j=0; j<5; j++){
			if(plain[i][j] == a){
				*loc = i; 
				*(loc+1) = j;
				return loc;
			}
		}
	}
}