/**********************************************
* Name: (Andy Gregoire) *
* Date: (April 15)
*
* Assignment: Project6
: Four Square Cipher
**********************************************/
#include "square.h"
using namespace std;
class cipher{
public:
	square *p1,*p2,*c1,*c2;
	cipher(string s1, string s2);
	~cipher();
	string encrypt(string ret);
	string decrypt(string ret);

};