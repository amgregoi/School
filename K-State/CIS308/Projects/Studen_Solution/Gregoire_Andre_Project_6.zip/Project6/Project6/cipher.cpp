/**********************************************
* Name: (Andy Gregoire) *
* Date: (April 15)
*
* Assignment: Project6
: Four Square Cipher
**********************************************/
#include "cipher.h"
using namespace std;

	square *p1,*p2,*c1,*c2;

	//cipher constructor - initialize the 4 squares
	cipher::cipher(string s1, string s2)
	{
		p1 = new square();
		p2 = new square();
		c1 = new square(s1);
		c2 = new square(s2);
	}
	//destructor - free memory of the four squares
	cipher::~cipher()
	{
		delete p1;
		delete p2;
		delete c1;
		delete c2;
	}
	//encryptes user parameter message
	string cipher::encrypt(string ret)
	{
		for(int k=0; k < ret.length()-1; k+=2){
			int* one = p1->getPos(ret[k]);
			int* two = p2->getPos(ret[k+1]);
			ret[k]= c1->getChar(*one, *(two+1));
			ret[k+1] = c2->getChar(*two, *(one+1));
		}
		return ret;
	}
	//decrypts user parameter message
	string cipher::decrypt(string ret)
	{
		for(int k=0; k < ret.length()-1; k+=2){
			int* one = c1->getPos(ret[k]);
			int* two = c2->getPos(ret[k+1]);
			ret[k]= p1->getChar(*one, *(two+1));
			ret[k+1] = p2->getChar(*two, *(one+1));
		}
		return ret;
	}