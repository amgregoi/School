/**********************************************
* Name: (Andy Gregoire) *
* Date: (May 9)*
* Assignment: Project8:Representing Numbers
*
***********************************************
* (Input an arithmetic expression of integers, 
*  reals or rationals and operators: +, -, *  )
***********************************************/
#ifndef integer_h
#define integer_h
#include "number.h"
using namespace std;
class integer: public Number{
private:
	int val;
public:
	integer(string x);
	double value();
	Number* plus(Number *n);
	Number* minus(Number *n);
	Number* times(Number *n);
	void print(void);
	int gcd(int, int);
	int lcm(int, int);
	/*
	virtual double value();
	virtual Number* plus(Number *n);
	virtual Number* minus(Number *n);
	virtual Number* times(Number *n);
	virtual void print(void); */
};
#endif