/**********************************************
* Name: (Andy Gregoire) *
* Date: (May 9)*
* Assignment: Project8:Representing Numbers
*
***********************************************
* (Input an arithmetic expression of integers, 
*  reals or rationals and operators: +, -, *  )
***********************************************/
#ifndef real_h
#define real_h
#include "number.h"
using namespace std;
using namespace std;
class real:public Number{
private:
	double val;
public:
	double value();
	real(string x);
	Number* plus(Number *n);
	Number* minus(Number *n);
	Number* times(Number *n);
	void print(void);
};
#endif