/**********************************************
* Name: (Andy Gregoire) *
* Date: (May 9)*
* Assignment: Project8:Representing Numbers
*
***********************************************
* (Input an arithmetic expression of integers, 
*  reals or rationals and operators: +, -, *  )
***********************************************/
#include "integer.h"
#include "real.h"
#include "rational.h"

integer::integer(string x)
{
	val = atoi(x.c_str());
	type = 1;
}

//returns double of number value
double integer::value(){
	return (double)val;
}
//Integer + (Integer || real || rational)
Number* integer::plus(Number *n){
	if(n->type == 1)//int + int
		return new integer(to_string(this->value() + n->value()));
	else if(n->type == 2)//int + real
		return (new real(to_string(this->value() + n->value())));
	else{ //int + rational
		string temp = to_string((int)(n->value()));
		char loc = temp[temp.length()-1];
		int l = int(loc)-48;
		temp.insert(l,1,'/');
		temp = temp.substr(0,temp.length()-1);
		string num = temp.substr(0,l),den = temp.substr(l+1,temp.length());
		int newNum=((int)(atoi(num.c_str())+(atoi(den.c_str())*this->value())));
		
		int newDen = atoi(den.c_str()),
		d = gcd(atoi(den.c_str()),newNum);
  		newNum/=d;
		newDen/=d;
		if(d < 0 && newNum > 0){ d*=-1; newNum*=-1;}
		else if(d < 0 && newNum <0) d*=-1;
		
		return (new rational(to_string(newNum)+'/'+to_string(newDen)));
	}
}

//Integer - (Integer || real || rational)
Number* integer::minus(Number *n){
	if(n->type == 1)//int + int
		return new integer(to_string(this->value() - n->value()));
	else if(n->type == 2)//int + real
		return (new real(to_string(this->value() - n->value())));
	else{ //int + rational
		string temp = to_string((int)(n->value()));
		char loc = temp[temp.length()-1];
		int l = int(loc)-48;
		temp.insert(l,1,'/');
		temp = temp.substr(0,temp.length()-1);
		string num = temp.substr(0,l),den = temp.substr(l+1,temp.length());
		int newNum = ( ((int)this->value() * atoi(den.c_str())) - atoi(num.c_str()) );
		
		
		int newDen = atoi(den.c_str()),
		d = gcd(atoi(den.c_str()),newNum);
  		newNum/=d;
		newDen/=d;
		if(d < 0 && newNum > 0){ d*=-1; newNum*=-1;}
		else if(d < 0 && newNum <0) d*=-1;
		
		return (new rational(to_string(newNum)+'/'+to_string(newDen)));
	}
}

//Integer * (Integer || real || rational)
Number* integer::times(Number *n){
if(n->type == 1)//int + int
		return new integer(to_string(this->value() * n->value()));
	else if(n->type == 2)//int + real
		return (new real(to_string(this->value() * n->value())));
	else{ //int + rational
		string temp = to_string((int)(n->value()));
		char loc = temp[temp.length()-1];
		int l = int(loc)-48;
		temp.insert(l,1,'/');
		temp = temp.substr(0,temp.length()-1);
		string num = temp.substr(0,l),den = temp.substr(l+1,temp.length());
		int newNum =((int)this->value() * atoi(num.c_str()));

		int newDen = atoi(den.c_str()),
		d = gcd(atoi(den.c_str()),newNum);
  		newNum/=d;
		newDen/=d;
		if(d < 0 && newNum > 0){ d*=-1; newNum*=-1;}
		else if(d < 0 && newNum <0) d*=-1;


		return new rational(to_string(newNum)+'/'+ to_string(newDen));
	}
}
void integer::print(void){
	cout << val;
}

int integer::gcd (int a, int b) {
    return (b == 0) ? a : gcd (b, a%b);
}

int integer::lcm(int x, int y)
{
 	int t = gcd(x,y);
	return (x*y/t);
}
