/**********************************************
* Name: (Andy Gregoire) *
* Date: (May 9)*
* Assignment: Project8:Representing Numbers
*
***********************************************
* (Input an arithmetic expression of integers, 
*  reals or rationals and operators: +, -, *  )
***********************************************/
#include "rational.h"
#include "real.h"
#include <algorithm>

rational::rational(string x)
{
	for(int i=0;i<x.length(); i++)
	{
		if(x[i] == '/')
		{
			numer = x.substr(0,i);
			denom = x.substr(i+1,x.length());
			loc = to_string(i);
			break;
		}
	}
	val = x;
	type = 3;
}
double rational::value(){
	string ret = (numer+denom+loc);
	return atof(ret.c_str());
}

//Rational + (Integer || real || rational)
Number* rational::plus(Number *n){
	if(n->type == 3){
		string temp = to_string((int)(n->value()));
		char loc = temp[temp.length()-1];
		int l = int(loc)-48;
		temp.insert(l,1,'/');
		temp = temp.substr(0,temp.length()-1);
		string num = temp.substr(0,l),den = temp.substr(l+1,temp.length());

		int d = lcm(atoi(this->denom.c_str()),atoi(den.c_str()));
		int newDen= (atoi(this->denom.c_str()) * atoi(den.c_str())),
			newNum =(atoi(this->numer.c_str()) * atoi(den.c_str())) + (atoi(num.c_str()) * atoi(this->denom.c_str()));
		int temp2 = newDen/d;
		newNum/=temp2;
		return new rational(to_string(newNum)+'/'+to_string(d));
	}
	else if(n->type == 2){
		double Frac2Float =(atof(numer.c_str())/atof(denom.c_str()));
		return new real(to_string(Frac2Float + n->value()));
	}
	else
	{ 
		int newNum=((int)(atoi(numer.c_str())+(atoi(denom.c_str())*n->value()))),
		newDen = atoi(denom.c_str()),
		d = gcd(atoi(denom.c_str()),newNum);
  		newNum/=d;
		newDen/=d;
		if(d < 0 && newNum > 0){ d*=-1; newNum*=-1;}
		else if(d < 0 && newNum <0) d*=-1;
		return new rational(to_string(newNum)+'/'+ to_string(newDen));
	}
}

//Rational - (Integer || real || rational)
Number* rational::minus(Number *n){
	if(n->type == 3){
		string temp = to_string((int)(n->value()));							// converts rational double back into a fraction
		char loc = temp[temp.length()-1];									//
		int l = int(loc)-48;												//
		temp.insert(l,1,'/');												//
		temp = temp.substr(0,temp.length()-1);								//
		string num = temp.substr(0,l),den = temp.substr(l+1,temp.length());	//

		int d = lcm(atoi(this->denom.c_str()),atoi(den.c_str()));			//reduces rational
		int newDen= (atoi(this->denom.c_str()) * atoi(den.c_str())),		//
			newNum = ( (atoi(this->numer.c_str()) * atoi(den.c_str())) - (atoi(num.c_str()) * atoi(this->denom.c_str())));
		int temp2 = newDen/d;												//
		newNum/=temp2;														//

		return new rational(to_string(newNum)+'/'+to_string(d));			// return new rational
	}
	else if(n->type == 2){
		double Frac2Float =(atof(numer.c_str())/atof(denom.c_str()));
		return new real(to_string(Frac2Float - n->value()));
	}
	else
	{ 
		int newNum=((int)(atoi(numer.c_str())-(atoi(denom.c_str())*n->value()))),
		newDen = atoi(denom.c_str()),
		d = gcd(atoi(denom.c_str()),newNum);
  		newNum/=d;
		newDen/=d;
		if(d < 0 && newNum > 0){ d*=-1; newNum*=-1;}
		else if(d < 0 && newNum <0) d*=-1;
		return new rational(to_string(newNum)+'/'+ to_string(newDen));
	}
}

//Rational * (Integer || real || rational)
Number* rational::times(Number *n){
if(n->type == 3){
		string temp = to_string((int)(n->value()));
		char loc = temp[temp.length()-1];
		int l = int(loc)-48;
		temp.insert(l,1,'/');
		temp = temp.substr(0,temp.length()-1);
		string num = temp.substr(0,l),den = temp.substr(l+1,temp.length());

		
		int newDen= (atoi(this->denom.c_str()) * atoi(den.c_str())),
			newNum = ( (atoi(this->numer.c_str()) * (atoi(num.c_str()))));
		int d = gcd(newDen,newNum);
		newDen/=d;
  		newNum/=d;
		return new rational(to_string(newNum)+'/'+to_string(newDen));
	}
	else if(n->type == 2){
		double Frac2Float =(atof(numer.c_str())/atof(denom.c_str()));
		return new real(to_string(Frac2Float * n->value()));
	}
	else
	{ 
		int newNum=((int)(atoi(numer.c_str())*(int)n->value())),
		newDen = atoi(denom.c_str()),
		d = gcd(atoi(denom.c_str()),newNum);
  		newNum/=d;
		newDen/=d;
		if(d < 0 && newNum > 0){ d*=-1; newNum*=-1;}
		else if(d < 0 && newNum <0) d*=-1;
		return new rational(to_string(newNum)+'/'+ to_string(newDen));
	}
}
void rational::print(void){
	cout << val;
}

int rational::lcm(int x, int y)
{
 	int t = gcd(x,y);
	return (x*y/t);
}

int rational::gcd (int a, int b) {
    return (b == 0) ? a : gcd (b, a%b);
}
