/**********************************************
* Name: (Andy Gregoire) *
* Date: (May 9)*
* Assignment: Project8:Representing Numbers
*
***********************************************
* (Input an arithmetic expression of integers, 
*  reals or rationals and operators: +, -, *  )
***********************************************/
#ifndef number_h
#define number_h
#include <string>
#include <iostream>
class Number{
public:
	int type;
	virtual double value()=0;
	virtual Number* plus(Number *n)=0;
	virtual Number* minus(Number *n)=0;
	virtual Number* times(Number *n)=0;
	virtual void print(void){};
};
#endif