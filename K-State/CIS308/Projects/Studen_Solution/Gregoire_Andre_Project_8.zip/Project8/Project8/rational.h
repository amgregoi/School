/**********************************************
* Name: (Andy Gregoire) *
* Date: (May 9)*
* Assignment: Project8:Representing Numbers
*
***********************************************
* (Input an arithmetic expression of integers, 
*  reals or rationals and operators: +, -, *  )
***********************************************/
#ifndef rational_h
#define rational_h
#include "number.h"
using namespace std;
class rational:public Number{
private:
	string val;
	string numer, denom, loc;
public:
	double value();
	rational(string x);
	Number* plus(Number *n);
	Number* minus(Number *n);
	Number* times(Number *n);
	void print(void);
	int lcm(int, int);
	int gcd(int, int);
};
#endif