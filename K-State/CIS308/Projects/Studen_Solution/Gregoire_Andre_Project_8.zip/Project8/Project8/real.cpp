/**********************************************
* Name: (Andy Gregoire) *
* Date: (May 9)*
* Assignment: Project8:Representing Numbers
*
***********************************************
* (Input an arithmetic expression of integers, 
*  reals or rationals and operators: +, -, *  )
***********************************************/
#include "real.h"

real::real(string x)
{
	val = atof(x.c_str());
	type = 2;
}

//returns double of number value
double real::value(){
	return (double)val;
}

//Real + (Integer || real || rational)
Number* real::plus(Number *n){
	if(n->type == 3){
		string temp = to_string((int)(n->value()));
		char loc = temp[temp.length()-1];
		int l = int(loc)-48;
		temp.insert(l,1,'/');
		temp = temp.substr(0,temp.length()-1);
		string num = temp.substr(0,l),den = temp.substr(l+1,temp.length());

		double Frac2Float =(atof(num.c_str())/atof(den.c_str()));
		return new real(to_string(Frac2Float + this->value()));
	}
	else if(n->type == 2){
		return new real(to_string(this->value() + n->value()));
	}
	else
	{ 
		return new real(to_string(this->value()+n->value()));
	}
}

//Real - (Integer || real || rational)
Number* real::minus(Number *n){
	if(n->type == 3){
		string temp = to_string((int)(n->value()));
		char loc = temp[temp.length()-1];
		int l = int(loc)-48;
		temp.insert(l,1,'/');
		temp = temp.substr(0,temp.length()-1);
		string num = temp.substr(0,l),den = temp.substr(l+1,temp.length());


		double Frac2Float =(atof(num.c_str())/atof(den.c_str()));
		return new real(to_string(this->value() - Frac2Float));
	}
	else if(n->type == 2){
		return new real(to_string(this->value() - n->value()));
	}
	else
	{ 
		return new real(to_string(this->value() - n->value()));
	}
}

//Real * (Integer || real || rational)
Number* real::times(Number *n){
if(n->type == 3){
		string temp = to_string((int)(n->value()));
		char loc = temp[temp.length()-1];
		int l = int(loc)-48;
		temp.insert(l,1,'/');
		temp = temp.substr(0,temp.length()-1);
		string num = temp.substr(0,l),den = temp.substr(l+1,temp.length());

		double Frac2Float =(atof(num.c_str())/atof(den.c_str()));
		return new real(to_string(Frac2Float * this->value()));
	}
	else if(n->type == 2){
		return new real(to_string(this->value() * n->value()));
	}
	else
	{ 
		return new real(to_string(this->value() * n->value()));
	}
}
void real::print(void){
	cout << val;
}
