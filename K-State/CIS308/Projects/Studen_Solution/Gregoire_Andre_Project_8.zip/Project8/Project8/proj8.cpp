/**********************************************
* Name: (Andy Gregoire) *
* Date: (May 9)*
* Assignment: Project8:Representing Numbers
*
***********************************************
* (Input an arithmetic expression of integers, 
*  reals or rationals and operators: +, -, *  )
***********************************************/


#include "real.h"
#include "rational.h"
#include "integer.h"
#include <algorithm>
using namespace std;
int main()
{
	int loc=0;
	bool isReal = false;
	bool isRational = false;
	char op;
	string x, temp;


	cout<<"Enter an arithmetic expression: ";
	getline(cin,x);
	x.erase(remove(x.begin(),x.end(),' '),x.end());
	Number *num1;
	Number *num2;
	Number *ans;

	for(int i=0; i<(signed)x.length(); i++)
	{
		if(x[i] == '.') isReal = true;
		if(x[i] == '/') isRational = true;
		if(x[i] == '+' || x[i] == '*' || x[i] == '-'){
			op = x[i];
			loc = i;
			if(isReal){ num1 = new real(x.substr(0,loc)); isReal = false;}
			else if(isRational){ num1 = new rational(x.substr(0,loc)); isRational = false;}
			else num1 = new integer(x.substr(0,loc));
		}
	}
	if(isReal){ num2 = new real(x.substr(loc+1,x.length())); isReal = false;}
	else if(isRational){ num2 = new rational(x.substr(loc+1,x.length())); isRational = false;}
	else num2 = new integer(x.substr(loc+1,x.length()));

	if(op == '+') ans = num1->plus(num2);
	else if(op == '-') ans = num1->minus(num2);
	else ans = num1->times(num2);
	cout<<"Result: ";
	ans->print();
	cout <<endl;

	system("pause");

}