#include "BigInteger.h"
using namespace std;

int main()
{
    string s1, s2;
    char c;

    cout<<"Enter first number: ";
	cin >> s1;
	BigInteger a(s1);

    cout<<"Enter second number: ";
	cin >> s2;
	BigInteger b(s2);

	while(true){
		cout<<"Enter operation: ";
		cin >> c;
		if(c == '+'){
			BigInteger x = a.plus(b);
			cout<<s1 + " + " + s2 + " = "; x.toString(); cout<<endl;
			break;
		}
		else if(c== '-'){
			BigInteger x = a.minus(b);
			cout<<s1 + " - " + s2+ " = "; x.toString(); cout<<endl;
			break;
		}
	}
	system("pause");
 }