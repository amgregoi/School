#include <iostream>
#include <string>
#define MAX(a) (((a)>=(0))?(a):(0))
#define SPEC(a,b) ((a+b)==(0)&&(a == -1)?(1):(a+b))
#define SIZE 50
using namespace std;

#ifndef BigInteger_H
#define BigInteger_H

class BigInteger{
	public:
		int num[SIZE];
		BigInteger(string s);
		BigInteger(int* s);
		BigInteger plus(BigInteger s);
		BigInteger minus(BigInteger s);
		void toString(void);
};
#endif
