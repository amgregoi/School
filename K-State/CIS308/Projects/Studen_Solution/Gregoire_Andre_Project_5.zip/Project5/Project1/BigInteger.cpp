#include "BigInteger.h"
using namespace std; 

	int num[SIZE];
	BigInteger::BigInteger(string s)
	{
		int j=s.length()-1;
		for(int i=SIZE-1; i>=0; i--)
		{
			if(j>=0)
			{
				num[i] =s[j]-48;
				if(num[i] == -48) num[i] = -1;
				j--;
			}
			else num[i]=-1;
		}
	}

	BigInteger::BigInteger(int* s)
	{
		for(int i =0; i<SIZE; i++)
			num[i]=s[i];
	}

	BigInteger BigInteger::plus(BigInteger s)
	{
		int carry=0, temp[SIZE], x;
		for(int i=SIZE-1; i>=0; i--)
		{
			if(num[i] == -1) x = SPEC(s.num[i], carry);
			else if(s.num[i] == -1) x = SPEC(num[i], carry);
			else x = MAX(num[i]) + MAX(s.num[i])+carry;

			if(x>9) carry = 1;
			else carry = 0;
			temp[i] = x%10;

		}
		BigInteger a(temp);
		return temp;
	}

	BigInteger BigInteger::minus(BigInteger s)
	{
		int temp[SIZE], x;
		for(int i=SIZE-1; i>=0; i--)
		{
			if(num[i] < s.num[i])
			{
				for(int j=i-1; j>=0; j--)
				{
					if(num[j] > 0)//decrements num for carry
					{
						num[j]--;	
						break;
					}
					else if(num[j] == 0)//takes care of carry between mulitple zeros
						num[j] = 9;	
				}
				x = MAX(num[i])+10-MAX(s.num[i]);
			}
			else if(num[i] == 0 && num[i-1] == -1) x=-1;
			else if(num[i]==-1) x=s.num[i];
			else if(s.num[i] == -1) x =num[i];
			else x = MAX(num[i])-MAX(s.num[i]);
			temp[i] = x;
		}
		BigInteger a(temp);
		return a;
	}
	void BigInteger::toString(void)
	{
		for(int i=0;i<SIZE;i++)
		{
			if(num[i] != -1)
				cout<<num[i];
		}
	}
//};