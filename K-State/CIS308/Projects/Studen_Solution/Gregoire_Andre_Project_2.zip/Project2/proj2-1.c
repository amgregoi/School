/**********************************************
* Name: Andy Gregoire                         *
* Date: Feb 14, 2013 - Midnight               *
* Assignment: Permutation (project2)          *
***********************************************
* find permutations of input string           *
* Comment out Line42 to remove extra credit   *
* function and test for regular output	      *
***********************************************/
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <stdlib.h>
int testWord(char* word)
{
	char *dict=malloc(sizeof(char)); //temp - holds a word from the word list
	FILE *f;//file opener
	if((f=fopen("words.txt", "r"))== NULL){printf("Error opening file"); exit(1);} //opens file
	while(fgets(dict, 20, f) != NULL)//loops through file looking for permutated word
	{
		if(strncmp(word, dict, 50)==0){ //compares word with dict
			fclose(f); //closes file
			return 1; //returns 1
		}//endif
	}//end while
	fclose(f); // close file
	return 0; //return 0
}//end testWord

//swaps the places of characters in location i & j in arr[]
void swap (char arr[], int i, int j)
{
    char t;
    t= arr[i]; //temp holds arr[i]
    arr[i] = arr[j];//place char in arr[j] in arr[i]
    arr[j] = t;//place above temp var into arr[j]
}//end swap

//finds/prints all permutations of the word passed in
void permutation(char word[], int start, int end)
{
   int j;//loop var
   if (start == end){
	if(testWord(word)){ //################## Comment out this line to remove extra credit function
		 printf("%s", word); //print permutation
	}
    }//end if
   else {
       for (j = start; j <= end; j++){
          swap(word, start, j);//calls swap to alter permutation
          permutation(word, start+1, end);//recursive call of function
          swap(word, j, start);
       }//end for
   }//end else
}//end perm

int main() 
{
        char word[20];
        printf("Enter a word: ");//prompt
        fgets(word, 19, stdin);//get input string
        permutation(word, 0, strlen(word)-2);//call permutation function
        return 0;
}//end main
