#include <string>
using namespace std;

#ifndef SQUARE_H
#define SQUARE_H

class Square {
private:
	char** matrix;
public:
	Square(void);
	Square(string);
	~Square();
	char getChar(int, int);
	int* getPos(char);
};

bool strContains(string, char);
string removeDups(string);

#endif