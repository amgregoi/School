#include "square.h"
#include <string>

using namespace std;

#ifndef CIPHER_H
#define CIPHER_H

class Cipher {
private:
	Square *plain1, *plain2, *cipher1, *cipher2;

public:
	Cipher(string, string);
	~Cipher();
	string encrypt(string);
	string decrypt(string);
};

string removeSpaces(string);
string toUpperCase(string);

#endif