#include "cipher.h"
#include <iostream>

Cipher::Cipher(string key1, string key2) {
	plain1 = new Square;
	plain2 = new Square;
	cipher1 = new Square(toUpperCase(key1));
	cipher2 = new Square(toUpperCase(key2));
}

Cipher::~Cipher() {
	delete plain1;
	delete plain2;
	delete cipher1;
	delete cipher2;
}

string Cipher::encrypt(string message) {
	message = removeSpaces(toUpperCase(message));
	
	string result = "";
	int i;
	//encrypt string in groups of two
	for (i = 0; i < message.length(); i+=2) {
		char c1 = message[i];
		char c2 = message[i+1];

		int* pos1 = plain1->getPos(c1);
		int* pos2 = plain2->getPos(c2);

		result += cipher1->getChar(pos1[0], pos2[1]);
		result += cipher2->getChar(pos2[0], pos1[1]);

		delete[] pos1;
		delete[] pos2;
	}

	return result;
}

string Cipher::decrypt(string message) {
	message = removeSpaces(toUpperCase(message));
	
	string result = "";
	int i;
	//encrypt string in groups of two
	for (i = 0; i < message.length(); i+=2) {
		char c1 = message[i];
		char c2 = message[i+1];

		int* pos1 = cipher1->getPos(c1);
		int* pos2 = cipher2->getPos(c2);

		result += plain1->getChar(pos1[0], pos2[1]);
		result += plain2->getChar(pos2[0], pos1[1]);

		delete[] pos1;
		delete[] pos2;
	}

	return result;
}

string removeSpaces(string str) {
	string result = "";
	int i;
	for (i = 0; i < str.length(); i++) {
		if (str[i] != ' ') result += str[i];
	}
	
	return result;
}

string toUpperCase(string str) {
	string result = "";
	int i;
	for (i = 0; i < str.length(); i++) {
		result += toupper(str[i]);
	}

	return result;
}