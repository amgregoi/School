#include "square.h"

Square::Square(void) {
	matrix = new char*[5];
	int i, j;
	for (i = 0; i < 5; i++) {
		matrix[i] = new char[5];
	}
		
	int num = 65;

	//fill with alphabet
	for (i = 0; i < 5; i++) {
		for (j = 0; j < 5; j++) {
			matrix[i][j] = (char) num;
			num++;

			//skip 'Q'
			if (num == 81) num++;
		}
	}
}

Square::Square(string key) {
	matrix = new char*[5];
	int i, j;
	for (i = 0; i < 5; i++) {
		matrix[i] = new char[5];
	}

	string letters = removeDups(key+"ABCDEFGHIJKLMNOPRSTUVWXYZ");
	int index = 0;

	//fill with key, then with alphabet
	for (i = 0; i < 5; i++) {
		for (j = 0; j < 5; j++) {
			matrix[i][j] = letters[index];
			index++;
		}
	}
}

Square::~Square() {
	int i;
	for (i = 0; i < 5; i++) {
		delete[] matrix[i];
	}

	delete[] matrix;
}
	
char Square::getChar(int r, int c) {
	return matrix[r][c];
}

int* Square::getPos(char c) {
	int i, j;

	for (i = 0; i < 5; i++) {
		for (j = 0; j < 5; j++) {
			if (matrix[i][j] == c) {
				int* pos = new int[2];
				pos[0] = i;
				pos[1] = j;
				return pos;
			}
		}
	}

	return NULL;
}

bool strContains(string s, char c) {
	int i;
	for (i = 0; i < s.length(); i++) {
		if (c == s[i]) return true;
	}

	return false;
}

string removeDups(string key) {
	string s = "";
	int i;

	for (i = 0; i < key.length(); i++) {
		if (!strContains(s, key[i])) {
			s += key[i];
		}
	}

	return s;
}