#include <iostream>
#include "cipher.h"
#include <string>

using namespace std;

int main() {
	cout << "Enter first key (no Q's): ";
	string first;
	cin >> first;

	cout << "Enter second key (no Q's): ";
	string second;
	cin >> second;

	cout << "\nEnter (e)ncrypt or (d)ecrypt: ";
	char option;
	cin >> option;

	if (first.find("Q") != string::npos || first.find("q") != string::npos || second.find("Q") != string::npos || second.find("q") != string::npos) {
		cout << "Keys cannot contain Qs. " << endl;
		return 0;
	}

	Cipher cipher(first, second);
	string trash;
	getline(cin, trash);

	string msg, result;
	if (option == 'e' || option == 'E') {
		cout << "\nEnter the message to encrypt (no Q's): ";
		getline(cin, msg);
		msg = removeSpaces(msg);
		if (msg.find("Q") != string::npos || msg.find("q") != string::npos) {
			cout << "\nMessages cannot contain Qs." << endl;
			return 1;
		}
		else if (msg.length() % 2 != 0) {
			cout << "\nMessage length must be even." << endl;
			return 1;
		}

		result = cipher.encrypt(msg);
		cout << "\nEncrypted message: " << result << endl;
	}
	else if (option == 'd' || option == 'D') {
		cout << "\nEnter the message to decrypt (no Q's): ";
		getline(cin, msg);
		msg = removeSpaces(msg);
		if (msg.find("Q") != string::npos || msg.find("q") != string::npos) {
			cout << "\nMessages cannot contain Qs." << endl;
			return 1;
		}
		else if (msg.length() % 2 != 0) {
			cout << "\nMessage length must be even." << endl;
			return 1;
		}

		result = cipher.decrypt(msg);
		cout << "\nDecrypted message: " << result << endl;
	}

	system("PAUSE");
	return 0;
}