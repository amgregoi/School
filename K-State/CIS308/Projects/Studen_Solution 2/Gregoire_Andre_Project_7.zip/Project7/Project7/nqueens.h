/**********************************************
* Name: (Andy Gregoire) *
* Date: (April 25th)
*
* Assignment: Project7: N-Queens Problem
*
***********************************************
* (Finds the possible solutions to the N-Queens problem) *
***********************************************/
#include "stack.h"

class nqueen{
private:
	int size;
	Board *b;
	Stack *s, *s2, *s3;
public:
	nqueen(int x);
	void findSols();
	void printSols(void);
};