/**********************************************
* Name: (Andy Gregoire) *
* Date: (April 25th)
*
* Assignment: Project7: N-Queens Problem
*
***********************************************
* (Finds the possible solutions to the N-Queens problem) *
***********************************************/
//stack.h
#include "node.h"
#ifndef STACK_H
class Stack {
	public:
	Node *top;
	Stack(void);
	~Stack();
	void push(Board*);
	Board* peek(void);
	Board* pop(void);
};
#endif