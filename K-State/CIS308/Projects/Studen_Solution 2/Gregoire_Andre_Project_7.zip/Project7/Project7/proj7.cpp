/**********************************************
* Name: (Andy Gregoire) *
* Date: (April 25th)
*
* Assignment: Project7: N-Queens Problem
*
***********************************************
* (Finds the possible solutions to the N-Queens problem) *
***********************************************/
#include "nqueens.h"
#include <iostream>
using namespace std;
int main(){

	int size;
	cout << "Enter Board Size: ";
	cin >> size;

	nqueen *queen = new nqueen(size);
	queen->findSols();
	queen->printSols();
	system("pause");

}