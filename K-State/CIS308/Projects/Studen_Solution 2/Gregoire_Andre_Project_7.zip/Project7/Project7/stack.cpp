/**********************************************
* Name: (Andy Gregoire) *
* Date: (April 25th)
*
* Assignment: Project7: N-Queens Problem
*
***********************************************
* (Finds the possible solutions to the N-Queens problem) *
***********************************************/
//stack.cpp
#include "stack.h"

//stack constructor
Stack::Stack(void) {
	top = NULL;
}

//stack deconstructor
Stack::~Stack() {
	while (top != NULL) pop(); 
}

//push Board * onto stack
void Stack::push(Board* val) {
	Node *newnode = new Node(val);
	if (top == NULL) top = newnode;
	else {
	newnode->next = top;
	top = newnode;
	}
}

//pop node from stack
Board* Stack::pop(void) {
	if (top == NULL) throw "Stack is empty";
	else {
		Board* data = top->data;
		Node *temp = top;
		top = top->next;
		delete temp;
		return data;
	}
}
