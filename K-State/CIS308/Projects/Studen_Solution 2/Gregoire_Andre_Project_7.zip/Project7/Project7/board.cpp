/**********************************************
* Name: (Andy Gregoire) *
* Date: (April 25th)
*
* Assignment: Project7: N-Queens Problem
*
***********************************************
* (Finds the possible solutions to the N-Queens problem) *
***********************************************/
#include "board.h"
#include <iostream>
#define pos(a) ((a>=0)?(a):(a*(-1)))
using namespace std;

//Board constructor
Board::Board(int x)
{
	size = x;
	posx = 0;
	visited=0;
	numQueens = 0;
	chessboard = new int*[size];
	for(int i=0; i<size; i++)
		chessboard[i] = new int[size];
	for(int i=0; i<x; i++){
		for(int j=0; j<x;j++){
			chessboard[i][j] = 0;
		}
		queens[i][0] = 0; queens[i][1] = 0;
	}
}

//duplicates & returns current board
Board* Board::duplicate(void){
	Board *x = new Board(size);
	for(int i=0; i<size;i++){
		x->queens[i][0] = queens[i][0];x->queens[i][1] = queens[i][1]; 
		for(int j=0; j<size;j++)
			x->chessboard[i][j] = chessboard[i][j];
	}
	x->numQueens = numQueens;
	x->size = size;
	x->posx = posx;
	return x;
}

//returns number of queens placed
int Board::getNumQueen(void){
	return numQueens;
}

//place a queen
void Board::move(int r, int c){ // puts queen at (r,c)
	chessboard[r][c] = 1;
	numQueens++;
	queens[posx][0] = r; queens[posx][1] = c;
	posx++;
}

//go back 1 move
void Board::remove(int r, int c){ // puts queen at (r,c)
	chessboard[r][c] = 0;
	numQueens--;
	queens[posx][0] = 0; queens[posx][1] = 0;
	posx--;
}

//checks if column is free to place a queen
int Board::checkCol(int newCol){//return 1 if we can add queen to column
	for(int i=0; i<size; i++)
		if(chessboard[i][newCol] == 1)//might need to change around
			return 0;
	return 1;
}

//checks if row is free to place a queen
int Board::checkRow(int newRow){//return 1 if we can add queen to row
	for(int i=0; i<size; i++)
		if(chessboard[newRow][i] == 1)//might need to change around
			return 0;
	return 1;
}

//checks if diagonal is free to place a queen
int Board::checkDiag(int newRow, int newCol){
	for(int i=0; i<size; i++){
		row = queens[i][0]; col=queens[i][1];
		if(pos((newRow-row))==pos((newCol-col)) && chessboard[row][col] == 1) return 0;
	}
	return 1;			
}

//prints out board
void Board::printBoard(int sols){
	for(int i=0; i<size;i++){
		for(int k=0; k<size; k++) cout << "----"; cout<<endl;
		cout<< "|"; 
		for(int j=0; j<size;j++){
			if(chessboard[i][j] == 1)
				cout << " X |";
			else
				cout << "   |";
		}
		cout << "\n";
	}
	for(int k=0; k<size; k++) cout << "----"; cout<<endl;
}

//return 1 if not a duplicate board
int Board::compareBoards(Board *temp){
	if(temp == NULL) return 1;
	for(int i=0; i<size; i++)
		for(int j=0; j<size;j++)
			if(chessboard[i][j] != temp->chessboard[i][j]) return 1;
	return 0;
}