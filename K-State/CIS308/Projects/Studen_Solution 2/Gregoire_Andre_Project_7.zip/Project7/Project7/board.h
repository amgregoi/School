/**********************************************
* Name: (Andy Gregoire) *
* Date: (April 25th)
*
* Assignment: Project7: N-Queens Problem
*
***********************************************
* (Finds the possible solutions to the N-Queens problem) *
***********************************************/
class Board{
	private:
		int size, visited, row, col, numQueens, posx;
		int **chessboard;
		int queens[8][2];
	public:
		Board(int x);
		Board* duplicate(void);
		int getNumQueen(void);
		void move(int r, int c); // moves queen at (r,c)
		void remove(int r, int c);
		int checkCol(int newCol);//return 1 if we can add queen to column
		int checkRow(int newRow);
		int checkDiag(int newRow, int newCol);
		void printBoard(int sols);
		int compareBoards(Board *temp);
};