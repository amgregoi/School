/**********************************************
* Name: (Andy Gregoire) *
* Date: (April 25th)
*
* Assignment: Project7: N-Queens Problem
*
***********************************************
* (Finds the possible solutions to the N-Queens problem) *
***********************************************/
#include "nqueens.h"
#include <iostream>
using namespace std;

//nqueen constructor
nqueen::nqueen(int x){
	size = x;
	b = new Board(size);
	s = new Stack;
	s2 = new Stack;
	s3 = new Stack;
	s->push(b);
}

//finds solutions 
void nqueen::findSols(){
	int c,m=0,n=0;
	while(s->top != NULL){
		c = 0;
		b = s->pop();
		for(int i=0; i<size; i++){
			if(b->checkRow(i) == 0)continue;
			for(int j=0; j<size; j++){
				if(b->checkCol(j)==1 && b->checkDiag(i,j)==1){
					b->move(i,j);	//places queen at (i,j)
					s->push(b->duplicate()); //pushes board onto stack
					if(b->getNumQueen() == size){
						for(Node *temp = s2->top;temp != NULL; temp=temp->next){
							n=b->compareBoards(temp->data);//compare board to board on stack for duplicate
							if(n==0) break;
						}//end for
						if(n>0 || s2->top == NULL){ s2->push(b->duplicate()); m++;}
						n=0;
					}//endif
					b->remove(i,j); // remove previous placement to do next move
					c++;
					break;
				}//endif
			}//end innter for
			if(c == 0) break;
		}//end outter for
	}//end while
}//end function

//prints solutions found from findSols
void nqueen::printSols(){
	int count = 1;
	while(s2->top != NULL){
		cout<<"Solution Number: "<<count<<endl;
		b = s2->pop();
		count++;
		b->printBoard(count);
		cout<<endl;
	}
	cout << "There were "<< count-1 << " solutions."<<endl<<endl;
}

