/**********************************************
* Name: (Andy Gregoire) *
* Date: (April 25th)
*
* Assignment: Project7: N-Queens Problem
*
***********************************************
* (Finds the possible solutions to the N-Queens problem) *
***********************************************/
#include<stdlib.h>
#include "board.h"
//node.h
#ifndef NODE_H
#define NODE_H
class Node {
	public:
	Board *data;
	Node *next;
	Node(Board *d){data = d; next = NULL;}
};
#endif