/*******************************************
Name: Andy Gregoire
Due: 3/14/2013
assignment : project 4
uses a tri to print all anagrams on input word
/*******************************************/
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>

typedef struct trie {
	char letter;
	enum{true, false}isWord;			//change to enum later
	struct trie* children[26];
} TRIE;

char *alpha = ".abcdefghijklmnopqrstuvwxyz.";

//Root of TRIE
TRIE *root=NULL;

//returns index of letter in children array of trie struct
int indexOf(char letter) {
	int i;
	for(i=0; i<26; i++)
		if(letter == alpha[i])
			return i;
}

//searchs for permutations (word) in TRIE
int search(char *word)
{
	TRIE *cur = root;
	int i, index;
	for(i=0; i<strlen(word); i++){
		index = indexOf(word[i]);
		if(cur->children[index] == NULL) return 0;
		else if(cur->isWord == true && i == strlen(word)-1){return 1; }
		else cur = cur->children[index];
	}
	return 0;
}

//adds word to trie
void add(char *word)
{
	TRIE *cur = root;
	int index, i;
	for(i=0; i<strlen(word)-1; i++){
		index = indexOf(word[i]);
		if(cur->children[index] == NULL)
		{
			cur->children[index] = malloc(sizeof(TRIE));
			cur->letter = word[i];
			if(i == strlen(word)-2)   cur->isWord = true;
			cur = cur->children[index];
			cur->isWord = false;
		}
		else	cur = cur->children[index];
	}//end while
}

//puts words in dictionary in TRIE
void buildTrie(char *fn)
{
char *dict=malloc(sizeof(char)); //temp - holds a word from the word list       
FILE *f;
if((f=fopen(fn, "r"))== NULL){printf("Error opening %s  file\n\n", fn); exit(1);} //opens file
while(fgets(dict, 20, f) != NULL)
		add(dict);
}

//swaps the places of characters in location i & j in arr[]
void swap (char arr[], int i, int j)
{
    char t;
    t= arr[i]; //temp holds arr[i]
    arr[i] = arr[j];//place char in arr[j] in arr[i]
    arr[j] = t;//place above temp var into arr[j]
}//end swap

//finds/prints all permutations of the word passed in
void permutation(char *word, int start, int end)
{
   int j;//loop var
   int i;
   if (start == end){
	if((i= search(word))==1)
		printf("%s\n", word); //print permutation
    }//end if
   else {
       for (j = start; j <= end; j++){
          swap(word, start, j);//calls swap to alter permutation
          permutation(word, start+1, end);//recursive call of function
          swap(word, j, start);
       }//end for
   }//end else
}//end perm

void freeTRIE(TRIE *temp)
{
	int i;
	for(i=0; i<26; i++)
		freeTRIE(temp->children[i]);
	free(temp);
}

//main
int main( int argc, char *argv[] ){
	if(argc != 2) printf("no file input found\n");
	else
	{
		root=malloc(sizeof(TRIE));
		root->letter = ' ';
		root->isWord = 0;
		buildTrie(argv[1]);
		char *word = malloc(sizeof(char *));
		printf("Enter a word: ");//prompt
	//	fgets(word, 19, stdin);//get input string
		scanf("%s", word);
		permutation(word, 0, strlen(word)-1);//call permutation function
	}
	free(root);
	exit(0);

}

