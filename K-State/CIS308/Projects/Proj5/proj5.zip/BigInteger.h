#ifndef biginteger_h
#define biginteger_h

#include <string>
#include <iostream>

using namespace std;

class BigInteger {
	private:
		string num;
		
	public:
		BigInteger(void);
		BigInteger(string);
		BigInteger plus(BigInteger);
		BigInteger minus(BigInteger);
		string toString(void);
		void setNum(string);
};

#endif