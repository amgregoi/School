#include "BigInteger.h"
#include <string>
#include <iostream>

using namespace std;

int main() {
	string first, second;
	string operation;
	BigInteger one, two, result;

	cout << "Enter first number: ";
	cin >> first;
	cout << "Enter second number: ";
	cin >> second;
	cout << "Enter operation (+ or -): ";
	cin >> operation;

	one.setNum(first);
	two.setNum(second);

	if (operation == "+") {
		result = one.plus(two);
	}
	else if (operation == "-") {
		result = one.minus(two);
	}
	else {
		cout << "Invalid operation" << endl;
		return 1;
	}

	cout << endl << one.toString() << " " << operation << " " << two.toString() << " = " << result.toString() << endl;

	system("PAUSE");

	return 0;
}