#include "BigInteger.h"
#include <cstring>
#include <sstream>

BigInteger::BigInteger(void) {
	num = "0";
}

BigInteger::BigInteger(string s) {
	num = s;
}

BigInteger BigInteger::plus(BigInteger b) {
	string added = "";
	
	int index1 = num.size()-1;
	int index2 = b.num.size()-1;
	
	int carry = 0;
	
	while (index1 >= 0 && index2 >= 0) {
		int dig1 = ((int)num[index1])-48;
		int dig2 = ((int)b.num[index2])-48;
		int sum = dig1+dig2+carry;

		ostringstream conv;
		
		carry = 0;
		
		while (sum >= 10) {
			sum -= 10;
			carry += 1;
		}
		
		conv << sum;
		added = conv.str() + added;
		index1--;
		index2--;
	}
	
	while (index1 >= 0) {
		int sum = ((int)num[index1])-48 + carry;
		ostringstream conv;

		carry = 0;

		while (sum >= 10) {
			sum -= 10;
			carry += 1;
		}
		
		conv << sum;
		added = conv.str() + added;
		index1--;
	}
	while (index2 >= 0) {
		int sum = ((int)b.num[index2])-48 + carry;
		ostringstream conv;

		carry = 0;

		while (sum >= 10) {
			sum -= 10;
			carry += 1;
		}
		
		conv << sum;
		added = conv.str() + added;
		index2--;	
	}
	
	added = carry + "" + added;
	
	return BigInteger(added);
}

BigInteger BigInteger::minus(BigInteger b) {
		string added = "";
	
	int index1 = num.size()-1;
	int index2 = b.num.size()-1;
	
	int borrow = 0;
	
	while (index1 >= 0 && index2 >= 0) {
		int dig1 = ((int)num[index1])-48;
		int dig2 = ((int)b.num[index2])-48;
		int sum = dig1-dig2+borrow;

		ostringstream conv;
		
		borrow = 0;
		
		while (sum <= 0) {
			sum += 10;
			borrow -= 1;
		}
		
		conv << sum;
		added = conv.str() + added;
		index1--;
		index2--;
	}
	
	//we assume that num is bigger than b.num
	while (index1 >= 0) {
		int sum = ((int)num[index1])-48 + borrow;
		ostringstream conv;

		borrow = 0;

		while (sum <= 0) {
			sum += 10;
			borrow -= 1;
		}
		
		conv << sum;
		added = conv.str() + added;
		index1--;
	}
	
	added = borrow + "" + added;
	
	return BigInteger(added);
}

string BigInteger::toString(void) {
	return num;
}

void BigInteger::setNum(string n) {
	num = n;
}