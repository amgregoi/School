#include "Board.h"
#include <iostream>
#include <string>

using namespace std;

/**
	* Board creates an empty chessboard
	*
	* @param size The size of the chessboard
	*/
Board::Board(int size) {
	chessboard = new bool*[size];
	for (int i = 0; i < size; i++) {
		chessboard[i] = new bool[size];
	}
	this->size = size;

	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
			chessboard[i][j] = false;
		}
	}
	numQueens = 0;
	row = -1;
	col = -1;
}

Board::~Board() {
	for (int i = 0; i < size; i++) {
		delete[] chessboard[i];
	}
	delete[] chessboard;
}

/**
	* duplicate returns a new Board object
	* with the same instance variables as this object
	*
	* @return The duplicate board
	*/
Board* Board::duplicate() {
	Board* b = new Board(size);
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
			b->chessboard[i][j] = chessboard[i][j];
		}
	}

	b->row = row;
	b->col = col;
	b->numQueens = numQueens;

	return b;
}

/**
	* getQueens returns the number of queens on this board
	*
	* @return The number of queens on this board
	*/
int Board::getQueens() {
	return numQueens;
}

/**
	* getRow returns the row of the last queen added to this board
	*
	* @return The row of the last queen added to this board
	*/
int Board::getRow() {
	return row;
}

/**
	* move adds a new queen at position (r, c)
	*
	* @param r The row of the new queen
	* @param c The column of the new queen
	*/
void Board::move(int r, int c) {
	chessboard[r][c] = true;
	row = r;
	col = c;
	numQueens++;
}

/**
	* checkCol returns whether it is safe to put a queen in
	* column newCol
	*
	* @param newCol the column to check
	* @return Whether that column is safe
	*/
bool Board::checkCol(int newCol) {
	if (row == -1 && col == -1) return true;
	for (int i = 0; i < size; i++) {
		if (chessboard[i][newCol]) return false;
	}
	return true;
}

/**
	* checkDiagonal returns whether it is safe to put a queen
	* on a diagonal from (newRow, newCol)
	*
	* @param newRow The proposed row for a new queen
	* @param newCol The proposed column for a new queen
	* @return Whether a diagonal from (newRow, newCol) is safe
	*/
bool Board::checkDiagonal(int newRow, int newCol) {
	if (row == -1 && col == -1) return true;
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
			if (chessboard[i][j] && abs(i-newRow) == abs(j-newCol)) return false;
		}
	}
	return true;
}

/**
	* printLine prints a horizontal line for the chessboard
	*/
void Board::printLine(void) {
	for (int i = 0; i < size*4+1; i++) {
		cout << "-";
	}
	cout << endl;
}

/**
	* printBoard prints the current chessboard,
	* and the number of solutions so far
	*
	* @param sols What number solution this board is
	*/
void Board::printBoard(int sols) {
	cout <<"Solution " << sols << ":" << endl;
	for (int i = 0; i < size; i++) {
		printLine();
		cout << "| ";
		for (int j = 0; j < size; j++) {
			if (chessboard[i][j]) cout << "X ";
			else cout << "  ";
			cout << "| ";
		}
		cout << endl;
	}
	printLine();
	cout << endl;
}

