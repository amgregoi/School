#ifndef NQUEENS_H
#define NQUEENS_H

class NQueens {
private:
	int boardSize;
	int numSols;
public:
	NQueens(int);
	void findSols(void);
};

#endif