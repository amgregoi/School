#include "Board.h"
#include <iostream>

#ifndef STACK_H
#define STACK_H

class Node {
public:
	Board* data;
	Node* next;
	Node(Board* d) {data = d; next = NULL;}
};

class Stack {
private:
	Node* top;
	int count;
public:
	Stack(void);
	~Stack();
	Board* pop(void);
	void push(Board*);
	int size(void);
};

#endif
