#include "NQueens.h"
#include "Stack.h"
#include "Board.h"
#include <iostream>

using namespace std;

/**
	* NQueens sets the size of the chessboard
	*
	* @param size The size of the (square) chessboard
	*/
NQueens::NQueens(int size) {
	boardSize = size;
	numSols = 0;
}

/**
	* queensStack displays all N-Queens solutions, using a stack.
	*/
void NQueens::findSols(void) {
	Stack* s = new Stack();
	Board* b = new Board(boardSize);
	s->push(b);

	while (s->size() != 0) {
		Board* cur = s->pop();
		if (cur->getQueens() == boardSize) {
			numSols++;
			cur->printBoard(numSols);
			delete cur;
		}
		else {
			for (int i = 0; i < boardSize; i++) {
				if (cur->checkCol(i) && cur->checkDiagonal(cur->getRow()+1, i)) {
					Board* newBoard = cur->duplicate();
					newBoard->move(cur->getRow()+1, i);
					s->push(newBoard);
				}
			}
		}
	}

	if (numSols == 0) {
		cout << "No " << boardSize << "-queen placement exists." << endl;
	}
	else {
		cout << endl << numSols << " total solutions." << endl;
	}

	while (s->size() > 0) {
		Board* b = s->pop();
		delete b;
	}

	delete s;
}