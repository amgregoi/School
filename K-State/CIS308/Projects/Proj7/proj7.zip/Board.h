#ifndef BOARD_H
#define BOARD_H

class Board {
private:
	bool** chessboard;
	int size;
	int row;
	int col;
	int numQueens;
	void printLine(void);
public:
	Board(int);
	~Board();
	Board* duplicate(void);
	int getQueens(void);
	int getRow(void);
	void move(int, int);
	bool checkCol(int);
	bool checkDiagonal(int, int);
	void printBoard(int);
};

#endif