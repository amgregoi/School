#include "Stack.h"

Stack::Stack(void) {
	top = NULL;
	count = 0;
}

Stack::~Stack() {
	while (count > 0) pop();
}

/**
	* pop removes and returns the object on the top of the stack
	*
	* @return The object on the top of the stack
	*/
Board* Stack::pop() {
	if (count == 0) return NULL;

	Board* val = top->data;
	Node* toDelete = top;
	top = top->next;
	delete toDelete;
	count--;
	return val;
}

/**
	* push puts x on the top of the stack
	*
	* @param x The data to put on the top of the stack
	*/
void Stack::push(Board* x) {
	Node* temp = top;
	top = new Node(x);
	top->next = temp;
	count++;
}

/**
	* size returns the number of elements on the stack
	*
	* @return The number of elements on the stack
	*/
int Stack::size() {
	return count;
}