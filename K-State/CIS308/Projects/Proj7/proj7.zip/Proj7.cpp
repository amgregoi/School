#include "NQueens.h"
#include <iostream>

using namespace std;

int main() {
	int size;
	cout << "Enter board size: ";
	cin >> size;
	cout << endl;

	NQueens q(size);
	q.findSols();

	system("PAUSE");
	return 0;
}