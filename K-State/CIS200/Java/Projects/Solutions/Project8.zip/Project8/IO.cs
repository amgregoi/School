// VIEW - Handles I/O only
// Andy Gregoire
using System;

public class IO {
	
/**
* Displays the menu
*
*/
	public void displayMenu() {
	  Console.WriteLine("\nPlease choose from the following choices below:");
      Console.WriteLine("\t1) Promotional Loan ($100,000 @ 5.5% for 15 years)");
      Console.WriteLine("\t2) Unique Loan (enter in loan values)");
      Console.WriteLine("\t3) Quit (Exit the program)");
      Console.Write("\n\tPlease enter your selection (1-3): ");	
	} // end displayMenu


/**
*  input - get and validate a menu choice	
*
* @return user intered choice for the menu
*/
	public int getMenuChoice() {
		int choice = -1;
		while (choice == -1) {
		 try {
			choice = Convert.ToInt32(Console.ReadLine());
			// validate choice
			while (choice > 3)
			{ Console.Write("\t\tInvalid Choice. Please select 1, 2, or 3: ");
			  choice = Convert.ToInt32(Console.ReadLine());
			} // end validate choice 1-3
		 } // end try
		 catch (FormatException) {
			   Console.Write("Input must be an integer.  Try again: ");
		 } // end catch
		} // end while not an int
		return choice;
	}

/**
*  Calculates interest rate	
*
* @return the calculated interest rate
*/
  public double getRate()
	{	double interestRate = -1;
		Console.WriteLine("\nPlease enter in the following information...");
		while (interestRate < 1 || interestRate > 9) {
			Console.Write("  Enter yearly interest rate (Ex: 8.25): ");
		 try {
			interestRate = Convert.ToDouble(Console.ReadLine());
			while (interestRate < 1 || interestRate > 9) {
				Console.WriteLine("\tValid Interest Rates are 1% - 9%");
				Console.Write("\tPlease re-enter valid yearly interest rate (Ex: 8.25): ");
				interestRate = Convert.ToDouble(Console.ReadLine());
			} // end while
		} // end try
		 catch (FormatException) {
		   Console.WriteLine("Input must be numeric only.  Try again...");
		 } // end catch
		} // end while not a double
		return interestRate;
	} // end getRate

/**
*  Read in and validate term of the loan (in years)	
*
* @return term
*/
  public int getTerm( )
	{	int years = -1;
		while (years < 5 || years > 50) {
			Console.Write("  Enter number of years for the loan (5-50): ");
		 try {
			years = Convert.ToInt32(Console.ReadLine());
			while (years < 5 || years > 50) {
				Console.WriteLine("\tValid Loan Terms are 5-50");
				Console.Write("\tPlease re-enter valid number of years: ");
				years = Convert.ToInt32(Console.ReadLine());
			} // end while
		 } // end try
		 catch (FormatException) {
		   Console.WriteLine("Input must be an integer.  Try again...");
		 } // end catch
		} // end while not an int
		return years;
	} // end getTerm


/**
*  Read in and validate loan amount	
*
* @return amount of the loan
*/
  public double getAmount( )
	{	double amount = 0;
		while (amount < 50000 || amount > 1000000) {
		Console.Write("  Enter loan amount without $ or commas (Ex:120000): ");
		 try {
			amount = Convert.ToDouble(Console.ReadLine());
			while (amount < 50000 || amount > 1000000) {
				Console.WriteLine("\tValid Loan Amounts are $50,000-$1,000,000");
				Console.Write("\tPlease re-enter loan amount without $ or commas (Ex:120000): ");
				amount = Convert.ToDouble(Console.ReadLine());
			} // end while
		  } // end try
		 catch (FormatException) {
		   Console.WriteLine("Input must be numeric only.  Try again...");
		 } // end catch
		} // end while not a double
		return amount;
	} // end getAmount
	
// ------------- Used to Display Loan Output, etc. ----------------
	public void displayString(String msg) {
		Console.WriteLine(msg); 
	}
} // end IO class