/**
 * Mortgage.java (MODEL)
 * Used to define a Mortgage object consisting of an annual interest rate,
 * the number of years for the loan and the loan amount. Contains methods to
 * calculate the monthly loan payment and the total amount paid.
 * Andy Gregoire
*/
using System;
public class Mortgage
{
  private double annualInterestRate;
  private int numOfYears;
  private double loanAmount;
  private double monthlyPayment;
  private double totalPayment;
  

  // Default constructor - sets a 100,000 loan at 5.5% for 15 years
  // Used for Advertised Promotion
  public Mortgage() // calls 3-arg constructor below
  {		
	annualInterestRate = 5.5;
    numOfYears = 15;
    loanAmount = 100000;
  } // end Mortgage() constructor

  // Construct a mortgage with specified annual interest rate,
  // number of years and loan amount
  public Mortgage(double newInterestRate, int newNumOfYears,
                  double newLoanAmount)
  { annualInterestRate = newInterestRate;
    numOfYears = newNumOfYears;
    loanAmount = newLoanAmount;
  } // end 3-argument constructor

// ------------------ Monthly Payment ---------------------
  // returns the value for the private data property monthlyPayment
  // currently not used...
  public double getMonthlyPayment()
  { return 	monthlyPayment;
  } // end getMonthlyPayment

  // Calculate and set the monthly payment for the loan
  public void setMonthlyPayment()
  { double monthlyInterestRate = annualInterestRate/1200;

	//double x = 1;
	monthlyPayment = loanAmount*monthlyInterestRate/(1 - ((double)Math.Pow(1/(1 + monthlyInterestRate), numOfYears*12)));
	 /* for(int i = 0; i< numOfYears*12; i++){
		x*= 1/(1 + monthlyInterestRate);
	  } */
	  
  } // end setMonthlyPayment

// ------------------ Total Payment ---------------------
  // returns the value for the private data property totalPayment
  // currently not used...
  public double getTotalPayment()
  { return 	totalPayment;
  } // end getMonthlyPayment

  // Calculate and set the total amount to be paid on the loan
  public void setTotalPayment()
  { totalPayment = monthlyPayment * numOfYears * 12;
  } // end totalPayment

// ------------------ Used to Display Output ---------------------
  public string toString()                                     
  { 
	string s = string.Format("The monthly payment is {0:$0,0.00} \nThe total payment is {1:$0,0.00}\n", monthlyPayment,totalPayment);
	return s;
  } // end toString

} // end class
