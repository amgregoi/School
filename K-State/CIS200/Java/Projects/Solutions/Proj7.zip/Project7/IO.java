// VIEW - Handles I/O only
import java.util.*;

public class IO {
	private Scanner s;
	
	public IO() {
		s = new Scanner(System.in); 
	}
	
// Displays the menu
	public void displayMenu() {
	  System.out.println("\nPlease choose from the following choices below:");
      System.out.println("\t1) Promotional Loan ($100,000 @ 5.5% for 15 years)");
      System.out.println("\t2) Unique Loan (enter in loan values)");
      System.out.println("\t3) Quit (Exit the program)");
      System.out.print("\n\tPlease enter your selection (1-3): ");	
	} // end displayMenu

// input - get and validate a menu choice	
	public int getMenuChoice() {
		int choice = -1;
		while (choice == -1) {
		 try {
			choice = Integer.parseInt(s.nextLine());
			// validate choice
			while (choice > 3)
			{ System.out.print("\t\tInvalid Choice. Please select 1, 2, or 3: ");
			  choice = Integer.parseInt(s.nextLine());
			} // end validate choice 1-3
		 } // end try
		 catch (NumberFormatException e) {
			   System.out.print("Input must be an integer.  Try again: ");
		 } // end catch
		} // end while not an int
		return choice;
	}

// Read in and validate interest rate
  public double getRate()
	{	double interestRate = -1;
		System.out.println("\nPlease enter in the following information...");
		while (interestRate < 1 || interestRate > 9) {
			System.out.print("  Enter yearly interest rate (Ex: 8.25): ");
		 try {
			interestRate = Double.parseDouble(s.nextLine());
			while (interestRate < 1 || interestRate > 9) {
				System.out.println("\tValid Interest Rates are 1% - 9%");
				System.out.print("\tPlease re-enter valid yearly interest rate (Ex: 8.25): ");
				interestRate = Double.parseDouble(s.nextLine());
			} // end while
		} // end try
		 catch (NumberFormatException e) {
		   System.out.println("Input must be numeric only.  Try again...");
		 } // end catch
		} // end while not a double
		return interestRate;
	} // end getRate

// Read in and validate term of the loan (in years)
  public int getTerm( )
	{	int years = -1;
		while (years < 5 || years > 50) {
			System.out.print("  Enter number of years for the loan (5-50): ");
		 try {
			years = Integer.parseInt(s.nextLine());
			while (years < 5 || years > 50) {
				System.out.println("\tValid Loan Terms are 5-50");
				System.out.print("\tPlease re-enter valid number of years: ");
				years = Integer.parseInt(s.nextLine());
			} // end while
		 } // end try
		 catch (NumberFormatException e) {
		   System.out.println("Input must be an integer.  Try again...");
		 } // end catch
		} // end while not an int
		return years;
	} // end getTerm

// Read in and validate loan amount
  public double getAmount( )
	{	double amount = 0;
		while (amount < 50000 || amount > 1000000) {
		System.out.print("  Enter loan amount without $ or commas (Ex:120000): ");
		 try {
			amount = Double.parseDouble(s.nextLine());
			while (amount < 50000 || amount > 1000000) {
				System.out.println("\tValid Loan Amounts are $50,000-$1,000,000");
				System.out.print("\tPlease re-enter loan amount without $ or commas (Ex:120000): ");
				amount = Double.parseDouble(s.nextLine());
			} // end while
		  } // end try
		 catch (NumberFormatException e) {
		   System.out.println("Input must be numeric only.  Try again...");
		 } // end catch
		} // end while not a double
		return amount;
	} // end getAmount
	
// ------------- Used to Display Loan Output, etc. ----------------
	public void displayString(String msg) {
		System.out.println(msg); 
	}
} // end IO class