import java.util.*;

public class Proj3Part3 {
	public static void main(String[] args) {
		Random r = new Random();

		int sum = 0;
		for (int i = 0; i < 10; i++) {
			int compScore = 0;
			int turnTotal = 0;
			int numTurns = 1;
			while (compScore < 20) {
				char option = ' ';
				System.out.print("\nComputer turn total is " + turnTotal + ". ");
				if (turnTotal >= 10) {
					option = 's';
					System.out.println("Computer stops.");
					numTurns++;
				}
				else {
					option = 'r';
					System.out.println("Computer rolls.");
				}

				if (option == 'r') {
					int roll = r.nextInt(6)+1;
					System.out.println("Computer rolled: " + roll);
					if (roll == 1) {
						System.out.println("Turn over.");
						System.out.println("Current score: Computer has " + compScore);
						turnTotal = 0;
						numTurns++;
					}
					else {
						turnTotal += roll;
					}
				}
				else {
					compScore += turnTotal;

					System.out.println("Turn over.");
					System.out.println("Current score: Computer has " + compScore);
					turnTotal = 0;
				}
			}
			System.out.println("\nGame over.  Computer took " + numTurns + " turns to reach 20 points\n\n");
			sum+=numTurns;
			numTurns = 0;
		}
		System.out.println("\nSimulation over.  Computer averaged " + sum/10.0 + " turns to reach 20 points");
	}
}