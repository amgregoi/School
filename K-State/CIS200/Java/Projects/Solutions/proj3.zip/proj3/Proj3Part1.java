import java.util.*;

public class Proj3Part1 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		Random r = new Random();

		//play to 20 points
		int score1 = 0;
		int score2 = 0;

		int turn = 1;

		int turnTotal = 0;
		while (score1 < 20 && score2 < 20) {
			System.out.print("\nPlayer " + turn + " turn total is " + turnTotal + ". Enter (r)oll or (s)top: ");
			char option = (s.nextLine()).charAt(0);
			if (option == 'r') {
				int roll = r.nextInt(6)+1;
				System.out.println("You rolled: " + roll);
				if (roll == 1) {
					System.out.println("Turn over.");
					System.out.println("Current score: Player 1 has " + score1 + ", Player 2 has " + score2);
					turn = (turn % 2) + 1;
					turnTotal = 0;
				}
				else {
					turnTotal += roll;
				}
			}
			else {
				if (turn == 1) score1 += turnTotal;
				else score2 += turnTotal;

				System.out.println("Turn over.");
				System.out.println("Current score: Player 1 has " + score1 + ", Player 2 has " + score2);
				turn = (turn % 2) + 1;
				turnTotal = 0;
			}
		}

		if (score1 >= 20) {
			System.out.println("Player 1 wins");
		}
		else {
			System.out.println("Player 2 wins");
		}
	}
}