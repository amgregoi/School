import java.util.*;

public class Proj3Part2 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		Random r = new Random();

		//play to 20 points
		int userScore = 0;
		int compScore = 0;

		int turn = 1;

		int turnTotal = 0;
		while (userScore < 20 && compScore < 20) {
			char option = ' ';
			if (turn == 1) {
				System.out.print("\nYour turn total is " + turnTotal + ". Enter (r)oll or (s)top: ");
				option = (s.nextLine()).charAt(0);
			}
			else {
				System.out.print("\nComputer turn total is " + turnTotal + ". ");
				if (turnTotal >= 10) {
					option = 's';
					System.out.println("Computer stops.");
				}
				else {
					option = 'r';
					System.out.println("Computer rolls.");
				}
			}
			if (option == 'r') {
				int roll = r.nextInt(6)+1;
				if (turn == 1) System.out.println("You rolled: " + roll);
				else System.out.println("Computer rolled: " + roll);
				if (roll == 1) {
					System.out.println("Turn over.");
					System.out.println("Current score: You have " + userScore + ", Computer has " + compScore);
					turn = (turn % 2) + 1;
					turnTotal = 0;
				}
				else {
					turnTotal += roll;
				}
			}
			else {
				if (turn == 1) userScore += turnTotal;
				else compScore += turnTotal;

				System.out.println("Turn over.");
				System.out.println("Current score: You have " + userScore + ", Computer has " + compScore);
				turn = (turn % 2) + 1;
				turnTotal = 0;
			}
		}

		if (userScore >= 20) {
			System.out.println("You win");
		}
		else {
			System.out.println("Computer wins");
		}
	}
}