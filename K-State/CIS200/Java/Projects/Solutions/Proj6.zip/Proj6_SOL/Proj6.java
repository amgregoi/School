/**
 * Proj5 gets two fractions and an operation from the user,
 * and displays the result
 */

import java.util.*;

public class Proj6 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		System.out.print("Enter the expression (like 2/3 + 3/4): ");
		String line = s.nextLine();
			// Split equation into first fraction, operator, second fraction
		StringTokenizer st = new StringTokenizer(line, " ");
		String first = st.nextToken();
		char op = (st.nextToken()).charAt(0);
		String second = st.nextToken();

			// Split first and second fraction into numeration and denominator
			// and create two fraction objects
		st = new StringTokenizer(first, "/");
		Fraction f1 = new Fraction(Integer.parseInt(st.nextToken()), Integer.parseInt(st.nextToken()));
		st = new StringTokenizer(second, "/");
		Fraction f2 = new Fraction(Integer.parseInt(st.nextToken()), Integer.parseInt(st.nextToken()));

		Fraction result = null;

		switch (op) {
			case '+':
				result = f1.plus(f2);	// 'plus' returns a reduced fraction object
				break;
			case '-':
				result = f1.minus(f2);	// 'minus' returns a reduced fraction object
				break;
			case '*':
				result = f1.times(f2);	// 'times' returns a reduced fraction object
				break;
			case '/':
				result = f1.divide(f2);	// 'divide' returns a reduced fraction object
				break;
			default:
				System.out.println("Invalid operator.");
		}

		if (result != null) {
			System.out.print("\n" + f1);		// calls the toString method
			System.out.print(" " + op + " ");
			System.out.print(f2);				// calls the toString method
			System.out.print(" = ");
			System.out.print(result);				// calls the toString method
			System.out.println();
		} // end if
	} // end main
} // end class