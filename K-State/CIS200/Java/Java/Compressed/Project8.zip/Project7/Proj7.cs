/* Proj7.java ... CONTROLLER

  Allows a bank officer to enter in all the input or use a
  special advertised promotion ($100,000 house loan for 15 years
  at the annual rate of 5.5%).
  
  Displays the monthly payment and the total amount paid on the loan
  
  Andy Gregoire
*/

using System;

public class MortgageDriver : IO
{
	
  public static void Main()
  { 
	MortgageDriver view = new MortgageDriver();
	int choice;

    do
    {
	  view.displayMenu();
      choice = view.getMenuChoice();

      if (choice == 1) //create a promotional loan
      { Mortgage promoLoan = new Mortgage();

	  // calc and set value for the monthly payment
		promoLoan.setMonthlyPayment();
        // calc and set value for the total payment
		promoLoan.setTotalPayment();

        // Display results with formatting
		view.displayString("\nPROMOTIONAL LOAN...:");
		view.displayString(promoLoan.toString());
      } // end promo loan

      else if (choice == 2) // Unique Loan Option
      { 

		// Read in and validate interest rate
		double interestRate = view.getRate();
		Console.WriteLine();	// display a blank line
		// Read in and validate term of the loan (in years)
		int years = view.getTerm();
		Console.WriteLine();	// display a blank line
		// Read in and validate loan amount
		double loanAmount = view.getAmount();
		Console.WriteLine();	// display a blank line

		// Create a Mortgage object
		Mortgage uniqueLoan = new Mortgage(interestRate, years, loanAmount);

        // calc and set value for the monthly payment
		uniqueLoan.setMonthlyPayment();
        // calc and set value for the total payment
		uniqueLoan.setTotalPayment();

		// Display results w/formatting
		view.displayString("\nUNIQUE LOAN...:");
		view.displayString(uniqueLoan.toString());
      } // end unqiue loan
  } while (choice != 3);

  view.displayString("\nPROGRAM COMPLETE...");
 }// end main
	
}//end MortgageDriver class
