public class Student {
	private String name;
    private String major;
	private int [ ] hours;
	private char [ ] grades;
	private int pos;
	
	public Student(String n, String m, int numCourses) {
		name = n;
		major = m;
		hours = new int [numCourses];
		grades = new char [numCourses];
		pos = 0;
	}
	
	public void addInfo (int h, char g) {
		if (pos >= hours.length) return;
		hours[pos] = h;
		grades[pos] = g;
		pos++;
	}

	// -	Calculate the GPA

	public String toString() {
	return ("\nName: " + name +
			"\nMajor: " + major +
			"\nGPA: " + calcGPA());
	}

	} // end class	
