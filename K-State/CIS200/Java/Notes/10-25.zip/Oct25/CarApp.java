/**************************************************************
* CarApp.java
* This class is a demonstration driver for the Car class.
**************************************************************/

public class CarApp
{
  public static void main(String[] args)
  {
    //Car nathanCar = new Car("Audi", 1998, "green");
    //Car nickCar = nathanCar.makeCopy();

	Car [ ] carArray = new Car [10];
	for (int j = 0; j < carArray.length; j++)
		carArray[j] = new Car();
	
    carArray[0] = new Car("Audi", 1998, "green");
    carArray[1] = carArray[0].makeCopy();
	carArray[1].setColor("red");

	//for (int i = 0; i < carArray.length; i++)
	int i = 0;
	while (carArray[i] != null)
	{
		System.out.println("\nCar " + (i+1) + ": " + carArray[i]);
		i++;
	}


		//nathanCar.display();

    //System.out.println("\nNick's Car:" + nickCar);
    //nickCar.display();

/*
    if (nathanCar.equals(nickCar))
    {
      System.out.println("\nCars have identical features.");
    }
    else {
      System.out.println("\nCars do NOT have identical features.");
    }
*/
	} // end main
} // end class CarApp