import java.util.*;

public class Bad {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		double sum;
		System.out.print("Enter a number: ");
		double num1 = Double.parseDouble(scan.nextLine());
		System.out.print("Enter another number: ");
		double num2 = Double.parseDouble(scan.nextLine());
		sum = num1 + num2;
		System.out.println("The answer is " + sum);
	}
}