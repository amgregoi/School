import java.util.*;
import java.text.*;

public class Aug24 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		DecimalFormat df = new DecimalFormat("#0.00");
		
		//reverse the sign of a number
		/*
		System.out.print("Enter a number with a decimal: ");
		double val = Double.parseDouble(s.nextLine());
		
		val *= -1;
		System.out.println("Reversed sign: " + val);*/
		
		//get three whole numbers, print the average
		/*System.out.print("Enter number: ");
		int num1 = Integer.parseInt(s.nextLine());
		System.out.print("Enter number: ");
		int num2 = Integer.parseInt(s.nextLine());
		System.out.print("Enter number: ");
		int num3 = Integer.parseInt(s.nextLine());
		
		double avg = (num1+num2+num3)/3.0;
		System.out.println("Average: " + df.format(avg));*/
		
		//get number, print digits
		System.out.print("Enter a 3-digit number: ");
		int num = Integer.parseInt(s.nextLine());
		int dig1 = num % 10;
		num = num / 10;
		int dig2 = num % 10;
		num = num / 10;
		int dig3 = num;
		
		System.out.println(dig1 + " " + dig2 + " " + dig3);
		
	//	123 % 10 = 3
	//	123 / 10 = 12
		
	}
}