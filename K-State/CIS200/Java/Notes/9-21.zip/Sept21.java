import java.util.*;

public class Sept21 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		//reverse array
		/*int[] nums = new int[10];
		for (int i = 0; i < nums.length; i++) {
			System.out.print("Enter number: ");
			nums[i] = Integer.parseInt(s.nextLine());
		}
		
		//code here to reverse
		int front = 0;
		int back = nums.length-1;
		
		while (front < back) {
			//swap current front and back
			int temp = nums[front];
			nums[front] = nums[back];
			nums[back] = temp;
			
			front++;
			back--;
		}
		
		for (int i = 0; i < nums.length; i++) {
			System.out.print(nums[i]);
		}*/
		
		//gpa calc
		/*System.out.print("How many courses? ");
		int size = Integer.parseInt(s.nextLine());
		
		char[] grades = new char[size];
		int[] hours = new int[size];
		
		for (int i = 0; i < size; i++) {
			System.out.print("Hours for course " + (i+1) + ": ");
			hours[i] = Integer.parseInt(s.nextLine());
			System.out.print("Grade for course " + (i+1) + ": ");
			grades[i] = (s.nextLine()).charAt(0);
		}
		
		int totalPoints = 0;
		int totalHours = 0;
		for (int i = 0; i < size; i++) {
			totalHours += hours[i];
			int pointVal = 0;
			switch (grades[i]) {
				case 'A':
					pointVal = 4;
					break;
				case 'B':
					pointVal = 3;
					break;
				case 'C':
					pointVal = 2;
					break;
				case 'D':
					pointVal = 1;
					break;
			}
			totalPoints += pointVal*hours[i];
		}
		
		System.out.println("GPA: " + totalPoints/(double)totalHours);
		*/
		
		//binary search
		int[] nums = {1,2,5,6,8,9,14,20,25};
		
		System.out.print("Enter number to find: ");
		int val = Integer.parseInt(s.nextLine());
		
		//want to print index of val in nums
		//OR that we couldn't find it
		
		int front = 0;
		int back = nums.length-1;
		boolean found = false;
		
		while (front <= back) {
			int mid = (front+back)/2;
			
			if (nums[mid] < val) front = mid+1;
			else if (nums[mid] > val) back = mid-1;
			else {
				System.out.println("Found at index: " + mid);
				found = true;
				break;
			}
		}
	
		if (found == false) {
			System.out.println("Element is not in the array");
		}
	}
}