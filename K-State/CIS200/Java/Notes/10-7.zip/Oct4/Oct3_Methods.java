import java.util.*;
import java.io.*;

public class Oct4_Solution {
	public static void main(String[] args) throws IOException {
		Scanner s = new Scanner(System.in);

		String response;
		char choice;

		do {
        	System.out.println("D)isplay a text file");
        	System.out.println("C)reate a text file");
        	System.out.println("Q)uit");
			System.out.print("Choose an option: ");
        	response = s.nextLine();
			choice = response.charAt(0);

			switch(choice)
			{
			case 'D': case 'd': displayFile();
								break;

			case 'C': case 'c': createFile();
								break;

			case 'Q': case 'q': System.out.println("Goodbye!");
								break;

			default: System.out.println("Invalid Choice");
			} // end case
		} while (choice != 'Q' && choice != 'q');

 } // end main

public static void displayFile () throws IOException
{
		Scanner s = new Scanner(System.in);
		String fileName;
		System.out.print("Enter in path and filename of your text file: ");
        fileName = s.nextLine();
		fileName += ".txt";
		Scanner inFile = new Scanner (new File(fileName));

		while (inFile.hasNext()) {
			String line = inFile.nextLine();
			System.out.println(line);
			}

		inFile.close();
} // end displayFile

public static void createFile () throws IOException
{
// Creates a textfile of entered input
	Scanner s = new Scanner(System.in);
	PrintWriter pw = new PrintWriter(new FileWriter("testFile.txt"));

	System.out.println ("Enter in text below ... enter '/' to end input");
	String line;

	do {	line = s.nextLine();
        	if (line.equals(""))
        	{   line=" ";
				pw.println();
			}
            else if (line.charAt(0) != '/')
			    pw.println(line);
	} while (line.charAt(0) != '/');

	pw.close();
} // end createFile

} // end class
