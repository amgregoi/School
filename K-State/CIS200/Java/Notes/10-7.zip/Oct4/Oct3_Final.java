import java.util.*;
import java.io.*;

public class Oct3_Solution {
	public static void main(String[] args) throws IOException {
		Scanner s = new Scanner(System.in);

		String fileName;
		System.out.print("Enter in path and filename of your text file: ");
        fileName = s.nextLine();
		fileName += ".txt";
		Scanner inFile = new Scanner (new File(fileName));

		while (inFile.hasNext()) {
			String line = inFile.nextLine();
			System.out.println(line);
			}

		inFile.close();

// Creates a textfile of entered input
	PrintWriter pw = new PrintWriter(new FileWriter("testFile.txt"));

	System.out.println ("Enter in text below ... enter '/' to end input");
	String line;

	do {	line = s.nextLine();
        	if (line.equals(""))
        	{   line=" ";
				pw.println();
			}
            else if (line.charAt(0) != '/')
			    pw.println(line);
	} while (line.charAt(0) != '/');

	pw.close();
 } // end main
} // end class
