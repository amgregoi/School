/*
 File name: TempConvert.java
 This program does the following:
   * Prompts the user to enter a temperature in degrees Fahrenheit
   * Converts the user's input to degrees Celsius
   * Displays the Celsius temperature

*/

import java.util.Scanner;

public class Oct4_TempConvert
{
  public static void main(String[] args) {
      //declare variables

      //Get user input and store it in variable

      // call method to convert the temperature to degrees Celsius
 
     // display output
 
  } //end of method main

 // method to convert farenheit to Celsius
 
 
} //end class TempConvert
