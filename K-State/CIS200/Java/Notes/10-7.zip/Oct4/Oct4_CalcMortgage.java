public class Oct4_CalcMortgage {
	public static void main(String[] args) {

		double loanAmount = 100000;		// $100,000 Loan
		double interestRate = 5.5;  	// @ 5.5%
		int years = 25;					// for 25 years
		
		interestRate /= 100;  		// convert to decimal
			// formula requires a MONTHLY interest rate to get a MONTHLY payment
		interestRate /= 12;  		

		double monthlyPayment =  calcMonthlyPayment (loanAmount, interestRate, years);
		
		// Unformatted Output ... use DecimalFormat to format
		System.out.println("Monthly Payment = " + monthlyPayment);
 
} // end main
		
	public static double calcMonthlyPayment(double loan, double rate, int yr)
	{   double num1 = loan*rate;
	    double num2 = (1-(Math.pow(1/(1+rate),yr*12)));
	    return (num1/num2);
	} // end method calcMonthlyPayment

} // end class
