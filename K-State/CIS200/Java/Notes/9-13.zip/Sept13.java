import java.util.*;

public class Sept13 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		//nested loop #1
		/*
		Outer loop: steps through 5 rows
			Inner loop: steps from 1-4, print
		*/
		
		/*
		for (int i = 0; i < 5; i++) {
			for (int j = 1; j <= 4; j++) {
				System.out.print(j + " ");
			}
			System.out.println();
		}
		*/
		
		//nested loop triangle
		/*for (int i = 0; i < 4; i++) {
			for (int j = 1; j <= i+1; j++) {
				System.out.print(j + " ");
			}
			System.out.println();
		}*/
		
		//another nested loop triangle
		
		//i is the number I start printing from
		//on the current row
		for (int i = 10; i >= 2; i-=2) {
			for (int j = i; j >= 2; j-=2) {
				System.out.print(j + " ");
			}
			System.out.println();
		}
	}
}