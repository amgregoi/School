using System;
using System.IO;

public class Example3 {
  public static void Main() {
/*    
	// writing to a file
	Console.Write("Enter filename: ");
	string fileName = Console.ReadLine();
	
	StreamWriter sw = new StreamWriter(fileName);
	
	// write names and quizScores to file
	Console.WriteLine("Creating file...\n");
	sw.WriteLine("Bob:10");
	sw.WriteLine("Jane:5");
	sw.WriteLine("Mary:12");
	sw.WriteLine("Fred:18");
	sw.WriteLine("Lisa:16");
	sw.WriteLine("Joe:8");
	
	sw.Close();
	
	// reading from a file
	Console.WriteLine("Verifying file contents:");
	StreamReader sr = new StreamReader(fileName);
	
	string line = sr.ReadLine();
	// check to see if line is null
	while ( line != null) {
		Console.WriteLine(line);
		line = sr.ReadLine();
	} // end while

	sr.Close();
*/

	// parse quizscores.txt to determine average, high score, pass/fail
	int highscore = -1;
	int totalscore = 0;
	int count = 0;
	
	Console.Write("Enter filename: ");
	string fileName = Console.ReadLine();
	StreamReader sr = new StreamReader (fileName);
	StreamWriter sw = new StreamWriter("results.txt");

	sw.WriteLine("\nQuiz Summary:");
	string line = sr.ReadLine();
	while (line != null) {
		string [ ] tokens = line.Split(':');
		int score = Convert.ToInt32(tokens[1]);
		count++;
		totalscore += score;
		if (score > highscore) 
			highscore = score;
		sw.Write("\t"+tokens[0]+"\t"+tokens[1]);
		if (score >= 14)
			sw.WriteLine("\t*Pass*");
		else
			sw.WriteLine("\tFailed");
			
		line = sr.ReadLine();
	} // end while
	
	sw.WriteLine("\nHigh Score: " + highscore);
	sw.WriteLine("Average: {0:F}", (double) totalscore / count);

	sr.Close();
	sw.Close();

	} // end Main
} // end class