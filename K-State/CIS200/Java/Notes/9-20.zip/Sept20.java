import java.util.*;

public class Sept20 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		//break example
		/*int sum = 0;
		for (int i = 0; i < 10; i++) {
			System.out.print("Enter number: ");
			int num = Integer.parseInt(s.nextLine());
			if (num == 0) break;
			sum += num;
		}
		
		System.out.println("Sum is: " + sum);*/
		
		//continue example
		/*int sum = 0;
		for (int i = 0; i < 10; i++) {
			System.out.print("Enter number: ");
			int num = Integer.parseInt(s.nextLine());
			if (num < 0) {
				i--;
				continue;
			}
			sum += num;
		}
		
		System.out.println("Sum is: " + sum);*/
		
		//array: get 10 numbers, print in reverse
		/*int[] nums = new int[10];
		for (int i = 0; i < nums.length; i++) {
			System.out.print("Enter number: ");
			nums[i] = Integer.parseInt(s.nextLine());
		}
		
		for (int i = nums.length-1; i >= 0; i--) {
			System.out.println(nums[i]);
		}*/
		
		//count Bs
		/*int[] nums = new int[10];
		for (int i = 0; i < nums.length; i++) {
			System.out.print("Enter test score: ");
			nums[i] = Integer.parseInt(s.nextLine());
		}
		
		int count = 0;
		for (int i = 0; i < nums.length; i++) {
			if (nums[i] >= 80 && nums[i] <= 89) {
				count++;
			}
		}
		
		System.out.println("Bs: " + count);*/
		
		//reverse array
		int[] nums = new int[10];
		for (int i = 0; i < nums.length; i++) {
			System.out.print("Enter number: ");
			nums[i] = Integer.parseInt(s.nextLine());
		}
		
		//code here to reverse
		int front = 0;
		int back = nums.length-1;
		
		while (do until halfway through) {
			//swap current front and back
			int temp = nums[front];
			nums[front] = nums[back];
			nums[back] = temp;
			
			front++;
			back--;
		}
		
		for (int i = 0; i < nums.length; i++) {
			System.out.print(nums[i]);
		}
	}
}