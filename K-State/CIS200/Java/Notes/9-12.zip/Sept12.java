import java.util.*;

public class Sept12 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		//sum numbers until a 0
		/*int sum = 0;
		int num;
		do {
			System.out.print("Enter number: ");
			num = Integer.parseInt(s.nextLine());
			if (num != -1) sum += num;
		} while (num != -1);
		
		System.out.println("Sum is: " + sum);*/
		
		//factorial with while loop
		/*System.out.print("Enter number: ");
		int num = Integer.parseInt(s.nextLine());
		
		if (num >= 0) {
			int cur = num;
			int product = 1;
			
			//loop through numbers to multiply
			while (cur >= 1) {
				product *= cur;
				cur--;
			}
			
			System.out.println(num + "! = " + product);
		}
		else {
			System.out.println("Number shouldn't be negative");
		}*/
		
		//min/max/avg
		
		int sum = 0;
		int min = 0; //smallest so far
		int max = 0; //biggest so far
		for (int i = 0; i < 10; i++) {
			System.out.print("Enter number: ");
			int num = Integer.parseInt(s.nextLine());
			
			if (i == 0) {
				min = num;
				max = num;
			}
			if (num < min) {
				min = num;
			}
			if (num > max) {
				max = num;
			}
			
			sum += num;
		}
		
		double avg = sum / 10.0;
		System.out.println("Average is: " + avg);
		System.out.println("Min is: " + min);
		System.out.println("Max is: " + max);
	}
}