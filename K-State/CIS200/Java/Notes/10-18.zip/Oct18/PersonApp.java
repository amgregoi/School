import java.util.*;

public class PersonApp {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		//create person Bob Smith, age 20, 515-00-9999 (Hardcode)
		Person pers1 = new Person("Bob Smith", 20, "515-00-9999");
		
		//create person ... read in info vs. hardcoding
		System.out.print("Enter name: ");
		String name = s.nextLine();
		System.out.print("Enter age: ");
		int age =Integer.parseInt(s.nextLine());
		System.out.print("Enter Social Security number (####-##-####): "); 
		String ss = s.nextLine();
		Person pers2 = new Person(name, age, ss);

		//display pers1
		pers1.display();
		
		//display pers2
		pers2.display();

	} // end main
} // end PersonApp