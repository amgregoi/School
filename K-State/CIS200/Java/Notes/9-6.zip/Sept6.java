import java.util.*;

public class Sept6 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		//dice game
		/*Random r = new Random();
		
		int comp1 = r.nextInt(6)+1;
		int comp2 = r.nextInt(6)+1;
		int user1 = r.nextInt(6)+1;
		int user2 = r.nextInt(6)+1;
		
		int compTotal = comp1+comp2;
		int userTotal = user1+user2;
		
		System.out.println("User rolls: " + user1 + " and " + user2);
		System.out.println("Computer rolls: " + comp1 + " and " + comp2);
		
		if (comp1 == comp2 && user1 == user2) {
			if (userTotal >= compTotal) {
				System.out.println("User wins");
			}
			else {
				System.out.println("Computer wins");
			}
		}
		//only the user rolled doubles
		else if (user1 == user2) {
			System.out.println("User wins");
		}
		//only computer rolled doubles
		else if (comp1 == comp2) {
			System.out.println("Computer wins");
		}
		else {
			//no doubles
			if (userTotal >= compTotal) {
				System.out.println("User wins");
			}
			else {
				System.out.println("Computer wins");
			}
		}*/

		//grade description
		System.out.print("Enter letter grade: ");
		char grade = (s.nextLine()).charAt(0);
		
		switch (grade) {
			case 'a':
			case 'A':
				System.out.println("Excellent");
				break;
			case 'b':
			case 'B':
				System.out.println("Above average");
				break;
			case 'c':
			case 'C':
				System.out.println("Average");
				break;
			case 'd': case 'D':
				System.out.println("Below average");
				break;
			case 'f': case 'F':
				System.out.println("Failure");
				break;
			default:
				System.out.println("Enter a valid letter grade");
				break;
		}
	}
}