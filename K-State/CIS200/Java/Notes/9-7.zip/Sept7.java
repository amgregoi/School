import java.util.*;

public class Sept7 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		//odds from 1-100
		/*int cur = 1;
		while (cur <= 100) {
			System.out.println(cur);
			cur+=2;
		}*/
		
		//add 10 numbers from user
		/*int cur = 1;
		int sum = 0;
		while (cur <= 10) {
			System.out.print("Enter number: ");
			int num = Integer.parseInt(s.nextLine());
			sum += num;
			cur++;
		}
		
		System.out.println("Sum is: " + sum);*/
		
		//exponent
		/*System.out.print("Enter base: ");
		int base = Integer.parseInt(s.nextLine());
		System.out.print("Enter exponent: ");
		int exp = Integer.parseInt(s.nextLine());
		
		if (exp >= 0) {
		
			int answer = 1;
			int counter = 0;
			while (counter < exp) {
				answer *= base;
				counter++;
			}
			
			System.out.println(base + "^" + exp + " = " + answer);
		}
		else {
			System.out.println("No negative exponents");
		}*/
		
		//prime test
		/*System.out.print("Enter an integer, 2 or bigger: ");
		int num = Integer.parseInt(s.nextLine());
		
		int check = 2;
		boolean prime = true;
		while (check < num) {
			//does check divide in evenly to num?
			if (num % check == 0) {
				//not prime
				prime = false;
			}
			check++;
		}
		
		if (prime == true) {
			System.out.println("prime");
		}
		else {
			System.out.println("not prime");
		}*/
		
		//control loop with number
		int num = 0;
		char option;
		do {
			System.out.print("\nEnter (a)dd, (s)ubtract, (p)rint, or (q)uit: ");
			option = (s.nextLine()).charAt(0);
			switch (option) {
				case 'a':
					num++;
					break;
				case 's':
					num--;
					break;
				case 'p':
					System.out.println(num);
					break;
			}
		} while (option != 'q');
	}
}