import java.util.*;

public class Aug31 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		//temperature converter
		/*System.out.print("Enter temperature: ");
		double temp = Double.parseDouble(s.nextLine());
		System.out.print("Enter unit (f or c): ");
		char unit = (s.nextLine()).charAt(0);
		
		double newTemp;
		if (unit == 'f' || unit == 'F') {
			newTemp =(5.0/9)*(temp-32);
			System.out.println("Converted temperature: " 
							+ newTemp);
		}
		else if (unit == 'c' || unit == 'C') {
			newTemp = (9.0/5)*temp + 32;
			System.out.println("Converted temperature: " 
							+ newTemp);
		}
		else {
			System.out.println("Bad unit.");
		}
		*/
		
		//smallest of three
		/*System.out.print("Enter number: ");
		int num1 = Integer.parseInt(s.nextLine());
		System.out.print("Enter number: ");
		int num2 = Integer.parseInt(s.nextLine());
		System.out.print("Enter number: ");
		int num3 = Integer.parseInt(s.nextLine());
		
		if (num1 <= num2 && num1 <= num3) {
			System.out.println("Smallest: " + num1);
		}
		else if (num2 <= num1 && num2 <= num3) {
			System.out.println("Smallest: " + num2);
		}
		else {
			//num3 is smallest
			System.out.println("Smallest: " + num3);
		}
		*/
		
		//two dice rolls
		Random r = new Random();
		/*int dice1 = r.nextInt(6)+1;
		int dice2 = r.nextInt(6)+1;
		
		System.out.println("Roll one: " + dice1);
		System.out.println("Roll two: " + dice2);*/
		
		//magic 8 ball
		System.out.print("What is your question? ");
		String question = s.nextLine();
		
		int num = r.nextInt(5);
		
		if (num == 0) {
			System.out.println("Yes");
		}
		else if (num == 1) {
			System.out.println("Outlook not so good");
		}
		else if (num == 2) {
			System.out.println("Ask again later");
		}
		else if (num == 3) {
			System.out.println("Possibly so");
		}
		else {
			//num must be 4
			System.out.println("No");
		}
	}
}