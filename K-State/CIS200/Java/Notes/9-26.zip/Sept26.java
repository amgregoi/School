import java.util.*;

public class Sept26 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		char[][] board = new char[3][3];
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				board[i][j] = '_';
			}
		}
		
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				System.out.print(board[i][j] + " ");
			}
			System.out.println();
		}
		
		int count = 0;
		char turn = 'X';
		while (count < 9) {
			System.out.print("\nEnter row: ");
			int row = Integer.parseInt(s.nextLine());
			System.out.print("Enter column: ");
			int col = Integer.parseInt(s.nextLine());
			
			if (row < 0 || col < 0 || 
				row > 2 || col > 2) {
					System.out.println("Indices should be 0-2");
			}
			else if (board[row][col] != '_') {
				System.out.println("That spot is taken.");
			}
			else {
				board[row][col] = turn;
			
				for (int i = 0; i < 3; i++) {
					for (int j = 0; j < 3; j++) {
						System.out.print(board[i][j] + " ");
					}
					System.out.println();
				}
				
				//check for a winner
				
				for (int i = 0; i < 3; i++) {
					if (board[i][0] == board[i][1] &&
						board[i][0] == board[i][2] &&
						board[i][0] == turn) {
					
						System.out.println(turn + " wins!");
						return;
					}
					if (board[0][i] == board[1][i] &&
						board[0][i] == board[2][i] &&
						board[0][i] == turn) {
					
						System.out.println(turn + " wins!");
						return;
					}
				}
				
				if (board[0][0] == board[1][1] &&
					board[0][0] == board[2][2] &&
					board[0][0] == turn) {
				
					System.out.println(turn + " wins!");
					return;
				}
				
				if (board[0][2] == board[1][1] &&
					board[0][2] == board[2][0] &&
					board[0][2] == turn) {
				
					System.out.println(turn + " wins!");
					return;
				}
			
				if (turn == 'X') turn = 'O';
				else turn = 'X';
				count++;
			}
		}
		
		System.out.println("Tie game");
	}
}