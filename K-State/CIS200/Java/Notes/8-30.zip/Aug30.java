import java.util.*;

public class Aug30 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		//can they vote
		/*System.out.print("Enter your age: ");
		int age = Integer.parseInt(s.nextLine());
		
		if (age >= 18) {
			System.out.println("You can vote!");
		}
		
		System.out.println("Goodbye!");*/
		
		//letter grade feedback
		/*System.out.print("Enter your letter grade: ");
		char grade = (s.nextLine()).charAt(0);
		
		if (grade == 'A' || grade == 'B' || 
				grade == 'a' || grade == 'b') {
			System.out.println("Good job");
		}*/
		
		//25% off
		/*System.out.print("Enter cost: ");
		double cost = Double.parseDouble(s.nextLine());
		
		if (cost >= 0) {
			cost = cost * 0.75;
			System.out.println("25% off: $" + cost);
		}
		else System.out.println("Cost shouldn't be negative.");*/
		
		//find the smallest of two numbers
		/*System.out.print("Enter number: ");
		int num1 = Integer.parseInt(s.nextLine());
		System.out.print("Enter number: ");
		int num2 = Integer.parseInt(s.nextLine());
		
		if (num1 < num2) {
			System.out.println("Smallest: " + num1);
		}
		else {
			System.out.println("Smallest: " + num2);
		}*/
		
		//even/odd
		/*System.out.print("Enter number: ");
		int num = Integer.parseInt(s.nextLine());
		
		if (num % 2 == 0) {
			System.out.println("even");
		}
		else {
			System.out.println("odd");
		}*/
		
		//letter grade
		/*System.out.print("Enter exam score: ");
		int score = Integer.parseInt(s.nextLine());
		
		if (score >= 90) {
			System.out.println("A");
		}
		else if (score >= 80) {
			System.out.println("B");
		}
		else if (score >= 70) {
			System.out.println("C");
		}
		else if (score >= 60) {
			System.out.println("D");
		}
		else if (score >= 0) {
			System.out.println("F");
		}
		else {
			System.out.println("Test scores shouldn't be negative");
		}*/
		
		int num;
		System.out.print("Enter value: ");
		int value = Integer.parseInt(s.nextLine());
		if (value >= 0) {
			num = 1;
		}
		else {
			num = 2;
		}
		
		System.out.println(num);
	}
}