import java.util.*;
import java.io.*;

public class Sept28 {
	public static void main(String[] args) throws IOException {
		Scanner s = new Scanner(System.in);
		
		//Caesar cipher
		/*System.out.print("Enter message: ");
		String msg = s.nextLine();
		System.out.print("Enter (e)ncrypt or (d)ecrypt: ");
		char eOrD = (s.nextLine()).charAt(0);
		String alpha = "abcdefghijklmnopqrstuvwxyz";
		
		if (eOrD == 'e') {
			String[] words = msg.split(" ");
			for (int i = 0; i < words.length; i++) {
				//go through the letters of the current word
				for (int j = 0; j < (words[i]).length(); j++) {
					String cur = (words[i]).substring(j,j+1);
					int index = alpha.indexOf(cur);
					index = (index + 3) % 26;
					System.out.print(alpha.charAt(index));
				}
				System.out.print(" ");
			}
			System.out.println();
		}
		else {
			String[] words = msg.split(" ");
			for (int i = 0; i < words.length; i++) {
				//go through the letters of the current word
				for (int j = 0; j < (words[i]).length(); j++) {
					String cur = (words[i]).substring(j,j+1);
					int index = alpha.indexOf(cur);
					index = (index - 3 + 26) % 26;
					System.out.print(alpha.charAt(index));
				}
				System.out.print(" ");
			}
			System.out.println();
		}*/
		
		//file input
		Scanner inFile = new Scanner(new File("nums.txt"));
		int sum = 0;
		while (inFile.hasNext()) {
			String line = inFile.nextLine();
			String[] pieces = line.split(" ");
			for (int i = 0; i < pieces.length; i++) {
				sum += Integer.parseInt(pieces[i]);
			}
		}
		
		System.out.println("Sum is: " + sum);
		inFile.close();
	}
}