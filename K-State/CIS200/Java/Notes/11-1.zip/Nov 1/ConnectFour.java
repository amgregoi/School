// CONTROLLER - handles communication between model-view
public class ConnectFour {
	public static void main(String[] args) {
		Board b = new Board();
		IO view = new IO();
		view.printBoard(b.toString());
		
		char piece = 'X';
		
		//loop through game play (while board is NOT full)
		while (b.full() == false) {
			int move = view.getMove(piece);
			// false means 'bad move'
			boolean result = b.move(move, piece);
			
			if (result == false) {
				view.printResults("Bad move, try again.");
			}
			else { // returns board as a String
				view.printBoard(b.toString()); 
				result = b.winner(piece); // test if a winner
				if (result == true) {
					view.printResults(piece + " wins!");
					return; // Where does this return to?
				}
				
				if (piece == 'X') piece = 'O';
				else piece = 'X';
			}
		}
		
		view.printResults("Tie game.");
	}
}