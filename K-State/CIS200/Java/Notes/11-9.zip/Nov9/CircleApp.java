// Dynamic Data Types: ArrayLists
// TestCircle.java: Demonstrate creating and using an Array of Circle objects
//                  vs. an ArrayList of Circles

import java.util.*;   // Must import for Scanner and ArrayList classes

public class CircleApp
{
  public static void main(String[] args)
  {    Scanner in = new Scanner (System.in);

// Create an ARRAY that will hold up to 50 Circle objects
    Circle [ ] circleArray = new Circle[50];
    int index = 0;   // used for array index

// Read in radii for circles until user enters -1
// Instantiate each object within the loop
    double temp;   // holds the radius
    System.out.println("Enter in info into the ARRAY (up to 50)...");
    do
    { System.out.print("\tEnter in radius of new circle (-1 to end): ");
      temp = in.nextDouble();
      if (temp != -1)
      { // Instantiate circles with default radius
          circleArray[index] = new Circle();
          circleArray[index].setRadius(temp);
        } //end if
      index++;      // increase subscript index
    } while (temp != -1); // end do-while

// Display radius and area of each circle
    System.out.println("");
    for (int i = 0; i < (index-1); i++)
    {System.out.println("The area of a circle " + (i+1) + " with radius "
        + circleArray[i].getRadius() + " is " + circleArray[i].findArea());
    } // end for

    System.out.println("\nEnter in info into the ARRAYLIST (unlimited)...");
// Create an ARRAYLIST with initial size of 2 objects
    int initialSize = 2;
    ArrayList <Circle> circleArrayList = new ArrayList<Circle> (initialSize);

// Reminder : value of circleArrayList.size() is ZERO (not 2)
// size() holds the number of CURRENT elements in ArrayList
    System.out.println("Current SIZE of the ArrayList: "
                                   + circleArrayList.size());

// Intantiate 'size' number of circle objects and add to the arraylist
    for (int i = 0; i < initialSize; i++)
    {  // Instantiate circles with default radius
      circleArrayList.add(new Circle());
    } // end for

// read in Radius for the 'numCircles' objects
    for (int i = 0; i < initialSize; i++)
    {System.out.print("\tEnter in radius of circle #" + (i+1) + ": ");
		circleArrayList.get(i).setRadius(in.nextDouble());
    } // end for


// Can now use size() to control the loop
    for (int i = 0; i < circleArrayList.size(); i++)
    {System.out.println("The area of a circle " + (i+1) + " with radius "
        + ((Circle) circleArrayList.get(i)).getRadius() + " is "
        + ((Circle) circleArrayList.get(i)).findArea());
    } // end for

    System.out.println("\nCurrent SIZE of the ArrayList: "
                                      + circleArrayList.size());

   System.out.println("Enter additional info into the ARRAYLIST...\n");
// use a while loop to add elements to the ArrayList
    double tempRadius = -1;
    do
    {System.out.print("\tEnter in radius of new circle (-1 to end): ");
     tempRadius = in.nextDouble();
     if (tempRadius != -1)   // create new circle object and add to ArrayList
     { int i = circleArrayList.size();
       circleArrayList.add(new Circle());
       ((Circle) circleArrayList.get(i)).setRadius(tempRadius);
     }//end if
    } while (tempRadius != -1);

// Can again use size() to control the loop
    for (int i = 0; i < circleArrayList.size(); i++)
    {System.out.println("The area of a circle " + (i+1) + " with radius "
        + circleArrayList.get(i).getRadius() + " is "
        + circleArrayList.get(i).findArea());
    } // end for

    System.out.println("\nFinal SIZE of the ArrayList: "
                                + circleArrayList.size());
    System.out.println("\nProgram complete...");
  } // end main
} // end class CircleApp
