public class Circle
{
  private double radius;

  // Default constructor
  public Circle()
  {
    radius = 1.0;
  }

  // Construct a circle with a specified radius
  public Circle(double r)
  {
    radius = r;
  }

   // Getter method for radius
  public double getRadius()
  {
    return radius;
  }

   // setter method for radius
  public void setRadius(double r)
  {
    radius=r;
  }

  // Find circle area
  public double findArea()
  {
    return radius*radius*Math.PI;
  }
}
