/**
 * AssignGrade.java
 * Reads in the scores of "numOfStudents" (entered in by user)
 * determines the high score, and then assigns grades based on
 * a grading curve
 */

 import java.util.Scanner;
 
public class AssignGrade
{public static void main(String[] args)
  {	Scanner s = new Scanner(System.in);
	int numOfStudents = 0; // The number of students
    int high = 0;          // The high score
    char grade;            // The student's grade
    int[] scores;          // Array of student scores
 
    // Get number of students
    System.out.print("Please enter number of students: ");
    numOfStudents = Integer.parseInt(s.nextLine());

    // Create array scores
    scores = new int[numOfStudents];

    // Read scores and find the high score
    System.out.println("Please enter " + numOfStudents + " scores below");
    for (int i=0; i<scores.length; i++)
    { scores[i] = Integer.parseInt(s.nextLine());
      if (scores[i] > high)
        high = scores[i];
    }//end for

    // Assign and display grades
    for (int i=0; i<scores.length; i++)
    { int tempScore = scores[i];
	  if (tempScore >= high - 10)
        grade = 'A';
      else if (tempScore >= high - 20)
        grade = 'B';
      else if (tempScore >= high - 30)
        grade = 'C';
      else if (tempScore >= high - 40)
        grade = 'D';
      else
        grade = 'F';

      System.out.println("Student " + (i+1) + " score is " + tempScore +
        " and grade is " + grade);
    }//end for
  }//end main
}//end class