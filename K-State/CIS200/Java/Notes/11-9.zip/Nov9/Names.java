// contains Arraylist & Scanner classes
import java.util.*;	

public class Names{
	public static void main(String[] args) {
	Scanner s = new Scanner(System.in);	

	// create ArrayList, initial size is 10
	//ArrayList nameList = new ArrayList();
	ArrayList <String> nameList = new ArrayList <String>();
	
	// add 10 names
	for (int i = 0; i < 10; i++) {
		System.out.print("Enter a name: ");
		String name = s.nextLine();
		nameList.add(name);
	} // end for
	
	// display the names using a loop
	System.out.println("\nNumber of names in List: " + nameList.size());
	System.out.println("The names are: ");
	for (int i = 0; i < nameList.size(); i++) {
		String name = nameList.get(i);
		System.out.println(name);
	} // end for

	// add 2 more names	
	System.out.println("\nAdding two names...");
	nameList.add("Homer Simpson");
	nameList.add("Marge Simpson");
		
	// display the names using an iterator
	System.out.println("Number of names in List: " + nameList.size());
	System.out.println("The names are: ");
	//process with an iterator
//	Iterator it = nameList.iterator();
	Iterator<String> it = nameList.iterator();
	while (it.hasNext()) {
		String name = it.next();
		System.out.println(name);
	} // end while

	System.out.println("\nChanging first name in list / Deleting last name...");
// change first name in the list
	nameList.set(0, "Bart Simpson");

// delete last name in the list
// (size = number of Elements currently in ArrayList)
	nameList.remove(nameList.size()-1);

	// display the names using an iterator
	System.out.println("Number of names in List: " + nameList.size());
	System.out.println("The names are: ");
	//process with an iterator
	Iterator<String> it2 = nameList.iterator();
	while (it2.hasNext()) {
		String name = it2.next();
		System.out.println(name);
	} // end while

//process with an enhanced for loop - replaces iterator
	for (String name : nameList) {
		System.out.println(name);
	}

 } // end main
} // end class