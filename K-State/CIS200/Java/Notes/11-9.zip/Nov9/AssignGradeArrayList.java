// AssignGradeArrayList.java
// Assigning grade using WRAPPER Classes and
// an ARRAYLIST vs. a Vector

import java.util.*;   // Must import this for ARRAYLIST class

public class AssignGradeArrayList
{
  public static void main(String[] args)
  { Scanner s = new Scanner(System.in);
    int numOfStudents;  // The number of students
    int high = 0;       // Holds highest score
    char grade;         // Holds grade based upon score
    ArrayList <Integer> scores;   // ArrayList of scores

    // Create ArrayList w/initial size of 5
    scores = new ArrayList <Integer>(5);

    // Read scores and find the best score
    // replace definite loop (for) with indefinite (while)
        //for (int i=0; i<numOfStudents; i++)
    int i = 0;    // used for display purposes only
	int tempScore = 1;
    while (tempScore != -1)
    {
    System.out.print("Please enter score #"+ (i+1) + " (-1 to end): ");
    tempScore = Integer.parseInt(s.nextLine());
    if (tempScore != -1)
      {   // Use Integer wrapper class to create an object
		scores.add (new Integer(tempScore));
//        scores.add (tempScore);	// autoboxing example
        if (tempScore > high) 
                high = tempScore;
      } // end outer if
     i++; // increase counter for display purposes only
    } // end while

      System.out.println("");

// Assign and display grades (using a 'for' loop)
//   for (i=0; i<scores.size(); i++) {
//     tempScore = scores.get(i).intValue();

// Assign and display grades (using an ENHANCED 'for' loop)
//	for (Integer iVar : scores) {
//	tempScore = iVar.intValue();

// Assign and display grades (using an ENHANCED 'for' loop w/Autoboxing)
	for (int iVar : scores) {
	tempScore = iVar; 
	if (tempScore >= high - 10)
        grade = 'A';
      else if (tempScore >= high - 20)
        grade = 'B';
      else if (tempScore >= high - 30)
        grade = 'C';
      else if (tempScore >= high - 40)
        grade = 'D';
      else
        grade = 'F';

      System.out.println("Student "+ (i+1) +" score is " +
          tempScore + " and grade is " + grade);
    }

    System.out.println("\nProgram complete...");

  } // end main
} // end class

