// this example illustrates the use of a recursive method call

public class Factorial {
	public static void main(String[] args) {

	System.out.println("4! = " + fact(4));
	System.out.println("Fibonacci(4) = " + fib(4));

 } // end main

/*
// recursion
public static int fact(int n)
{
  if (n <= 1)
    return 1;
  else
    return n * fact(n-1); 	// recursive method call
} // end fact
*/

// iteration
public static int fact(int n)
{ int total = 1;
  while (n != 0) {
	  total *= n;
	  n--;
  } // end while

  return total;
} // end fact


public static int fib (int n) {

// Base Cases:
//   If n == 0 then fib(n) = 0.
//   If n == 1 then fib(n) = 1.
if (n < 2) {
   return n;
} // end if

// Recursive Case:
//   If n >= 2 then fib(n) = fib(n-1) + fib(n-2).
 else {
   return fib(n-1) + fib(n-2);
 } // end else
} // end fib

} // end class