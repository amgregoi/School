/**
 File name: TempConvert.java
 Author: Dr. D. Lang
 This program does the following:
   * Prompts the user to enter a temperature in degrees Fahrenheit
   * Converts the user's input to degrees Celsius
   * Displays the Celsius temperature

*/
import java.util.Scanner;

public class TempConvert_Solution_Methods
{
    public static void main(String[] args)
    {
      //declare variables
      int degreesF ; 	//to nearest degree
      double degreesC ; //includes decimal portion

      //Get user input and store it in variable
		degreesF = getInput();
 
	  // call method to convert the temperature to degrees Celsius
        degreesC = convert(degreesF);

      // display output
		display(degreesF, degreesC);
    } //end of method main
	
    // method to read in Fahrenheit
    public static int getInput( ) {
		Scanner in = new Scanner (System.in);
		System.out.print ("Enter a temperature in degrees Fahrenheit: ");
		int degreesF = in.nextInt();
		return (degreesF);
	} // end getInput
	
    // method to convert Fahrenheit to Celsius
    public static double convert (int degreesF)
    {   double degreesC = 5.0/9 *(degreesF - 32);
        return (degreesC);
    }// end convert

    // method to display temp in Celsius
    public static void display(double tempF, double tempC) { 
        System.out.println(tempF + " degrees Fahrenheit "
                          + "= " + tempC + " degrees Celsius.");
	} // end display

} //end class TempConvert_Solution_Methods
