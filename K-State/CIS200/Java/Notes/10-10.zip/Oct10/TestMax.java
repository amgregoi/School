// TestMax.java
// Developed to demonstrate defining and calling a java method
// 'findMaximum' method finds the maximum of 2 numbers

public class TestMax
{
  public static void main(String[] args)
  { int num1 = 33, num2 = 55; // Hard-coding values

    // Invoke the max method AND DISPLAY with integer VARIABLES
    System.out.println("The maximum between " + num1 + " and " + num2 + " is "
                                                    + findMaximum(num1,num2));

    // System.out.println("num1 = " + num1 + " and " + num2 + " is "+ num2);

    // Invoke the max method  AND DISPLAY with integer LITERALS
    System.out.println("The maximum between 3 and 4 is " + findMaximum(3,4));

    // Can also invoke the findMaximum method using an assignment operator THEN
    // Display the variable later in a print statement
    int larger = findMaximum (100,200);
    System.out.println("Larger = " + larger);
  }//end main

// --- Find the maximum value between two integer values ---
  public static int findMaximum(int num1, int num2)
  {     // What is returned if the following line is added?
        // num1=500; num2 = 1000;
        // Do the values of the "original" num1/num2 change?
    if (num1 > num2)
    { return num1;
    } // end if
    else
    { return num2;
    }//end if-else

// Replacing the 'else' with the following causes a compile error - why?
// else if (num1 <= num2)

  }//end findMaximum method

}//end class
