// this example throws an exception within the method...

import java.util.*;

public class ThrowingDouble {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		try {
				System.out.print("Enter num1: ");
				double num1 = Double.parseDouble(s.nextLine());
				System.out.print("Enter num2: ");
				double num2 = Double.parseDouble(s.nextLine());
				double result = doubleDiv(num1, num2);
				System.out.println("Result is: " + result);
			} // end try
		catch (NumberFormatException e) {
			System.out.println("Bad Input. Numeric only");
		} // end catch
		catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		} // end catch2
		System.out.println("End of program reached...");

	} // end main
	
	public static double doubleDiv (double a, double b) {
		if (b==0) throw new IllegalArgumentException
								("Division by zero is not allowed");
		//System.out.println("Made it past throwing exception in intDiv");
		return a/b;
	} // end intDiv

} // end class