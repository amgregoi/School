// this example throws an exception within the method...

import java.util.*;

public class Throwing_SOL {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		try {
			System.out.print("Enter num1: ");
			double num1 = Double.parseDouble(s.nextLine());
			System.out.print("Enter num2: ");
			double num2 = Double.parseDouble(s.nextLine());
			double result = intDiv(num1, num2);
			System.out.println("Integer result is: " + result);
		} // end try
		catch (NumberFormatException nfe) {
			System.out.println("Bad input. Integers only");
		} // end catch1
		catch (IllegalArgumentException arg) {
			// displays message below
			System.out.println(arg.getMessage());
		} // end catch2


		System.out.println("End of program reached...");
	} // end main

	public static double intDiv(double a, double b) {
	//	if (b == 0)
	//		throw new IllegalArgumentException("division by zero not allowed");
	//	System.out.println("Made it past throwing exception in method intDiv...");
		return a/b;
	} // end intDiv
} // end class