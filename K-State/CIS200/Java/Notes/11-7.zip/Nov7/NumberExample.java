import java.util.Scanner;

public class NumberExample_SOL {

	public static void main(String[] args) {

		int num = getNum();
		// if (num != -1)
		 System.out.println("Square: " + num*num);

	} // end main

	public static int getNum() {
		Scanner s  = new Scanner(System.in);

		int num = -999;
		while (num == -999) {
			try {
				System.out.print("Enter number: ");
				num = Integer.parseInt(s.nextLine());
				// return num;
			} // end try
			catch (NumberFormatException e) {
				System.out.println("Input must be an integer.  Try again.");
				//ex.printStackTrace();
			} // end catch
		} // end while

		// System.out.println("\n10 tries ... Bad input .. I'm quitting!");
		// return -1;
		return num;
	} // end getNum
} // end class NumberExample