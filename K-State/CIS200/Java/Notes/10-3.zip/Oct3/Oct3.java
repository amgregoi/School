import java.util.*;
import java.io.*;

public class Oct3 {
	public static void main(String[] args) throws IOException {
		
/*
// text reader ... read in name of a text file and display contents to screen
		String fileName;
		System.out.print("Enter in path and filename of your text file: ");
        fileName = s.nextLine();
		fileName+=".txt";
		Scanner inFile = new Scanner(new File(fileName));
        
// add needed code here
        while (inFile.hasNext()) {
			String line = inFile.nextLine();
			System.out.println(line);
			}
		
		inFile.close();

// Test 1 - enter file name w/o file ext or path
// Test 2 - enter file name w/file ext, but w/o path
// Test 3 - enter file name w/entire path
*/
	createFile();

 } // end main
 
 public static void createFile () throws IOException {
 Scanner s = new Scanner(System.in);
 PrintWriter pw = new PrintWriter (new FileWriter("testFile.txt"));
    System.out.println("Enter in text below ... enter '/' to end the input");
	String input;
	do {
			input = s.nextLine();
			if (input.equals("")) {
			    input=" ";
				pw.println();
				}
			else if (input.charAt(0) != '/')
				pw.println(input);
		} while (input.charAt(0) != '/');
			
			pw.close();
 
 } // end createFile
} // end class