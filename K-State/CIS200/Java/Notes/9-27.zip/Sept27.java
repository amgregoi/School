import java.util.*;

public class Sept27 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		//print double letters
		/*System.out.print("Enter a string: ");
		String str = s.nextLine();
		
		for (int i = 0; i < str.length()-1; i++) {
			//see if current letter is same as the
			//next one
			if (str.charAt(i) == str.charAt(i+1)) {
				System.out.println("Pair of " + str.charAt(i) + "'s");
			}
		}*/
		
		//process date
		System.out.print("Enter a date (m/d/y): ");
		String date = s.nextLine();
		int slash1 = date.indexOf("/");
		
		String month = date.substring(0,slash1);
		date = date.substring(slash1+1);
		int slash2 = date.indexOf("/");
		
		String day = date.substring(0, slash2);
		String year = date.substring(slash2+1);
		
		System.out.println(month + " " + day + " " + year);
	}
}