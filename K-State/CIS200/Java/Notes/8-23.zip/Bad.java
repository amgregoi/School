public class Bad {
	public static void main(String[] args) {
		System.out.println("hello");
		System.out.println("this is a test");
		System.out.println("testing...testing...\"");
	}
}