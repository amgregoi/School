import java.util.*;
import java.io.*;

public class Oct10 {
	public static void main(String[] args) throws IOException {
		Scanner s = new Scanner(System.in);

// text reader ... read in name of a text file and display contents to screen
		String fileName;
		//System.out.print("Enter in path and filename of your text file: ");
        //fileName = s.nextLine();
		if (args.length > 0){
			Scanner inFile = new Scanner(new File(args[0]));
			while (inFile.hasNext()) {
				String line = inFile.nextLine();
				System.out.println(line);
			} // end while

		inFile.close();
		} // end if

		else
			System.out.println("usage: [java class name] [input filename.txt]");

 } // end main
} // end class