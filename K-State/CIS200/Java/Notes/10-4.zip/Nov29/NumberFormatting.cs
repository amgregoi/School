using System;

public class NumberFormatting {
	public static void Main() {

	// (C)urrency formatting		
	Console.WriteLine("{0:C}", 2.567);		// default 2 decimals (Rounds)
	Console.WriteLine("{0:C1}", 2.567);		// 1 decimal 
	Console.WriteLine("{0:C0}", 2.567);		// 0 decimals

	// (F)ixed-point formatting		
	Console.WriteLine("\n{0:F0}", 2.567);	// 0 decimals (Rounds)
	Console.WriteLine("{0:F3}", 2.567);		// 3 decimals
	Console.WriteLine("{0:F}", 2567);		// default 2 decimals, *no comma*

	// (N)umber formatting		
	Console.WriteLine("\n{0:N0}", 2.567);	// 0 decimals (Rounds)
	Console.WriteLine("{0:N1}", 1234567.89);// 1 decimal, *commas*
	Console.WriteLine("{0:N}", 2567);		// default 2 decimals, *comma*
	} // end Main
} // end class