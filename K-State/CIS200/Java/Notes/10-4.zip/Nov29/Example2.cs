using System;

public class Example2 {
  public static void Main() {
    int [ ] nums = new int[4];
	int size = nums.Length;
	
	for (int i=0; i < size; i++)
		Console.WriteLine(nums[i]);

	string [ ] str = new string[4];
	size = str.Length;
	for (int i=0; i < size; i++)
		Console.WriteLine(str[i]);
		
	int [,] grid = new int[3,4];	// 3 Rows, 4 Col
	grid[0,2] = 4;	// Row 1, Col 3
	grid[2,3] = 5;	// Row 3, Col 4
	
	int numRows = grid.GetLength(0);
	int numCols = grid.GetLength(1);

	for (int row = 0; row < numRows; row++) {
		for (int col = 0; col < numCols; col++)
			Console.Write (grid[row,col] + " ");
	Console.WriteLine("");
	}
	
	string s = "hello";
	char letter = s[0];
	
	string s1 = s.Substring(2);
	string s2 = s.Substring(1,2);
	Console.WriteLine("\ns: " + s);
	Console.WriteLine("s1: " + s1);
	Console.WriteLine("s2: " + s2);
		
  } // end main
} // end class