using System;

public class Example1 {
  public static void Main() {
    
    string s = "C# Example";

    int num;
    double dNum;
    bool flag = true;
    
// Display hard-coded string
    Console.WriteLine("CIS 200: " + s);

// get an int number from the user, increase by one
    Console.Write("Enter an int number: ");
    num = Convert.ToInt32(Console.ReadLine());
    num++;

// get a double number from the user
    Console.Write("Enter a double number: ");
    dNum = Convert.ToDouble(Console.ReadLine());

// assigns true or false to flag (just for an example)
    flag = (num > dNum);

// display the one that is bigger
    if (flag)
      Console.WriteLine("integer plus one is bigger");
    else
      Console.WriteLine(dNum + " (double) is bigger");

// convert string to char
	// complies but exception thrown at runtime if 's' is more than one char
	//char c = Convert.ToChar(s);
	char c = s[0];
    Console.WriteLine("string = " + s);
    Console.WriteLine("Char = " + c);

// convert string to char [ ]
	char [ ] cArray = s.ToCharArray();
    Console.WriteLine("string = " + s);
    Console.WriteLine("Char 4 = " + cArray[3]);

  } // end main
} // end class