/**************************************************************
* CarApp.java
* This class is a demonstration driver for the Car class.
**************************************************************/

public class CarApp
{
  public static void main(String[] args)
  {
    Car nathanCar = new Car("Audi", 1998, "green");
    Car nickCar = nathanCar.makeCopy();
 
    //nickCar.setYear (2000);
	
    System.out.println("\nNathan's Car:" + nathanCar); //.toString());
    //nathanCar.display();

    System.out.println("\nNick's Car:" + nickCar);
    //nickCar.display();


    if (nathanCar.equals(nickCar))
    {
      System.out.println("\nCars have identical features.");
    }
    else {
      System.out.println("\nCars do NOT have identical features.");
    }

	} // end main
} // end class CarApp