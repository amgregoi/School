import java.util.*;
import java.io.*;

public class FileIO {
	public static void main(String[] args)throws IOException {
		Scanner s = new Scanner(System.in);
		
		//file input
	try{
		Scanner inFile = new Scanner(new File("nums.txt"));
		int sum = 0;
		while (inFile.hasNext()) {
			String line = inFile.nextLine();
			String[] pieces = line.split(" ");
			for (int i = 0; i < pieces.length; i++) {
				sum += Integer.parseInt(pieces[i]);
			} // end for
		} // end while
		
		System.out.println("Sum is: " + sum);
		inFile.close();
		} //end try
	catch (IOException e) {
		System.out.println("Error in opening the file");
		System.out.println("Check filename and rerun program");
		//System.out.println("\nHere is some technical information:");
		// e.printStackTrace();
		// System.exit(-1);	
	} //end catch IOException

	catch (NumberFormatException n) {
	  System.out.println("All lines in text file must be integers.");
	} //end catch NumberFormatException
	
	System.out.println("Exiting gracefully...");
	
 } // end main
} // end FileIO class