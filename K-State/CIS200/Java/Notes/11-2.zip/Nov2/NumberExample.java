import java.util.Scanner;

public class NumberExample {

	public static void main(String[] args) {
		int num = getNum();
		if (num != -1)
			System.out.println ("Square: " + num*num);
	} // end main
	
	public static int getNum () throws NumberFormatException {
		Scanner s  = new Scanner(System.in);
		//try 10 times
			for (int i = 0; i < 10; i++) {
			try {
				System.out.print("Enter number: ");
				int num = Integer.parseInt(s.nextLine());
				return num;
			} // end try
			catch (NumberFormatException e) {
				System.out.println("Input must be an integer.");
			} // end catch
				
			} // end for

			System.out.println("\n10 tries...bad input...I'm quitting!");
            return -1;
	} // end getNum
} // end class NumberExample