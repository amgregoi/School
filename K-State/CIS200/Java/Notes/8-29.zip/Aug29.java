import java.util.*;

public class Aug29 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		//extract digits
		/*System.out.print("Enter number: ");
		int num = Integer.parseInt(s.nextLine());
		int dig1 = num % 10;
		num = num / 10;
		int dig2 = num % 10;
		num = num / 10;
		int dig3 = num % 10;
		num = num / 10;
		int dig4 = num;
		
		System.out.println(dig4 + " " + dig3 + " " +
							dig2 + " " + dig1);*/
							
		//character converter
		System.out.print("Enter a single lower-case character: ");
		char letter = (s.nextLine()).charAt(0);
		
		//capitalize
		//force it to be an int (ASCII value)
		int ascii = (int) letter;
		//subtract 32 (to convert to upper-case)
		ascii -= 32;
		//force it to be a char (get back the character)
		letter = (char) ascii;
		System.out.println("Capitalized: " + letter);
		
		//get the previous letter
		ascii--;
		letter = (char) ascii;
		System.out.println("Previous: " + letter);
		
		//get the next letter
		ascii+=2;
		letter = (char) ascii;
		System.out.println("Next: " + letter);
	}
}