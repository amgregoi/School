// controller - controls communication between model and view
import java.util.*;

public class Controller {
	public static void main(String[] args) {
	// create a View object
	View v = new View();

	// Read in a number using 'getNum' in View
	// Use to create a 'NumberSquarer' object
	NumberSquarer sq = new NumberSquarer(v.getNum());

	// Display result using 'printResults' in View
		v.printResults(sq.square());
	} // end main
} // end Controller