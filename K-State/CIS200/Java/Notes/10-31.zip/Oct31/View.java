// view - handles I/O
import java.util.*;

public class View {
	private Scanner s;
	
// one argument constructor	
	public View() {
		s = new Scanner(System.in);
	}
	
// method to read and return an int	
	public int getNum() {
		System.out.print("Enter number: ");
		return Integer.parseInt(s.nextLine());
	}
	
// method to print a passed-in int	
	public void printResults(int sq) {
		System.out.println("Result is: " + sq);
	}
} // end View.java