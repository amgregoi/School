// model - stores data / does calculations
public class NumberSquarer {
		private int num;

		// one argument constructor	
		public NumberSquarer(int n) {
				num = n;
		}

// square() method to return the square of num
	public int square() {
		return num*num;
	}

} // end NumberSquarer