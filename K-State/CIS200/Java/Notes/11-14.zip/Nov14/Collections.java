import java.util.*;
//import java.io.*;

public class Collections {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
/*
//ArrayList
	ArrayList<Double> list = new ArrayList<Double>();
		
	//Read in 10 doubles
	System.out.println("Read in 10 doubles into ArrayList...");
	for (int i = 0; i < 10; i++) {
		System.out.print("Enter number " + (i+1) + ": ");
		double num = Double.parseDouble(s.nextLine());
		list.add(num);	// Autoboxing used
	} // end for
		
	//process with a loop/get
	System.out.println("\nThe numbers in ArrayList (using 'for') are: ");
	for (int i = 0; i < list.size(); i++) {
		double elem = list.get(i);  // Autoboxing used
		System.out.println(elem);
	} // end for
		
	//process with an iterator
	System.out.println("\nThe numbers in ArrayList (using iterator) are: ");
	Iterator<Double> it = list.iterator();
	while (it.hasNext()) {
		double val = it.next(); // Autoboxing used
		System.out.println(val);
	} // end while

	//TreeSet
	TreeSet<Double> list = new TreeSet<Double>();
		
	//Read in 10 doubles
	System.out.println("Read in 10 doubles into TreeSet...");
	for (int i = 0; i < 10; i++) {
		System.out.print("Enter number " + (i+1) + ": ");
		double num = Double.parseDouble(s.nextLine());
		list.add(num);	// Autoboxing used
	} // end for
		
	//process with an iterator
	System.out.println("\nThe numbers in TreeSet(using iterator) are: ");
	Iterator<Double> it = list.iterator();
	while (it.hasNext()) {
		double val = it.next(); // Autoboxing used
		System.out.println(val);
	} // end while

	TreeSet<String> list = new TreeSet<String>();

	list.add("Fred");
	list.add("Amy");
	list.add("Sam");
	list.add("Kate");

	System.out.println("\nThe names in TreeSet(using iterator) are: ");
	Iterator<String> it = list.iterator();
	while (it.hasNext()) {
		String val = it.next(); // Autoboxing used
		System.out.println(val);
	} // end while
*/

HashMap<String, String> map = new HashMap<String,String>();

map.put("KSU", "Wildcat");
map.put("KU", "Jayhawks");
map.put("TX", "Longhorns");
map.put("MU", "Tigers");
map.put("OK","Sooners");

System.out.println("\nSchool Abbrev...");
Iterator<String> it = map.keySet().iterator();
while (it.hasNext()) {
	String abbrev = it.next();
	System.out.println(abbrev);
	}
map.put("KU","Goofy Bird");
System.out.println("\nSchool Abbrev...");
Iterator<String> it2 = map.keySet().iterator();
while (it2.hasNext()) {
	String abbrev = it2.next();
	System.out.println(abbrev);
	}

System.out.print("\nEnter in School Abbrev: ");
String key = s.nextLine();
String val = map.get(key);
System.out.println("School Mascot: " + val);	


 } // end main
} // end class