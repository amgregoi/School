// File: Car.java
// Defining the Car class with the data properties make, model, year,
// mpg and amount of fuel left in the tank. Includes methods to calculate
// the mpg and how far you can go with the fuel left in your tank

public class Car
{ // Notice NO MAIN method in class definition
   // declare instance var - data properties all objects of this class have
   public String make, model;
   public int year;
   public double mpg = 0;            // initialize at zero
   public double amountOfFuel = 0;  // amount of fuel in tank - in gallons

//Define methods - what the class knows how to do (Comment!)
// ---------------------------------------------------------------
   /* This method calculates the miles per gallon for a certain object
      Two values must be passed into the method - how far the car goes on
      how many gallons. The result is stored in the 'mpg' data property
   */
   public void calcMPG (int milesTraveled, int gallonsOfGas)
   {   mpg = milesTraveled / gallonsOfGas;
   } // end calcMPG

// ---------------------------------------------------------------
   /* This method returns how far (in miles) a car object can
      go until the gas tank is empty, depending on the value stored in
      the 'amountOfFuel' and 'mpg' data properties
   */
    public double getDistanceToEmpty()
    { double distanceToGo = amountOfFuel * mpg;
      return distanceToGo ;
    } //end method getDistanceToEmpty

// ---------------------------------------------------------------
// This method displays the data properties of a car
    public void displayOutput()
    { System.out.println ("Car info: ");
      System.out.println ("Year - " + year);
      System.out.println ("Make - " + make);
      System.out.println ("Model - " + model);

      if (mpg != 0)
         System.out.println ("MPG - " + mpg);
      else
        System.out.println ("MPG not determined...");

      if (amountOfFuel != 0)
         System.out.println ("Fuel in tank is " + amountOfFuel + " gallons");
      else
        System.out.println ("Fuel tank is empty...");
      System.out.println ("");   // display a blank line
    } // end displayDataProperties
} //end class Car
