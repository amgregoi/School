public class CarApp {
 public static void main (String [ ] args) {

	Car myCar = new Car();
	Car car2 = new Car();
	
	myCar.make = "Ford";
	myCar.model = "Mustang";
	myCar.year = 1965;
	
	car2.make="Toyota";
	car2.model="Prius";
	car2.year=2011;
	
	myCar.displayOutput();
	car2.displayOutput();
	
	car2.amountOfFuel = 12.3;
	car2.calcMPG(200, 3);
	car2.displayOutput();
	}
}