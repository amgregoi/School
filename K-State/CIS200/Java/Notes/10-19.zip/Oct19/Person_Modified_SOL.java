public class Person {
	//instance variables
	//<visibility> <data type> <variable name>;
	private String name;
	private int age;
	private String ssNumber;
	
	//no argument constructor
	public Person() {
		name = "unitialized";
		age = -1;
		ssNumber = "unitialized";
	}

	//2 argument constructor - name, age
	public Person(String n, int a) {
		name = n;
		age = a;
		ssNumber = "unitialized";
	}

	//2 argument constructor - name, ss#
	public Person(String n, String ss) {
		name = n;
		age = -1;
		ssNumber = ss;
	}

	//3 argument constructor - name, age, ss#
	public Person(String n, int a, String ss) {
		name = n;
		age = a;
		ssNumber = ss;
	}
	
	//methods
	public void display() {
		System.out.println("\nName: " + name);
		System.out.println("Age: " + age);
		System.out.println("SS #: " + ssNumber + "\n");
	} // end display()

	// add method to parse name so it stored as: �Last, First�
	public void parseName() {
		String [ ] temp = name.split(" ");
		name = temp[1] + ", " + temp[0];
	} // end parseName


	// add method to store last four digits of SS number
	public void parseSS() {
		String [ ] temp = ssNumber.split("-");
		System.out.println("Last four digits of your SS#: " + temp[2]);
	} // end parseSS
		
} // end class Person