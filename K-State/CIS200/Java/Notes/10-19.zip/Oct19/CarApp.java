/*
 File: CarApp.java
 Description: Demonstrates how to use the Car class by instaniating
 a car object and displaying its data properties
*/

public class CarApp
{
  public static void main(String[] args)
  {
    //create a car object
    Car myCar = new Car();

    //assign values to make, model, and year
    myCar.make = "Ford";
    myCar.model = "Mustang";
    myCar.year = 1965;

    // display current data properties
    myCar.displayOutput();

    //assign value to the amount of fuel in the tank
    myCar.amountOfFuel = 10.3;

    // calculate MPG ... to keep it simple, we are HARDCODING the values
    // for the distance traveled on how many gallons. This would best be
    // entered in by the user
    myCar.calcMPG(200,10);     // calculate MPG using 200 miles
                               // on 10 gallons of gas

    // display current data properties
    myCar.displayOutput();

    // calculate and display how far we can go on the current tank of gas
    System.out.println("Your car can go " + myCar.getDistanceToEmpty()
                       + " miles before running out of gas." );
  } //end method main
} //end class CarApp
