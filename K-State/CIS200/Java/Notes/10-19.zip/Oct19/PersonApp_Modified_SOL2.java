import java.util.*;

public class PersonApp {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		//create person Bob Smith, age 20, 515-00-9999 (Hardcode)
		Person pers1 = new Person("Bob Smith", 20, "515-00-9999");
		Person pers2 = new Person( );
		Person pers3 = new Person("Billy Jones", 22);
		Person pers4 = new Person("Alice Smith", "122-22-9999");
	
		pers1.display();
		pers2.display();
		pers3.display();
		pers4.display();
	}
}