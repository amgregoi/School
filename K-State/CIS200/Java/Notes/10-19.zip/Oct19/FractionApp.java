public class FractionApp { 
  public static void main(String[] args){
    Fraction a = new Fraction(3, 4);
    Fraction b = new Fraction(3);

	//Fraction c = new Fraction(); // error
	//Fraction c = new Fraction(3, 0); // zero denominator; error?

    a.display();
    b.display();
    //c.display();

  } // end main
} // end class FractionApp
