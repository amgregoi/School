public class Fraction {
  private int numerator;
  private int denominator;
  private double decimal;

    // one argument constructor
	public Fraction(int n) {
    this(n, 1);
  }

 		// two argument constructor
  public Fraction(int n, int d){
    numerator = n;
    denominator = d;
    decimal = (double)numerator
      / denominator;
  }

  // display fraction & decimal value
  public void display()
	{ System.out.println(numerator +
      " / " + denominator +
      " = " + decimal);
	} // end display
} // end Fraction class
