public class Person {
	//instance variables
	//<visibility> <data type> <variable name>;
	private String name;
	private int age;
	private String ssNumber;
	
	//constructor
	public Person(String n, int a, String ss) {
		name = n;
		age = a;
		ssNumber = ss;
	}
	
	//methods
	public void display() {
		System.out.println("\nName: " + name);
		System.out.println("Age: " + age);
		System.out.println("SS #: " + ssNumber + "\n");
	} // end display()
	
} // end class Person