/*/////////////////////// test.c ////////////////////////////////////*/
long test(unsigned int ui, int i, short s, unsigned short us,
	char c, unsigned char uc, long l, unsigned long ul,
	int x, short y)
{
	char c1;
	int i1;
	char c2;

	ui = 1;
 	i = 2;
	s = 3;
	us = 4;
	c = 5;
	uc = 6;
	l = 7;
	ul = 8;
	x = 9;
	y = 10;
	c1 = 11;
	c2 = 12;
	i1 = 13;
	return ui * 2 + l;
}
