#include <unistd.h>

void main(void)
{
	alarm(5);
	while(1);
}
