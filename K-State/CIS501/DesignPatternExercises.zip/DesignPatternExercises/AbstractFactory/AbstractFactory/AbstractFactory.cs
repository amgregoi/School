//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Abstract Factory Pattern                                           //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno, (c) 2007                           //
//      for Learning Tree Course, 123P, 252P                            //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Reflection;

namespace AbstractFactory
{
    public abstract class Item
    {
        protected string caption;
        public Item(String caption) 
        {
            this.caption = caption;
        }
        public abstract string makeHTML();
    }

    public abstract class Link : Item 
    {
        protected String url;
        public Link(String caption, string url) : base(caption)
        {
            this.url = url;
        }
    }

    public abstract class Tray : Item 
    {
        protected List<Item> tray = new List<Item>();
        public Tray(String caption) : base(caption) {}
        public void add(Item item) 
        {
            tray.Add(item);
        }
    }

    public abstract class Page
    {
        protected string title;
        protected string author;
        protected List<Item> contents = new List<Item>();
        public Page(string title, string author)
        {
            this.title = title;
            this.author = author;
        }
        public void add(Item item)
        {
            contents.Add(item);
        }
        public void output()
        {
            try {
                string filename = title + ".html";
                FileStream file = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.Write);
                StreamWriter writer = new StreamWriter(file);
                writer.Write(this.makeHTML());
                writer.Close();
                System.Console.WriteLine(filename + " was created");
            } catch (IOException e) {
                System.Console.Error.WriteLine(e.StackTrace);
            }
        }
        public abstract string makeHTML();
    }

    public abstract class Factory
    {
        public static Factory getFactory(string typeName)
        {
            Factory factory = null;

            try
            {
                typeName = "AbstractFactory." + typeName;
                Type type = Type.GetType(typeName);
                factory = (Factory)Activator.CreateInstance(type);
            }
            catch (Exception ex)
            {
                System.Console.Error.WriteLine(ex.StackTrace);
            }
            return factory;
        }
        public abstract Link createLink(String caption, String url);
        public abstract Tray createTray(String caption);
        public abstract Page createPage(String title, String author);
    }

    public class ListFactory : Factory
    {
        public override Link createLink(String caption, String url) 
        {
            // complete the body
        }
        public override Tray createTray(String caption) 
        {
            // complete the body
        }
        public override Page createPage(String title, String author) 
        {
            // complete the body
        }
    }

    public class ListLink : Link
    {
        public ListLink(string caption, string url):base(caption,url) {}
        public override string makeHTML() 
        {
            return "  <li><a href=\"" + url + "\">" + caption + "</a></li>";
        }
    }

    public class ListTray : Tray {
        public ListTray(string caption) : base(caption){}
        public override string makeHTML()
        {
            StringBuilder buffer = new StringBuilder();
            buffer.AppendLine("<li>");
            buffer.AppendLine(caption);
            buffer.AppendLine("<ul>");
            foreach(Item item in tray)
            {
                buffer.AppendLine(item.makeHTML());
            }
            buffer.AppendLine ("</ul>");
            buffer.AppendLine ("</li>");
            return buffer.ToString();
        }
    }

    public class ListPage : Page {
        public ListPage(string title, string author):base(title, author) { }
        public override string makeHTML()
        {
            StringBuilder buffer = new StringBuilder();
            buffer.AppendLine("<html><head><title>" + title + "</title></head>");
            buffer.AppendLine("<body>");
            buffer.AppendLine("<h1>" + title + "</h1>");
            buffer.AppendLine("<ul>");
            foreach(Item item in contents)
            {
                buffer.AppendLine(item.makeHTML());
            }
            buffer.AppendLine("</ul>");
            buffer.AppendLine("<hr><address>" + author + "</address>");
            buffer.AppendLine("</body></html>");
            return buffer.ToString();
        }
    }

    public class TableFactory : Factory 
    {
        public override Link createLink(string caption, string url)
        {
           // complete the body
        }
        public override Tray createTray(string caption) 
        {
            // complete the body
        }
        public override Page createPage(string title, string author)
        {
            // complete the body
        }
    }

    public class TableLink : Link
    {
        public TableLink(string caption, string url):base(caption, url) {}
        public override string makeHTML() 
        {
            return "<td><a href=\"" + url + "\">" + caption + "</a></td>";
        }
    }

    public class TableTray : Tray 
    {
        public TableTray(String caption) :base(caption){}
        public override string makeHTML()
        {
            StringBuilder buffer = new StringBuilder();
            buffer.AppendLine("<td>");
            buffer.AppendLine("<table width=\"100%\" border=\"1\"><tr>");
            buffer.AppendLine("<td bgcolor=\"#cccccc\" align=\"center\" colspan=\""+ tray.Count + "\"><b>" + caption + "</b></td>");
            buffer.AppendLine("</tr>");
            buffer.AppendLine("<tr>");
            foreach(Item item in tray)
            {
                buffer.AppendLine(item.makeHTML());
            }
            buffer.AppendLine("</tr></table>");
            buffer.AppendLine("</td>");
            return buffer.ToString();
        }
    }

    public class TablePage : Page 
    {
        public TablePage(String title, String author):base(title, author) {}
        public override string makeHTML() 
        {
            StringBuilder buffer = new StringBuilder();
            buffer.AppendLine("<html><head><title>" + title + "</title></head>");
            buffer.AppendLine("<body>");
            buffer.AppendLine("<h1>" + title + "</h1>");
            buffer.AppendLine("<table width=\"80%\" border=\"3\">");
            foreach(Item item in contents)
            {
                buffer.AppendLine("<tr>" + item.makeHTML() + "</tr>");
            }
            buffer.AppendLine("</table>");
            buffer.AppendLine("<hr><address>" + author + "</address>");
            buffer.AppendLine("</body></html>");
            return buffer.ToString();
        }
    }


    class Driver
    {
        static void Main(string[] args)
        {
            if (args.Length != 1) 
            {
                System.Console.WriteLine("Usage: AbstractFactory ConcreteFactory");
                System.Console.WriteLine("Example 1: AbstractFactory ListFactory");
                System.Console.WriteLine("Example 2: AbstractFactory TableFactory");
                Environment.Exit(0);
            }
            Factory factory = Factory.getFactory(args[0]);

            Link nytimes = factory.createLink("New York Times", "http://www.nytimes.com/");
            Link kcstar = factory.createLink("Kansas City Star", "http://www.kansascity.com/");

            Link us_yahoo = factory.createLink("Yahoo!", "http://www.yahoo.com/");
            Link jp_yahoo = factory.createLink("Yahoo!Japan", "http://www.yahoo.co.jp/");
            Link excite = factory.createLink("Excite", "http://www.excite.com/");
            Link google = factory.createLink("Google", "http://www.google.com/");

            Tray traynews = factory.createTray("News Papers");
            traynews.add(nytimes);
            traynews.add(kcstar);

            Tray trayyahoo = factory.createTray("Yahoo!");
            trayyahoo.add(us_yahoo);
            trayyahoo.add(jp_yahoo);

            Tray traysearch = factory.createTray("Search Engine");
            traysearch.add(trayyahoo);
            traysearch.add(excite);
            traysearch.add(google);

            Page page = factory.createPage("LinkPage", "Yuki Hiroshi");
            page.add(traynews);
            page.add(traysearch);
            page.output();
        }
    }
}
