//////////////////////////////////////////////////////////
//                                                      //
//  MM State                                            //
//  Written by Masaaki Mizuno, (c)2007                  //
//      for Learning Tree Course  252P                  //
//      also for K-State Course cis501                  //
//                                                      //
//////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;

namespace State
{
    class Context {
      State currentState;  // currrent state
      public State state00; 
      public State state10; 
      public State state11; 
      public State state01; 
      public State fatalError;

      public Context()
      {
          currentState = null;
          state00 = new State00(this);
          state10 = new State10(this);
          state11 = new State11(this);
          state01 = new State01(this);
          fatalError = new FatalError(this);
          turnGreen();
          setState(state00);
      }

      public void setState(State sp)
      {
          currentState = sp;
      }

      // delegate  method calls to the current state object
      public void printCurrentState(){currentState.printCurrentState();}
      public void s1On() {currentState.s1On();}
      public void s2On() {currentState.s2On();}
      public void s1Off() {currentState.s1Off();}
      public void s2Off() {currentState.s2Off();}

      public void turnRed() {Console.WriteLine("### Signal is Red ###");}
      public void turnGreen() {Console.WriteLine("### Signal is Green ###");}
      public void siren() {Console.WriteLine("### Siren is on ###");}
    }

    abstract class State {
      protected Context context;

      public State(Context cp) { context = cp; }
      public virtual void s1On(){}
      public virtual void s2On(){}
      public virtual void s1Off(){}
      public virtual void s2Off(){}
      public abstract void printCurrentState();
    }

    class State00: State{
      public State00(Context cp): base(cp){}
      public override void s1On()
      {
          context.turnRed();
          context.setState(context.state10); 
      }
      public override void printCurrentState()
      {
          Console.WriteLine("Current State: State00");
      }
    }

    class State10: State{
      public State10(Context cp): base(cp){}
      public override void s2On()
      {
          // complete the body
      }
      public override void printCurrentState()
      {
          Console.WriteLine("Current State: State10");
      }
    }

    class State11: State{
      public State11(Context cp): base(cp){}
      public override void s1Off()
      {
         // complete the body
      }
      public override void printCurrentState()
      {
          Console.WriteLine("Current State: State11");
      }
    }

    class State01: State{
      public State01(Context cp): base(cp){}
      public override void s1On()
      {
          // complete the body
      }
      public override void s2Off()
      {
          // complete the body
      }
      public override void printCurrentState()
      {
          Console.WriteLine("Current State: State01");
      }
    }

    class FatalError: State
    {
        public FatalError(Context cp) : base(cp) { }
        public override void printCurrentState()
        {
            Console.WriteLine("Current State: Fatal Error");
        }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            int si; // sensor input
            Context cx = new Context();

            cx.printCurrentState();

            while (true)
            {
                Console.Write("\n 0: S1ON\n 1: S2ON\n 2: S1OFF\n 3: S2OFF\n 4: DONE\nInput: ");
                try
                {
                    si = int.Parse(Console.ReadLine());
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    return;
                }         
                switch (si)
                {
                    case 0: cx.s1On(); cx.printCurrentState(); break;
                    case 1: cx.s2On(); cx.printCurrentState(); break;
                    case 2: cx.s1Off(); cx.printCurrentState(); break;
                    case 3: cx.s2Off(); cx.printCurrentState(); break;
                    default: return;
                }
            }
        }
    }
}
