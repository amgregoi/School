//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Decorator Pattern                                                  //
//   Written by Masaaki Mizuno, (c) 2007                                //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
//////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;

namespace Decorator
{
    interface Decorator
    {
        void display();
    }
    class Terminal : Decorator
    {
        public void display()
        {
            Console.WriteLine("Decorator");
        }
    } 
    abstract class Internal:Decorator
    {
        protected Decorator next;
        public abstract void display();
        public Internal(Decorator next) { this.next = next; }
    }
    class Pre:Internal
    {
        char ch;
        public Pre(char ch, Decorator next) : base(next) { this.ch = ch; }
        public override void display()
        {
            for (int i = 0; i < 10; i++) Console.Write(ch);
            Console.WriteLine();
            this.next.display();
        }
    }
    class PrePost: Internal
    {
        char ch;
        public PrePost(char ch, Decorator next) : base(next) {this.ch = ch;}
        public override void display()
        {
            for (int i = 0; i < 10; i++) Console.Write(ch);
            Console.WriteLine();
            this.next.display();
            for (int i = 0; i < 10; i++) Console.Write(ch);
            Console.WriteLine();
        }
    }
   class Post:Internal
    {
        char ch;
        public Post(char ch, Decorator next):base (next) { this.ch = ch; }
        public override void display()
        {
            this.next.display();
            for (int i = 0; i < 10; i++) Console.Write(ch);
            Console.WriteLine();
        }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            Decorator d; // = construct a chain of decorator objects
            d.display();
        }
    }
}
