﻿//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Mediator Pattern (Interface.cs)                                    //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Modified and ported to C# by Masaaki Mizuno, (c) 2007, 2010        //
//      for Learning Tree Course 252P                                   //
//      also for K-State Course cis501                                  //
//                                                                      //
//////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mediator
{
    public interface LoginMediator
    {
        void createColleagues();
        void colleagueChanged(LoginColleague colleague);
    }

    public interface LoginColleague
    {
        void setMediator(LoginMediator mediator);
        void setColleagueEnabled(Boolean enabled);
    }
}
