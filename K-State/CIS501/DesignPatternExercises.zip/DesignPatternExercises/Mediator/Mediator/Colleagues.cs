﻿//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Mediator Pattern (Colleagues.cs)                                   //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Modified and ported to C# by Masaaki Mizuno, (c) 2007, 2010        //
//      for Learning Tree Course 252P                                   //
//      also for K-State Course cis501                                  //
//                                                                      //
//////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace Mediator
{
    public class ColleagueButton : LoginColleague
    {
        Button btn;
        public ColleagueButton(Button btn)
        {
            this.btn = btn;
        }

        private LoginMediator loginMediator;
        public void setMediator(LoginMediator loginMediator)
        {
            this.loginMediator = loginMediator;
        }

        public void setColleagueEnabled(Boolean enabled)
        {
            btn.Enabled = enabled;
        }

        public void btnClickHandler(object sender, EventArgs e)
        { 
            Application.Exit();
        }
    }

    public class ColleagueRadioButton: LoginColleague
    {
        RadioButton rb;
        public ColleagueRadioButton(RadioButton rb)
        {
            this.rb = rb;
        }
        public Boolean Checked
        {
            set
            {
                rb.Checked = value;
            }
            get
            {
                return rb.Checked;
            }
        }
        private LoginMediator loginMediator;
        public void setMediator(LoginMediator loginMediator)
        {
            this.loginMediator = loginMediator;
        }
        public void setColleagueEnabled(Boolean enabled)
        {
            rb.Enabled = enabled;
        }

        public void rbCheckChangedHander(object sender, EventArgs e)
        {
            loginMediator.colleagueChanged(this);
        }
    }

    public class ColleagueTextBox : LoginColleague
    {
        TextBox tb;
        public ColleagueTextBox(TextBox tb)
        {
            this.tb = tb;
        }

        public string Text
        {
            get
            {
                return tb.Text;
            }
        }

        private LoginMediator loginMediator;
        public void setMediator(LoginMediator loginMediator)
        {
            this.loginMediator = loginMediator;
        }
        public void setColleagueEnabled(Boolean enabled)
        {
            tb.Enabled = enabled;
            tb.BackColor = (enabled ? Color.White : Color.LightGray);
        }
        public void tbTextChangedHandler(object sender, EventArgs e)
        {
            loginMediator.colleagueChanged(this);
        }
    }
}
