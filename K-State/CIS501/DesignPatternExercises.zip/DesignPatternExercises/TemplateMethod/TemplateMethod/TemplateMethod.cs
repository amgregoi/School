//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Template Method Pattern                                            //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno, (c) 2007                           //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;

namespace TemplateMethod
{
    public abstract class AbstractDisplay 
    { 
        public abstract void open();       
        public abstract void print();      
        public abstract void close();
        public void display()
        {
            open();
            for (int i = 0; i < 5; i++)
            {
                print();
            }
            close();
        }         
    }

    public class CharDisplay : AbstractDisplay 
    {  
        private char ch;                               
        public CharDisplay(char ch)
        {                 
            this.ch = ch;                            
        }
        public override void open() 
        {                        
            System.Console.Write("<<");                
        }
        public override void print() 
        {  
            System.Console.Write(ch); 
        }
        public override void close() {    
            System.Console.WriteLine(">>");
        }
    }

    //public class StringDisplay : AbstractDisplay { 
    //  // Complete the method
    //}

    class Driver
    {
        static void Main(string[] args)
        {
            AbstractDisplay d1 = new CharDisplay('H');
            //AbstractDisplay d2 = new StringDisplay("Hello, world.");
            //AbstractDisplay d3 = new StringDisplay("Hello, KSU");
            d1.display();
            //d2.display();
            //d3.display(); 
            Console.Write("To terminate the program, type CR : ");
            Console.ReadLine();
        }
    }
}
