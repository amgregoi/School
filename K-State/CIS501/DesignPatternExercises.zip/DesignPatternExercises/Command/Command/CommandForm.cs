//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Command Pattern   (CommandForm.cs)                                 //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Modified and ported to C# by Masaaki Mizuno, (c) 2007, 2010        //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Command
{
    public partial class CommandForm : Form
    {
        private MacroCommand history = new MacroCommand();
        private DrawPanel drawPanel;
        public CommandForm()
        {
            InitializeComponent();
        }

        private void CommandForm_Load(object sender, EventArgs e)
        {
            drawPanel = new DrawPanel(pnl, history);
            DrawCommand.DrawPanel = drawPanel;
            pnl.Paint += new PaintEventHandler(drawPanel.pnlPaintHandler);
        }

        private Boolean mouseDown = false;

        private void drawPanel_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
        }

        private void drawPanel_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        private void drawPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                Command cmd = new DrawCommand(new Point(e.X, e.Y));
                history.append(cmd);
                cmd.execute();
                history.undoListClear();
            }
        }

        private void btnUndo_Click(object sender, EventArgs e)
        {
            history.undo();
        }

        private void btnRedo_Click(object sender, EventArgs e)
        {
            history.redo();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            history.clear();
            drawPanel.Refresh();
        }


    }
}