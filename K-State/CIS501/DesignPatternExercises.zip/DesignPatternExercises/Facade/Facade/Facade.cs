//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Facade Pattern                                                     //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Modified and Ported to C# by Masaaki Mizuno, (c) 2007, 2010        //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Facade
{
    public class Database
    {
        public Dictionary<string, string> getDictionary(String dbname) {
            Dictionary<string, string> db = new Dictionary<string, string>();
            string filename = "../../" + dbname + ".txt";
            StreamReader reader = new StreamReader(new FileStream(
                filename, FileMode.Open, FileAccess.Read));
            string line;
            try {
                while((line = reader.ReadLine()) != null)
                {
                    int delimiter = line.IndexOf("=");
                    db.Add(line.Substring(0, delimiter), line.Substring(delimiter+1, line.Length-(delimiter+1)));
                }

            } catch (IOException) {
                System.Console.Error.WriteLine("Warning: " + filename + " is not found.");
            }
            return db;
        }
    }

    public class HtmlWriter {
        private StreamWriter writer;
        public HtmlWriter(StreamWriter writer) { 
            this.writer = writer;
        }
        public void title(string title) { 
            writer.WriteLine("<html>");
            writer.WriteLine("<head>");
            writer.WriteLine("<title>" + title + "</title>");
            writer.WriteLine("</head>");
            writer.WriteLine("<body>");
            writer.WriteLine("<h1>" + title + "</h1>");
        }
        public void paragraph(string msg) { 
            writer.WriteLine("<p>" + msg + "</p>");
        }
        public void link(string href, string caption){
            paragraph("<a href=\"" + href + "\">" + caption + "</a>");
        }
        public void mailto(string mailaddr, string username) {
            link("mailto:" + mailaddr, username);
        }
        public void close() {  
            writer.WriteLine("</body>");
            writer.WriteLine("</html>");
            writer.Close();
        }
    }

    public class PageMaker {
        Database db = new Database();
        Dictionary<string, string> maildb;

        public PageMaker(string dbFileName)
        {
            maildb = db.getDictionary(dbFileName);
        }

        public void makeWelcomePage(string mailaddr, string filename) {
            try {              
                String username = maildb[mailaddr];
                HtmlWriter htmlWriter = new HtmlWriter(new StreamWriter(new FileStream
                    (filename, FileMode.OpenOrCreate, FileAccess.Write)));
                htmlWriter.title("My name is " + username);
                // add a couple of lines to make the correct output

                htmlWriter.mailto(mailaddr, username);
                htmlWriter.close();
                System.Console.WriteLine(filename + " is created for " + mailaddr +
			     " (" + username + ")");
            } catch (IOException e) {
                System.Console.Error.WriteLine(e.StackTrace);
            }
        }
    }
    class Driver
    {
        static void Main(string[] args)
        {
            PageMaker pageMaker = new PageMaker("maildata");
            pageMaker.makeWelcomePage("hyuki@hyuki.com", "welcome.html");
        }
    }
}
