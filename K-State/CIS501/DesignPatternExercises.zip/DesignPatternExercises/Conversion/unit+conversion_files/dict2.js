var Sourses=0;
var click_block=0;
var IsTFD=0;
var word='';
var Domain='thefreedictionary.com';
var Sources=0;
var AdResults=0;
var OResults='';
var GResults='';
var IsG=false;
var kw='';
var moreAds=[];
var AdsNum=3;
var IE=(navigator.appName=='Microsoft Internet Explorer' && navigator.userAgent.indexOf("Opera")==-1?1:0);
function ById(id){return document.getElementById(id)}
function dictionary(){
if (click_block){
click_block=0;
return;
}
if (!IE){
t = document.getSelection();
opennewdictwin(t);
}
else {
t = document.selection.createRange();
if(document.selection.type == 'Text' && t.text != ''){
document.selection.empty();
opennewdictwin(t.text);
}}}
function opennewdictwin(text){
while (text.substr(text.length-1,1)==' ')
	text=text.substr(0,text.length-1)
while (text.substr(0,1)==' ')
	text=text.substr(1)
if (text > ''){
var newloc='http://www.'+Domain+'/'+escape(text);
if (document.location.toString().toLowerCase()!=newloc.toLowerCase()) document.location=newloc;
}}
function wiki(){}
function foldoc(){document.write('<br><div class=brand_copy>This article is provided by FOLDOC - Free Online Dictionary of Computing (<a target=_blank href="http://www.foldoc.org">www.foldoc.org</a>)</div><br>')};
function cde(){document.write('<br><div class=brand_copy>Computer Desktop Encyclopedia copyright �1981-2005 by <a target=_blank href=http://www.computerlanguage.com/tfd.html>The Computer Language Company Inc</a>. All Right reserved. THIS COPYRIGHTED DEFINITION IS FOR PERSONAL USE ONLY. All other reproduction is strictly prohibited without permission from the publisher</div><br>')};
function law(){document.write('<div class=brand_copy>Copyright � 1981-2005 by <a target=_blank href=http://www.farlex.com/hills.htm>Gerald N. Hill and Kathleen T. Hill</a>. All Right reserved.</div>')};
function hm(){document.write('<div class=brand_copy>The American Heritage� Dictionary of the English Language, Fourth Edition copyright &copy;2000 by <a target=_blank href="http://www.eref-trade.hmco.com/">Houghton Mifflin Company</a>. Updated in 2003. Published by <a target=_blank href="http://www.eref-trade.hmco.com/">Houghton Mifflin Company</a>. All rights reserved.</div><br>')};
function hutch(){document.write('<div class=brand_copy>This article is &copy; Research Machines plc 2004. All rights reserved. <a target=_blank href=http://www.helicon.co.uk>Helicon Publishing</a> is a division of Research Machines plc.</div>')};
function columbia(){document.write('<br><div class=brand_copy>The Columbia Electronic Encyclopedia� Copyright � 2005, Columbia University Press. Licensed from Columbia University Press. All rights reserved. <A target=_blank href="http://www.cc.columbia.edu/cu/cup/">www.cc.columbia.edu/cu/cup/</A></div>')};
function harvey(){document.write('<br><div class=brand_copy>Copyright � 2004, <A target=_blank href="http://www.duke.edu/~charvey/">Campbell R. Harvey</A>. All Rights Reserved.</div>')};
function investorwords(){document.write('<br><div class=brand_copy>This definition is provided by <A target=_blank href="http://www.investorwords.com/">InvestorWords.com</A>. Copyright&copy; 1997-2005 by WebFinance Inc. All Rights Reserved.</div>')};
function hm_med(){document.write('<p class=brand_copy>The American Heritage� Stedman\'s Medical Dictionary, 2nd Edition Copyright � 2004 by Houghton Mifflin Company. Published by <a target=_blank href="http://www.eref-trade.hmco.com/">Houghton Mifflin Company</a>. All rights reserved.</p>')}
function oxf(){document.write('<p class=brand_copy><i>Oxford Dictionary of English</i> 2<sup>nd</sup> Edition revised, ISBN 0-19-861057-2 � Oxford University Press 2005</p>')};
function investopedia(){document.write('<br><p class=brand_copy>Powered by <a target=_blank href="http://www.investopedia.com">Investopedia.com</a>. Copyright � 1999-2005 - All rights reserved. Owned and Operated by Investopedia Inc.</p>')};
function acr(){document.write('<p><a target=_blank href="http://app.thefreedictionary.com/newacronym.aspx?acr='+escape(word)+'">submit new definition</a></p>');
acr_copy();};
function acr_copy(){document.write('<div class=brand_copy>Powered by <a target=_blank href="http://www.acronymfinder.com">AcronymFinder.com</a> &copy; 1988-2005, Mountain Data Systems, All rights reserved.</div>')};
function IdiI(){document.write('<p class=brand_copy><i><a target=_blank href="http://www.cambridge.org/elt/elt_projectpage.asp?id=2500249">Cambridge International Dictionary of Idioms</a></i> � Cambridge University Press 1998</p>');
Sources=Sources | 0x4000;
}
function IdiA(){
document.write('<p class=brand_copy><i><a target=_blank href="http://www.cambridge.org/elt/elt_projectpage.asp?id=2500256">Cambridge Dictionary of American Idioms</a></i> � Cambridge University Press 2003</p>');
Sources=Sources | 0x8000;
}
function Attribution(){
	if (Sources & 0x8) hm_med();
	if (Sources & 0x10) columbia();
	if (Sources & 0x20) cde();
	if (Sources & 0x40) foldoc();
	//if (Sources & 0x80) wiki();
	if (Sources & 0x100) harvey();
	if (Sources & 0x200) investorwords();
	if (Sources & 0x400) acr();
	if (Sources & 0x1000) law();
	if (Sources & 0x2000) hutch();
	if (Sources & 0x10000) oxf();
	if (Sources & 0x20000) investopedia();
}
var nsx;
var nsy;
if (!document.all){
	document.captureEvents(Event.MOUSEMOVE);
	document.onmousemove=get_mouse;
}
function get_mouse(e){
	nsx=e.pageX-10;
	nsy=e.pageY+5;
}
function t_i(id){
	var hlp=ById('Tp'+id);
	if (hlp){
	if (document.all){
	 nsy=event.y+document.body.scrollTop;
	 nsx=event.x+document.body.scrollLeft;
	}
	hlp.style.top=nsy+20;
	hlp.style.left=(nsx>610?nsx-470:140);
	hlp.style.visibility='visible';
}}
function t_o(id){
	var hlp=ById('Tp'+id);
	if(hlp) hlp.style.visibility='hidden';
}
function el(a){
if (a.substr(0,3)!='ftp') a='http://'+a;
window.open(a, '_blank');
}
function eml2(path, name){open('/_/viewer.aspx?path='+escape(path)+'&name='+name,'img','')};
function eml(path, name){location='/_/viewer.aspx?path='+escape(path)+'&name='+name,'view'};
function hil(name){eml2('hut',name)};
function hmil(name){eml2('hm',name)};
function hmil_med(name){eml2('hm/med',name)};
function openerlink(link){
opener.location='http://encyclopedia.'+Domain+'/'+link;
self.close();
return false;
}
var g_kw=0;
function google_ad_request_done(google_ads){
	var i=0;
	IsG=true;
	if (g_kw) GResults=google_ads.length;
	if (!g_kw || google_ads.length>=3){
	for (i=0;i<google_ads.length && i<AdsNum;i++){
	 if (i==0){
		if (IsTFD)
			document.write('<div class=Ov id=Ov style="width:185px;float:right;clear:right;background-color:white"><div class=OvBorder>');
		else
			document.write('<span class=by>Ads by Goooooogle</span>');
	 }
	 if (!IsTFD && i>0) document.write('<div class=AdSep></div>');
	 write_ad(google_ads[i]);
	}
	AdResults=i;
	if (AdResults<=google_ads.length){
		moreAds=new Array(google_ads.length-AdResults);
		for (i=AdResults;i<google_ads.length;i++)
			moreAds[i-AdResults]=google_ads[i];
	}
	}
	if (IsTFD){
		if (i) document.write('</div><div style="text-align:center;color:blue;font-size:8pt">Ads by Goooooogle</div></div>');
		}
	else if (i==0)
		if (g_kw){
			g_kw=0;
			google_ad_width = 468;
			google_ad_height = 60;
			google_ad_format = "468x60_as";
			google_ad_output = "js";
			google_prev_ad_formats_by_region=null;
			google_encoding="iso-8859-1";
			google_ad_channel =ad_channel;
			document.write('<script language="JavaScript1.1" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></'+'script>');
		}
}
function ad(url,visible_url,line1,line2,line3){this.url=url;this.visible_url=visible_url;this.line1=line1;this.line2=line2;this.line3=line3;}
function write_ad(ad){
	 document.write('<a href="http://www.thefreedictionary.com/_/gr.aspx?source='+escape(top.location)+'&url='+escape(ad.url)+'" onMouseOver="return m_over(\''+(IsG?'go to ':'http://')+ad.visible_url+'\')" onMouseOut="m_out()">');
	 if (IsTFD)
	 document.write('<div class=OvTitle>'+ad.line1+'</div><div class=OvDescr>'+ad.line2+' '+ad.line3+'</div><span class=OvURL>'+ad.visible_url+'</span></a><br>');
	 else
	 document.write('<span class=OvTitle>'+ad.line1+'</span><br><span class=OvDescr>'+ad.line2+' '+ad.line3+'</span><br><span class=OvURL>'+ad.visible_url+'</span></a>');
}
function write_more_ads(){
	if (moreAds.length){
	document.write('<div class=Ov><div class=OvBorder'+(AdsNum==2?' style="background-color:#EDF1F3"':'')+'><span class=by>'+(IsG?'Ads by Goooooogle':'Sponsored links')+'</span>');
	for (i=0;i<moreAds.length && i<AdsNum;i++){
		if (!IsTFD && i>0) document.write('<div class=AdSep></div>');
		write_ad(moreAds[i]);
		}
	document.write('</div></div>');
	}
}
function myerror(){
//document.write('<iframe src="http://www.thefreedictionary.com/_/deftopad.aspx" border=0 frameborder=0 width="95%" height=90 scrolling=no></iframe><br>');
window.onerror=null;
return true;
}
function m_over(url){
window.status=url;
return true;
}
function m_out(){
window.status = '';
}
function play(File){
var s='http://img.tfd.com/hm/prons/'+File+'.wav';
if (IE && navigator.platform=='Win32'){
	document.all.bgsound.src=s;
	setTimeout('document.all.bgsound.src="about:blank"', 8000);
} else if(ById("sound_frame")) {
	var snd=ById("sound_frame");
	snd.src='about:blank';
	snd.src=s;
	setTimeout('ById("sound_frame").src="about:blank"', 8000);
} else 
	window.location=s;
window.status='';
}
function pron_key(t){
var pkw=open('/_/pk.htm','pk','width=630,height=675,statusbar=0,menubar=0');
return false;
}
var SignedIn=0;
function hut(f){
Sources=Sources | 0x2000;
var t=' please sign-in or <a href="https://secure.farlex.com/protected/subscribe.aspx?url='+escape(location.href)+'">register</a> for a free trial.</p>'
if (!SignedIn)
	switch(f){
	case 1:document.write('<p><b><font color=red>This article is available to subscribers only.</font></b> To read this article'+t);break;
	case 3:document.write('<p><b><font color=red>Only a portion of this article is shown. The entire article is available to subscribers.</font></b> To read this article in its entirety'+t);break;
	}
}
function homepage(root){
var ua=navigator.userAgent;
if (IE && ua.indexOf("Win")!=-1 && !eval('hp.is'+'Homepage(\'http://www.'+Domain+'/\')')){
	document.write('<a href="/" onMouseOver="return m_over(\'set www.'+Domain+' as home page\')" onMouseOut="m_out()" onClick="style.b'+'ehavior=\'url(#'+'default#'+'homepage)\';setHome'+'Page(\'http://www.'+Domain+'/\');">');
	document.write((root?'Set as Home Page</a> |':'<img src=http://img.tfd.com/m/home.gif align=absbottom>set as home page</a>'));
	}
}
function toggle(id){
	var img=ById('toggle_img_'+id);
	var td=ById('toggle_td_'+id).style;
	if (td.display=='none'){
		td.display='';
		toggle_store(id,0);
		img.src=img.src.replace('right','down');
	}
	else {
		td.display='none';
		toggle_store(id,1);
		img.src=img.src.replace('down','right');
	}
}
function toggle_store(id, hide){
	var c='0'+getCookie('t2');
	if (hide)
		c=c|(1<<(id-1));
	else
		c=c & (~(1<<(id-1)));
	setCookie('t2',c);
}
function toggle_retrieve(id){
	var c=getCookie('t2');
	if (c) c=Number(c);
	else c=1;
	if (c&(1<<(id-1))) toggle(id);
}
function getCookie(name){
	var dc=document.cookie;
	var prefix=name+'=';
	var s = dc.indexOf('; ' + prefix);
	if (s==-1){
		s=dc.indexOf(prefix);
		if (s != 0) return null;
	}
	else
		 s+=2;
	var e=dc.indexOf(';', s);
	if (e==-1)
		 e=dc.length;
	return unescape(dc.substring(s+prefix.length, e));
}
function setCookie(name, value){
	document.cookie=name+'='+escape(value)+
	'; expires=Thu, 1 Jan 2015 05:00:00 UTC; path=/; domain='+Domain;
}
function KWTrack(){
if (kw>'' && (OResults>0 || GResults>0))
	document.write('<img width=1 height=1 style="display:none" src=http://ad.db3nf.com/pix.aspx?w='+escape(kw)+'&o='+OResults+'&g='+GResults+'>');
UpdadeSearchForms();
if (document.f1 && window.location.toString().indexOf('#')<0) window.setTimeout('document.f1.Word.focus()',100);
}
var tfd_searchby_HTML=null;
function UpdadeSearchForms(){
var SearchCookie=getCookie('searchBy');
if (SearchCookie){
	for (var f=1;f<=2;f++){
		var form=eval('document.f'+f);
		if (form) {
			var f_sd=ById('f'+f+'_sd');
			if (f_sd) {
				if (f_sd.innerHTML.indexOf('firstname_begins_with')<0) tfd_searchby_HTML=f_sd.innerHTML;
				if (SearchCookie!=8) 
					{if (f_sd.innerHTML.indexOf('firstname_begins_with')>0) f_sd.innerHTML=tfd_searchby_HTML;}
				else
					f_sd.innerHTML='<table cellspacing=0 cellpadding=2><tr><td valign=bottom>First Name<div style="font-size:8pt;height:20px"><input type=checkbox name=firstname_begins_with value=1 checked>Begins with</div><input size=8 name=Word maxlength=25><td><td valign=bottom>Last Name<div style="font-size:8pt;height:20px"><input type=checkbox name=name_begins_with value=1>Begins with</div><input size=8 name=name maxlength=25></td><td valign=bottom>Location<div style="font-size:8pt;padding-top:4px;padding-bottom:1px">(City, State, Area code or ZIP)</div><input size=16 name=where maxlength=100></td><td valign=bottom><input type=submit value=Search></td></tr></table>';
			}
			for (var i=0;i<form.elements.length;i++){
				var bt=form.elements[i];
				if (bt.type) if (bt.type=='radio') if (bt.value==SearchCookie) bt.checked=true;
			}
			var search_by_obj=ById('f'+f+'_tfd_searchby');
			if (search_by_obj) search_by_obj.style.visibility=(SearchCookie>3 && SearchCookie!=8?'hidden':'');
		}
	}
}}
function _SearchBy(by){
	setCookie('searchBy', by.value);
	UpdadeSearchForms();
}
function tshirt(Tx1,Tx2,Tx3,Tx4,Tx5){
	var url='http://www.spreadshirt.com/shop.php?sid=16702&product_id=1047372&tx1='+escape(Tx1)+'&tx2='+escape(Tx2)+'&tx3='+escape(Tx3)+'&tx4='+escape(Tx4)+'&tx5='+escape(Tx5);
	url='/_/gr.aspx?tshirt=1&url='+escape(url);
	document.write('<a href="'+url+'"><img width=16 height=16 src="http://img.tfd.com/m/tshirt_s.gif" border=0></a>');
}