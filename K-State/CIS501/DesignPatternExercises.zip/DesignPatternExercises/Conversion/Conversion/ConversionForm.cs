
//////////////////////////////////////////////////////////////////////
//  Strategy Pattern (Unit Conversion Program)  ConversionForm.cs   //
//  Written by Masaaki Mizuno, (c) 2007                             //
//      for Learning Tree Courses 123P and 252P                     //
//      also for K-State course cis501                              //
//////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Conversion
{
    public partial class ConversionForm : Form
    {
        public Strategy currentStrategy;
        public List<Strategy> strategies = new List<Strategy>();

        public ConversionForm()
        {
            InitializeComponent();
        }
        
        private void ConversionForm_Load(object sender, EventArgs e)
        {
            Strategy.initialize(this);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double from;

            try
            {
                if (rd1to2.Checked)
                {
                    from = double.Parse(txt1.Text);
                    txt2.Text = string.Format("{0:F2}",
                        currentStrategy.LeftToRight(from));
                }
                else
                {
                    from = double.Parse(txt2.Text);
                    txt1.Text = string.Format("{0:F2}",
                        currentStrategy.RightToLeft(from));
                }
            }
            catch (Exception)
            {
                currentStrategy.Init();
            }
        }

        private void cbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selected = cbType.SelectedIndex;
            currentStrategy = strategies[selected];
            currentStrategy.Init();
        }

    }
}