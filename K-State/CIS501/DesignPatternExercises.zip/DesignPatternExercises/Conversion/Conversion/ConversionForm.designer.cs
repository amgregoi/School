namespace Conversion
{
    partial class ConversionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.rd1to2 = new System.Windows.Forms.RadioButton();
            this.rd2to1 = new System.Windows.Forms.RadioButton();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.cbType = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(79, 169);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(72, 20);
            this.button1.TabIndex = 0;
            this.button1.Text = "Convert";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(3, 77);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(100, 20);
            this.txt1.TabIndex = 1;
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(121, 77);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(100, 20);
            this.txt2.TabIndex = 2;
            // 
            // rd1to2
            // 
            this.rd1to2.Checked = true;
            this.rd1to2.Location = new System.Drawing.Point(70, 106);
            this.rd1to2.Name = "rd1to2";
            this.rd1to2.Size = new System.Drawing.Size(110, 20);
            this.rd1to2.TabIndex = 3;
            this.rd1to2.TabStop = true;
            this.rd1to2.Text = "Fah to Cen";
            // 
            // rd2to1
            // 
            this.rd2to1.Location = new System.Drawing.Point(70, 132);
            this.rd2to1.Name = "rd2to1";
            this.rd2to1.Size = new System.Drawing.Size(92, 20);
            this.rd2to1.TabIndex = 4;
            this.rd2to1.Text = "Cen to Fah";
            // 
            // lbl1
            // 
            this.lbl1.Location = new System.Drawing.Point(3, 54);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(100, 20);
            this.lbl1.TabIndex = 7;
            this.lbl1.Text = "Fahrenheit";
            // 
            // lbl2
            // 
            this.lbl2.Location = new System.Drawing.Point(121, 54);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(100, 20);
            this.lbl2.TabIndex = 6;
            this.lbl2.Text = "Centigrade";
            // 
            // cbType
            // 
            this.cbType.Location = new System.Drawing.Point(28, 17);
            this.cbType.Name = "cbType";
            this.cbType.Size = new System.Drawing.Size(168, 21);
            this.cbType.TabIndex = 5;
            this.cbType.SelectedIndexChanged += new System.EventHandler(this.cbType_SelectedIndexChanged);
            // 
            // ConversionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(224, 211);
            this.Controls.Add(this.cbType);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.rd2to1);
            this.Controls.Add(this.rd1to2);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.button1);
            this.Name = "ConversionForm";
            this.Text = "Unit Converter";
            this.Load += new System.EventHandler(this.ConversionForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label lbl1;
        public System.Windows.Forms.ComboBox cbType;
        public System.Windows.Forms.TextBox txt1;
        public System.Windows.Forms.TextBox txt2;
        public System.Windows.Forms.RadioButton rd1to2;
        public System.Windows.Forms.RadioButton rd2to1;
        public System.Windows.Forms.Label lbl2;
    }
}

