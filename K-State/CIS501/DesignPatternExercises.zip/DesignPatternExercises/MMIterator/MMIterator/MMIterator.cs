//////////////////////////////////////////////////////////////////
//  MMIterator                                                  //
//  Written by Masaaki Mizuno, (c) 2007                         //
//      for Learning Tree Course 252P                           //
//      also for K-State Course cis501                          //
//////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;

namespace MMIterator
{
    class State
    {
        string name;
        public State(string name)
        {
            this.name = name;
        }
        public override string ToString()
        {
            return name;
        }
    }

    interface QueueIterator
    {
        Boolean hasNext();
        object next();
    }

    interface Queue
    {
        void enQueue(object item);
        object deQueue();
        QueueIterator queueIterator();
    }

    class ArrayQueue: Queue
    {
        public const int MAXITEMS = 5;
        object[] queue = new object[MAXITEMS];
        int head = 0;
        int tail = 0;
        int num = 0;
        public void enQueue(object st)
        {
            if (num < MAXITEMS)
            {
                queue[tail++] = st;
                tail %= MAXITEMS;
                num++;
            }
            else
            {
                System.Console.WriteLine("ArrayQueue Overflow Error");
            }
        }
        public object deQueue()
        {
            if (num > 0)
            {
                object item = queue[head++];
                head %= MAXITEMS;
                num--;
                return item; 
            }
            else
            {
                System.Console.WriteLine("ArrayQueue Underflow Error");
                return null;
            }
        }
        public QueueIterator queueIterator() 
        {
            return new ArrayQueueIterator(this);
        }
        internal int Tail
        {
            get{return tail;}
        }
        internal int Head
        {
            get{return head;}
        }
        internal int Num
        {
            get { return num; }
        }
        internal object getAt(int index)
        {
            return queue[index];
        }
    }

    class ArrayQueueIterator : QueueIterator
    {
        ArrayQueue arrayQueue;
        int index;
        int num;
        internal ArrayQueueIterator(ArrayQueue arrayQueue)
        {
            this.arrayQueue = arrayQueue;
            index = arrayQueue.Head;
            num = arrayQueue.Num;
        }
        public Boolean hasNext()
        {
          // Complete the method
            return false;  // this is dummy
        }
        public object next()
        {
          // complete the method
            return new object(); // this is dummy
        }
    }

    class ListNode
    {
        object item;
        ListNode next;
        public ListNode(object item, ListNode next)
        {
            this.item = item;
            this.next = next;
        }
        public object Item
        {
            get { return item; }
        }
        public ListNode Next
        {
            get { return next; }
            set { next = value; }
        }
    }
    class ListQueue: Queue
    {
        ListNode head = null; 
        ListNode tail = null;
        public void enQueue(object item)
        {
            if (tail == null)
            {
                head = tail = new ListNode(item, null);
            }
            else
            {
                tail = tail.Next = new ListNode(item, null);
            }
        }
        public object deQueue()
        {
            if (head != null)
            {
                ListNode ln = head;
                head = ln.Next;
                if (head == null) tail = null;
                return ln.Item;
            }
            else
            {
                System.Console.WriteLine("List Queue Underflow Error");
                return null;
            }
        }
        public QueueIterator queueIterator()
        {
            return new ListQueueIterator(this);
        }
        internal ListNode Head
        {
            get{return head;}
        }
        internal ListNode Tail
        {
            get{return tail;}
        }
    }

    class ListQueueIterator : QueueIterator
    {
        ListQueue listQueue;
        ListNode currentPtr;
        internal ListQueueIterator(ListQueue listQueue)
        {
            this.listQueue = listQueue;
            currentPtr = listQueue.Head;
        }
        public Boolean hasNext()
        {
           // complete the method
            return false; // this is dummy
        }
        public object next()
        {
            // complete the method
            return new object(); // this is dummy
        }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            Queue que = new ArrayQueue();
            //Queue que = new ListQueue();
            que.enQueue(new State("Kansas"));
            que.enQueue(new State("Ohio"));
            que.enQueue(new State("California"));
            que.enQueue(new State("Michigan"));
            que.enQueue(new State("Pennsylvania"));

            //Uncomment the following two lines
            QueueIterator qi = que.queueIterator();
            while (qi.hasNext()) System.Console.WriteLine(qi.next());

            System.Console.WriteLine(que.deQueue());
            System.Console.WriteLine(que.deQueue());
            System.Console.WriteLine(que.deQueue());
            System.Console.WriteLine(que.deQueue());
            System.Console.WriteLine(que.deQueue());
        }
    }
}
