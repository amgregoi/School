//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Observer Pattern                                                   //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno, (c) 2007                           //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Observer
{
    public abstract class Observer
    {
        public abstract void update();
    }

    public class Model
    {
        private List<Observer> observers = new List<Observer>();
        public void addObserver(Observer observer)
        {
            observers.Add(observer);
        }
        public void deleteObserver(Observer observer)
        {
            observers.Remove(observer);
        }
        public void notifyObservers()
        {
            // Complete the body
         
        }
    }

    public class RandomNumberGenerator : Model
    {
        private Random random = new Random();   
        private int number;                     // current value
        public int getNumber() {       
            return number;
        }
        public void execute() {
            for (int i = 0; i < 20; i++) {
                number = random.Next(50);
                notifyObservers();
            }
        }
    }
    public class DigitObserver : Observer 
    {
        RandomNumberGenerator generator;
        public DigitObserver(RandomNumberGenerator generator)
        {
            this.generator = generator;
        }
        public override void update() {
            System.Console.WriteLine("DigitObserver:" + generator.getNumber());
            Thread.Sleep(100);
        }
    }


    public class GraphObserver : Observer {
        RandomNumberGenerator generator;
        public GraphObserver(RandomNumberGenerator generator)
        {
            this.generator = generator;
        }
        public override void update() {
            System.Console.Write("GraphObserver:");
            int count = generator.getNumber();
            for (int i = 0; i < count; i++) {
                System.Console.Write("*");
            }
            System.Console.WriteLine("");
            Thread.Sleep(100);
        }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            RandomNumberGenerator generator = new RandomNumberGenerator();
            Observer observer1 = new DigitObserver(generator);
            Observer observer2 = new GraphObserver(generator);
            // Write what you have to do before calling generator.execute();
            // Then, add one more GraphObserver object
            generator.execute();
        }
    }
}
