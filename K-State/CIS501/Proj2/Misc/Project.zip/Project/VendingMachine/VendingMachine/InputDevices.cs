﻿//////////////////////////////////////////////////////////////////////
//      Vending Machine (Actuators.cs)                              //
//      Written by Masaaki Mizuno, (c) 2006, 2007, 2008, 2010, 2011 //
//                      for Learning Tree Course 123P, 252J, 230Y   //
//                 also for KSU Course CIS501                       //  
//////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine
{
    // For each class, you can (must) add fields and overriding constructors

    public class CoinInserter
    {
        public CoinInserter()
        {
        }
        //public void CoinInserted()
        //{
        //    // You can add only one line here
        //}

        // The following method is to show how CoinInserted works and how to use ListDialog
        public void CoinInserted()
        {
            UnitedNations un = new UnitedNations();
            List<Nation> nationsList = un.MakeList();

            ListDialog ld = new ListDialog();
            object[] displayItems = nationsList.ToArray();
            ld.AddDisplayItems(displayItems);
            ld.ShowDialog();
        }
    }

    public interface VMButton
    {
        void ButtonPressed();
    }

    public class PurchaseButton : VMButton
    {
        public PurchaseButton()
        { 
        }
        public void ButtonPressed()
        {
            // You can add only one line here
        }
    }

    public class CoinReturnButton : VMButton
    {
        public CoinReturnButton()
        {
        }
        public void ButtonPressed()
        {
            // You can add only one lines here
        }
    }

    public class SalesRecordListButton : VMButton
    {
        public SalesRecordListButton()
        {
        }
        public void ButtonPressed()
        {
            // You can add only one line herer
        }
    }

    public class SalesRecordClearButton : VMButton
    {
        public SalesRecordClearButton()
        {
        }

        public void ButtonPressed()
        {
            // You can add only one line here
        }
    }
}
