﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace VehicleRegistration
{
    public partial class VehicleRegistrationSystem : Form
    {
        public VehicleRegistrationSystem()
        {
            InitializeComponent();
        }

        private void bnDone_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bnRegDealer_Click(object sender, EventArgs e)
        {
            DealerRegistrationDialogbox drd = new DealerRegistrationDialogbox();
            if (drd.ShowDialog() != DialogResult.OK) return;

        }

        private void bnRegVehicle_Click(object sender, EventArgs e)
        {
            VehicleRegistrationDialogbox vrd = new VehicleRegistrationDialogbox();
            if (vrd.ShowDialog() != DialogResult.OK) return;

        }

        private void bnRegOwner_Click(object sender, EventArgs e)
        {
            OwnerRegistrationDialogbox ord = new OwnerRegistrationDialogbox();
            if (ord.ShowDialog() != DialogResult.OK) return;
           
        }

        private void bnDeleteDealer_Click(object sender, EventArgs e)
        {

        }

        private void bnDeleteVehicle_Click(object sender, EventArgs e)
        {

        }

        private void bnDeleteOwner_Click(object sender, EventArgs e)
        {
 
        }

        private void bnListVehicles_Click(object sender, EventArgs e)
        {
            ListDialog ld = new ListDialog();
            //ld.AddDisplayItems(/* pass object[] */);
            ld.ShowDialog();
        }

        private void bnListOwners_Click(object sender, EventArgs e)
        {
            ListDialog ld = new ListDialog();
            //ld.AddDisplayItems(/* pass object[] */);
            ld.ShowDialog();
        }

        private void bnListDealers_Click(object sender, EventArgs e)
        {
            ListDialog ld = new ListDialog();
            //ld.AddDisplayItems(/* pass object[]*/);
            ld.ShowDialog();
        }

        private void bnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "VRS Files|*.vrs";
            saveFileDialog.AddExtension = true;
            saveFileDialog.InitialDirectory = Application.StartupPath;
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                System.IO.FileStream f = new System.IO.FileStream(saveFileDialog.FileName,
                    System.IO.FileMode.Create);
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter fo = new
                    System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

               
            }
        }

        private void bnRestore_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "VRS Files|*.vrs";
            openFileDialog.InitialDirectory = Application.StartupPath;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                System.IO.FileStream f = new System.IO.FileStream(openFileDialog.FileName,
                    System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.Read);
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter fo = new
                 System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                
  
            }
        }

        private void bnTransfer_Click(object sender, EventArgs e)
        {
            OwnershipTransferDialogbox otd = new OwnershipTransferDialogbox();
            if (otd.ShowDialog() != DialogResult.OK) return;
 
        }

        private void bnListOwnedVehicles_Click(object sender, EventArgs e)
        {
            LocateOwnerDialogbox lod = new LocateOwnerDialogbox();
            if (lod.ShowDialog() != DialogResult.OK) return;
           
        }

        private void ListOwnerHistory_Click(object sender, EventArgs e)
        {
            LocateVehicleDialogbox lvd = new LocateVehicleDialogbox();
            if (lvd.ShowDialog() != DialogResult.OK) return;

        }

        private void bnLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "VRS Info Files|*.inf";
            openFileDialog.InitialDirectory = Application.StartupPath;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {

                TextReader trs = new StreamReader(openFileDialog.FileName);
                string s;
                List<string> words;
                int stringIndex;
                while (((s = trs.ReadLine()) != null) && (s != ""))
                {
                    words = new List<string>();
                    while (true)
                    {
                        if ((stringIndex = s.IndexOf('"')) == -1) break;
                        s = s.Substring(stringIndex + 1);
                        stringIndex = s.IndexOf('"');
                        words.Add(s.Substring(0, stringIndex));
                        s = s.Substring(stringIndex + 1);
                    }
                    // Add your logic
                }

            }
        }
    }
}
