//////////////////////////////////////////////////////////////////////
//  Strategy Pattern (Unit Conversion Program)  Strategy.cs         //
//  Written by Masaaki Mizuno, (c) 2007                             //
//      for Learning Tree Courses 123P and 252P                     //
//      also for K-State course cis501                              //
//////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;

namespace Conversion
{
    public abstract class Strategy
    {
        protected ConversionForm myForm;
        
        public static void initialize(ConversionForm myForm)
        {
            myForm.cbType.Items.Add("Fah/Cel");
            myForm.cbType.Items.Add("Lb/Kg");
            myForm.cbType.Items.Add("Mile/Km");
            myForm.cbType.Items.Add("G/L");
            myForm.cbType.Items.Add("MpG/KpL");
            myForm.cbType.Items.Add("Ft/Mt");
            myForm.strategies.Add(new FToC(myForm));
            myForm.strategies.Add(new LToK(myForm));
            myForm.strategies.Add(new MToK(myForm));
            myForm.strategies.Add(new GToL(myForm));
            myForm.strategies.Add(new MgToKl(myForm));
            myForm.strategies.Add(new FToM(myForm));
            myForm.cbType.SelectedIndex = 0;
            myForm.currentStrategy = myForm.strategies[0];
            myForm.currentStrategy.Init();
        }

        protected Strategy(ConversionForm myForm)
        {
            this.myForm = myForm;
        }

        internal abstract void Init();
        internal abstract double LeftToRight(double from);
        internal abstract double RightToLeft(double from);
    }

    class FToC : Strategy
    {
        internal FToC(ConversionForm myForm)
            : base(myForm)
        {
        }

        internal override void Init()
        {
            myForm.lbl1.Text = "Fahrenheit";
            myForm.lbl2.Text = "Centigrade";
            myForm.rd1to2.Text = "Fah to Cen";
            myForm.rd2to1.Text = "Cen to Fah";
            myForm.txt1.Text = "0.0";
            myForm.txt2.Text = "0.0";
            myForm.rd1to2.Checked = true;
        }

        internal override double LeftToRight(double from)
        {
            return (from - 32) / 1.8;
        }

        internal override double RightToLeft(double from)
        {
            return from * 1.8 + 32;
        }
    }

    class LToK : Strategy
    {
        internal LToK(ConversionForm myForm)
            : base(myForm)
        {
        }

        internal override void Init()
        {
            myForm.lbl1.Text = "Lb";
            myForm.lbl2.Text = "Kilo Grams";
            myForm.rd1to2.Text = "Lb to Kg";
            myForm.rd2to1.Text = "Kg to Lb";
            myForm.txt1.Text = "0.0";
            myForm.txt2.Text = "0.0";
            myForm.rd1to2.Checked = true;
        }

        internal override double LeftToRight(double from)
        {
            return from * 0.45359237;
        }

        internal override double RightToLeft(double from)
        {
            return from / 0.45359237;
        }
    }

    class MToK : Strategy
    {
        internal MToK(ConversionForm myForm)
            : base(myForm)
        {
        }

        internal override void Init()
        {
            myForm.lbl1.Text = "Miles";
            myForm.lbl2.Text = "Kilo Meters";
            myForm.rd1to2.Text = "Mile to Kilo";
            myForm.rd2to1.Text = "Kilo to Mile";
            myForm.txt1.Text = "0.0";
            myForm.txt2.Text = "0.0";
            myForm.rd1to2.Checked = true;
        }

        internal override double LeftToRight(double from)
        {
            return from * 1.609347219;
        }

        internal override double RightToLeft(double from)
        {
            return from / 1.609347219;
        }
    }

    class FToM : Strategy
    {
        internal FToM(ConversionForm myForm)
            : base(myForm)
        {
        }

        internal override void Init()
        {
            myForm.lbl1.Text = "Feet";
            myForm.lbl2.Text = "Meters";
            myForm.rd1to2.Text = "Feet to Meters";
            myForm.rd2to1.Text = "Meters to Feet";
            myForm.txt1.Text = "0.0";
            myForm.txt2.Text = "0.0";
            myForm.rd1to2.Checked = true;
        }

        internal override double LeftToRight(double from)
        {
            return from * 0.3048;
        }

        internal override double RightToLeft(double from)
        {
            return from / 0.3048;
        }
    }

    class GToL : Strategy
    {
        internal GToL(ConversionForm myForm)
            : base(myForm)
        {
        }

        internal override void Init()
        {
            myForm.lbl1.Text = "Gallons";
            myForm.lbl2.Text = "Liters";
            myForm.rd1to2.Text = "Gallons to Liters";
            myForm.rd2to1.Text = "Liters to Gallons";
            myForm.txt1.Text = "0.0";
            myForm.txt2.Text = "0.0";
            myForm.rd1to2.Checked = true;
        }

        internal override double LeftToRight(double from)
        {
            return from * 3.7854;
        }

        internal override double RightToLeft(double from)
        {
            return from / 3.7854;
        }
    }

    class MgToKl : Strategy
    {
        internal MgToKl(ConversionForm myForm)
            : base(myForm)
        {
        }

        internal override void Init()
        {
            myForm.lbl1.Text = "Miles/Gallon";
            myForm.lbl2.Text = "Kilo Meters/Liter";
            myForm.rd1to2.Text = "MpG to KpL";
            myForm.rd2to1.Text = "KpL to MpG";
            myForm.txt1.Text = "0.0";
            myForm.txt2.Text = "0.0";
            myForm.rd1to2.Checked = true;
        }

        internal override double LeftToRight(double from)
        {
            return from * 0.425145;
        }

        internal override double RightToLeft(double from)
        {
            return from / 0.425145;
        }
    }
}
