//////////////////////////////////////////////////////////
//                                                      //
//  State Machine Diagram Implementation                //
//  Translation Algorithm developed by M. Mizuno        //
//  Written by Masaaki Mizuno, (c)2010                  //
//      for Learning Tree Course 252P                   //
//      also for K-State Course cis501 and cis621       //
//                                                      //
//////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StateMachineDiagram
{
    public class Context
    {
        public State CurrentState{get; private set;}
        public Context()
        {
            CurrentState = null;
        }
        public void setState(State nextState)
        {
          if (CurrentState != null) CurrentState.exitSequence();
          CurrentState = nextState;
            Console.WriteLine("Current State : " + CurrentState);
          CurrentState.entrySequence();
        }
    }

    public abstract partial class State
    {
        protected CompositeState SuperState {get; private set; }
        abstract public void entrySequence();
        abstract public void exitSequence();
    }

    public class SimpleState: State
    {
        public SimpleState(Context context):this(context, null){}
        public SimpleState(Context context, State superState) : base(context, superState) { }
        public override void entrySequence()
        {
            entry();
        }
        public override void exitSequence()
        {
            exit();
        }
        protected virtual void entry(){}
        protected virtual void exit(){}
    }

    public abstract class CompositeState: State
    {
        protected State CurrentSubState { get; private set; }
        public CompositeState(Context context): this(context, null){}
        public CompositeState(Context context, State superState) : base(context, superState)
        {
            CurrentSubState = null;
        }
        public void setSubState(State nextSubState)
        {
           if (CurrentSubState != null) CurrentSubState.exitSequence();
           CurrentSubState = nextSubState;
             Console.WriteLine(" Current SubState : " + CurrentSubState);
           CurrentSubState.entrySequence();
        }

        public override void entrySequence() {setSubState(entry());}
        public override void exitSequence() {
          CurrentSubState.exitSequence();
          exit();
          CurrentSubState = null;
        }
        protected abstract State entry(); // entry() must return the initial sub state
        protected virtual void exit(){}
    }

    public abstract partial class State
    {
        protected CPlayer Context{get; private set;}
        public State(Context context, State superState)
        {
            this.Context = (CPlayer)context;
            this.SuperState = (CompositeState)superState;
        }
  
        public virtual void powerButton(){}
        public virtual void volPlusButton(){}
        public virtual void playButton(){}
        public virtual void stopButton(){}
    }

    public class CPlayer: Context
    {
        public State PowerOff{get; private set;}
        public State PowerOn{get; private set;}
        public State Play{get; private set;}
        public State Stop{get; private set;}

        public CPlayer()
        {
            PowerOff = new PowerOff(this);
            PowerOn = new PowerOn(this);
            Play = new Play(this, PowerOn);
            Stop = new Stop(this, PowerOn);
        }
        public void powerButton(){CurrentState.powerButton();}
        public void volPlusButton(){CurrentState.volPlusButton();}
        public void playButton() {CurrentState.playButton();}
        public void stopButton() {CurrentState.stopButton();}

        public void setOn(){Console.WriteLine("SetOn() was called");}
        public void setOff(){Console.WriteLine("SetOff() was called");}
        public void volUp(){Console.WriteLine("VolUp() was called");}
        public void startPlay(){Console.WriteLine("StartPlay() was called");}
        public void stopPlay(){Console.WriteLine("StopPlay() was called");}
    }

    public class PowerOff: SimpleState
    {
        public PowerOff(Context context):base(context){}

        public override void  powerButton()
        {
 	         Context.setState(Context.PowerOn);
        }

        public override string ToString()
        {
            return "Power Off";
        }
    }

    public class Play : SimpleState
    {
        public Play(Context context, State superState) : base(context, superState) { }
        public override void stopButton()
        {
            Context.stopPlay();
            SuperState.setSubState(Context.Stop);
        }

        public override string ToString()
        {
            return "Play";
        }
    }

    public class Stop : SimpleState
    {
        public Stop(Context context, State superState) : base(context, superState) { }
        public override void playButton()
        {
            Context.startPlay();
            SuperState.setSubState(Context.Play);
        }
        public override string ToString()
        {
            return "Stop";
        }
    }

    public class PowerOn: CompositeState
    {
        public PowerOn(Context context):base(context){}
        protected override State  entry()
        {
 	        Context.setOn();
            return Context.Stop;
        }
        protected override void exit()
        { 
            Context.setOff();
        }
        public override void powerButton()
        {
            Context.setState(Context.PowerOff);
        }

        public override void playButton()
        {
            CurrentSubState.playButton();
        }
        public override void stopButton()
        {
            CurrentSubState.stopButton();
        }
        public override void volPlusButton()
        {
            Context.volUp();
        }
        public override string ToString()
        {
            return "Power On";
        }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            int button;
            CPlayer cplayer = new CPlayer();
            cplayer.setState(cplayer.PowerOff);

            while (true)
            {
                Console.Write("\n 1: PowerButton\n 2: PlayButton\n 3: StopButton\n 4: VolPlsButton\n 0: DONE\nInput: ");
                try
                {
                    button = int.Parse(Console.ReadLine());
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    return;
                }
                switch (button)
                {
                    case 1: cplayer.powerButton(); break;
                    case 2: cplayer.playButton(); break;
                    case 3: cplayer.stopButton(); break;
                    case 4: cplayer.volPlusButton(); break;
                    default: return;
                }
            }
        }
    }
}
