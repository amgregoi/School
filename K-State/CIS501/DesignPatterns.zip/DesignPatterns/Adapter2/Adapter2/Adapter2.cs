//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Adapter Pattern 2                                                  //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno, (c) 2007                           //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;

namespace Adapter2
{
    public class Banner {
        private string st;
        public Banner(string st) {
            this.st = st;
        }
        public void showWithParen() {
            System.Console.WriteLine("(" + st + ")");
        }
        public void showWithAster() {
            System.Console.WriteLine("*" + st + "*");
        }
    }

    public abstract class Print {
        public abstract void printWeak();
        public abstract void printStrong();
    }


    public class PrintBanner : Print {
        private Banner banner;
        public PrintBanner(string st) {
            this.banner = new Banner(st);
        }
        public override void printWeak() {
            banner.showWithParen();
        }
        public override void printStrong() {
            banner.showWithAster();
        }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            Print p = new PrintBanner("Hello");
            p.printWeak();
            p.printStrong();
        }
    }
}
