//////////////////////////////////////////////////////////
//                                                      //
//  Deep/Shallow Copies                                 //
//  Written by Masaaki Mizuno, (c)2007                  //
//      for Learning Tree Course  252P                  //
//      also for K-State Course cis501                  //
//                                                      //
//////////////////////////////////////////////////////////
using System;

namespace Copy
{
	class Class0
	{
		public int i;
		public double j;

		public Class0()
		{
		}
		public static Class0 copy(Class0 org)
		{
			Class0 dst = new Class0();
            dst.i = org.i;
            dst.j = org.j;
            return dst;
		}

        public override string ToString()
        {
            return "   Class0: i = " + i + ",   j = " + j;
        }
	}
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		public Class0 c0;
		public float f;

        public Class1()
        {
        }

		public static Class1 copy(Class1 org)
		{
			Class1 dst = new Class1();

            dst.f = org.f;  
            dst.c0 = Class0.copy(org.c0);   // deep copy
            //dst.c0 = org.c0;              // shallow copy
            return dst;
		}

        public override string ToString()
        {
            return "Class1: f = " + f + ",  " + c0;
        }
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			//
			// TODO: Add code to start application here
			//
			Class0 c0 = new Class0();
            c0.i = 10;
            c0.j = 3.14;

			Class1 c1a = new Class1();
            c1a.f = 3.1415f;
            c1a.c0 = c0;

            Class1 c1b = Class1.copy(c1a);

            c1a.c0.i = 200;
            Console.WriteLine(c1a);
            Console.WriteLine(c1b);
		}
	}
}
