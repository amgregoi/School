//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Singleton Pattern                                                  //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno, (c) 2007                           //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;

namespace Singleton
{
    public class Singleton
    {
        private static Singleton singleton = new Singleton();
        private Singleton() {                                 
        System.Console.WriteLine("The instance was constructed.");
    }
        public static Singleton getInstance()
        {
            return singleton;
        }
    }

    class Driver
    {
        static void Main(String[] args)
        {
            System.Console.WriteLine("Start.");
            Singleton obj1 = Singleton.getInstance();
            Singleton obj2 = Singleton.getInstance();
            if (obj1 == obj2) {
                System.Console.WriteLine("obj1 and obj2 are the same");
            } else {
                System.Console.WriteLine("obj1 and obj2 are not the same");
            }
            System.Console.WriteLine("End.");
        }
    }
}
