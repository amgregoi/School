//////////////////////////////////////////////////////////
//                                                      //
//  MM Abstract Factory                                 //
//  Written by Masaaki Mizuno, (c)2007                  //
//      for Learning Tree Course  252P                  //
//      also for K-State Course cis501                  //
//                                                      //
//////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace MMAbstractFactory
{
    interface Type1
    {
        string whoAreYou();
    }
    interface Type2
    {
        string dare();
    }
    interface Type3
    {
        string introduceYourself();
    }

    class A1 : Type1
    {
        public string whoAreYou() { return "A1"; }
    }
    class B1 : Type1
    {
        public string whoAreYou() { return "B1"; }
    }
    class C1 : Type1
    {
        public string whoAreYou() { return "C1"; }
    }

    class A2 : Type2
    {
        public string dare() { return "A2"; }
    }
    class B2 : Type2
    {
        public string dare() { return "B2"; }
    }
    class C2 : Type2
    {
        public string dare() { return "C2"; }
    }

    class A3 : Type3
    {
        public string introduceYourself() { return "A3"; }
    }
    class B3 : Type3
    {
        public string introduceYourself() { return "B3"; }
    }
    class C3 : Type3
    {
        public string introduceYourself() { return "C3"; }
    }

    interface Factory
    {
        Type1 createType1();
        Type2 createType2();
        Type3 createType3();
    }

    class FA : Factory
    {
        public Type1 createType1() { return new A1(); }
        public Type2 createType2() { return new A2(); }
        public Type3 createType3() { return new A3(); }
    }
    class FB : Factory
    {
        public Type1 createType1() { return new B1(); }
        public Type2 createType2() { return new B2(); }
        public Type3 createType3() { return new B3(); }
    }
    class FC : Factory
    {
        public Type1 createType1() { return new C1(); }
        public Type2 createType2() { return new C2(); }
        public Type3 createType3() { return new C3(); }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            if (args.Length != 1)
            {
                Console.WriteLine("Usage: MMAbstractFactory A (B, or C)");
                Environment.Exit(0);
            }
            try
            {
                Type t = Type.GetType("MMAbstractFactory.F" + args[0]);
                Factory f = (Factory)Activator.CreateInstance(t);
                Type1 t1 = f.createType1();
                Type2 t2 = f.createType2();
                Type3 t3 = f.createType3();
                Console.WriteLine(t1.whoAreYou());
                Console.WriteLine(t2.dare());
                Console.WriteLine(t3.introduceYourself());
            }
            catch (Exception e)
            {
                Console.WriteLine("Usage: MMAbstractFactory A (B, or C)\n" + e);
            }
        }
    }
}
