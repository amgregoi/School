//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Bridge Pattern                                                     //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Modified and ported to C# by Masaaki Mizuno, (c) 2007              //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;

namespace Bridge
{
    public class Display {
        private DisplayImpl impl;
        public Display(DisplayImpl impl) {
            this.impl = impl;
        }
        public void open() {
            impl.rawOpen();
        }
        public void print() {
            impl.rawPrint();
        }
        public void close() {
            impl.rawClose();
        }
        public void display() {
            open();
            print();                    
            close();
        }
    }


    public class CountDisplay : Display {
        public CountDisplay(DisplayImpl impl):base(impl){ }
        public void multiDisplay(int times) {
            open();
            for (int i = 0; i < times; i++) {
                print();
            }
            close();
        }
    }


    public abstract class DisplayImpl {
        public abstract void rawOpen();
        public abstract void rawPrint();
        public abstract void rawClose();
    }

    public class StringDisplayImpl: DisplayImpl {
        private string st; 
        private int width;    
        public StringDisplayImpl(string st) { 
            this.st = st;                
            this.width = st.Length;
        }
        public override void rawOpen() {
            printLine();
        }
        public override void rawPrint() {
            System.Console.WriteLine("|" + st + "|"); 
        }
        public override void rawClose() {
            printLine();
        }
        private void printLine() {
            System.Console.Write("+");                  
            for (int i = 0; i < width; i++) {      
                System.Console.Write("-");            
            }
            System.Console.WriteLine("+");             
        }
    }
    public class CharDisplayImpl :  DisplayImpl { 
        private char ch;                               
        public CharDisplayImpl(char ch) {             
            this.ch = ch;                            
        }
        public override void rawOpen() {                     
            System.Console.Write("<<");                
        }
        public override void rawPrint() {                  
            System.Console.Write(ch);                
        }
        public override void rawClose() {                
            System.Console.WriteLine(">>");          
        }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            Display d1 = new Display(new StringDisplayImpl("Hello, Japan."));
            Display d2 = new Display(new StringDisplayImpl("Hello, World."));
            CountDisplay d3 = new CountDisplay(new StringDisplayImpl("Hello, Universe."));
            CountDisplay d4 = new CountDisplay(new CharDisplayImpl('M'));
            Display d5 = new Display(new CharDisplayImpl('X'));
            d1.display();
            d2.display();
            d3.display();
            d3.multiDisplay(5);
            d4.display();
            d4.multiDisplay(8);
            d5.display();
        }
    }
}
