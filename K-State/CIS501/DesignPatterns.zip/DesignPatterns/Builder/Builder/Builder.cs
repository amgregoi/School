//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Builder Pattern                                                    //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno, (c) 2007                           //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Builder
{
    public abstract class Builder {
        public abstract void makeTitle(string title);
        public abstract void makeString(string str);
        public abstract void makeItems(string[] items);
        public abstract void close();
    }

    public class Director {
        private Builder builder;
        public Director(Builder builder) {      
            this.builder = builder;            
        }
        public void construct() {             
            builder.makeTitle("Greeting");     
            builder.makeString("In the morning"); 
            builder.makeItems(new String[]{  
                "Good morning",
                "Have a nice day",
            });
            builder.makeString("At night");
            builder.makeItems(new String[]{       
                "Good evening",
                "Good night",
                "Have a good night sleep",
            });
            builder.close(); 
        }
    }

    public class TextBuilder : Builder {
        private StringBuilder sb = new StringBuilder();       
        public override void makeTitle(string title) {                  
            sb.AppendLine("==============================");
            sb.AppendLine("|" + title);          
            sb.AppendLine();                            
        }
        public override void makeString(string str) {               
            sb.AppendLine('~' + str);            
            sb.AppendLine();                         
        }
        public override void makeItems(string[] items) {         
            for (int i = 0; i < items.Length; i++) {
                sb.AppendLine(" ." + items[i]); 
            }
            sb.AppendLine();                          
        }
        public override void close() {                            
            sb.AppendLine("==============================");
        }
        public String getResult() {                          
            return sb.ToString();                       
        }
    }

    public class HTMLBuilder : Builder {
        private string filename;                      
        private FileStream file;
        private StreamWriter writer;         
        public override void makeTitle(string title) {       
            filename = title + ".html";            
            try {
                file = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.Write);
                writer = new StreamWriter(file);
            } catch (IOException e) {
                System.Console.WriteLine(e.StackTrace);
            }
            writer.WriteLine("<html><head><title>" + title + "</title></head><body>");   
            writer.WriteLine("<h1>" + title + "</h1>");
        }
        public override void makeString(string str) {                       
            writer.WriteLine("<p>" + str + "</p>");                 
        }
        public override void makeItems(string[] items) {                  
            writer.WriteLine("<ul>");                             
            for (int i = 0; i < items.Length; i++) {
                writer.WriteLine("<li>" + items[i] + "</li>");
            }
            writer.WriteLine("</ul>");
        }
        public override void close() {                                  
            writer.WriteLine("</body></html>");                 
            writer.Close();                                  
        }
        public String getResult() {                         
            return filename;                               
        }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            if (args.Length != 1) {
                usage();
                Environment.Exit(0);
            }
            if (args[0].Equals("plain")) {
                TextBuilder textbuilder = new TextBuilder();
                Director director = new Director(textbuilder);
                director.construct();
                String result = textbuilder.getResult();
                System.Console.WriteLine(result);
            } else if (args[0].Equals("html")) {
                HTMLBuilder htmlbuilder = new HTMLBuilder();
                Director director = new Director(htmlbuilder);
                director.construct();
                String filename = htmlbuilder.getResult();
                System.Console.WriteLine(filename + "was created");
            } else {
                usage();
                Environment.Exit(0);
            }
        }
        public static void usage() {
            System.Console.WriteLine("Usage: Builder plain      in plain text");
            System.Console.WriteLine("Usage: Builder html       in HTML");
        }
    }
}
