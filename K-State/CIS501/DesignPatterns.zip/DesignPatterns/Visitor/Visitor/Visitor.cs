//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Visitor Pattern                                                    //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Modified and Ported to C# by Masaaki Mizuno, (c) 2007, 2010        //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;

namespace Visitor
{
    public interface Visitor {
        void visit(File file);
        void visit(Directory directory);
    }

    public interface Acceptor {
        void accept(Visitor v);
    }

    public abstract class Entry : Acceptor {
        public virtual Entry add(Entry entry) { 
            throw new FileTreatmentException();
        }
        public virtual List<Entry> FileList 
        {
            get
            {
                throw new FileTreatmentException();
            }
        }
        public abstract void accept(Visitor v);
    }


    public class File : Entry {
        private string name;
        public File(string name) {
            this.name = name;
        }
        public string Name
        {
            get { return name; }
        }
        public override void accept(Visitor v) {
            v.visit(this);
    // L1:
        }
    }

    public class Directory : Entry {
        private string name;   
        private List<Entry> fileList = new List<Entry>();   
        public Directory(string name) {     
            this.name = name;
        }
        public string Name
        {
            get { return name; }
        }
        public override Entry add(Entry entry) {  
            fileList.Add(entry);
            return this;
        }
        public override List<Entry> FileList 
        {  // This method is added to help a visitor
            get
            {
                return fileList;
            }
        }
        public override void accept(Visitor v) { 
            v.visit(this);
    //L2:
        }
    }

    public class ListVisitor : Visitor {
        private string currentdir = ""; 
        public void visit(File file) { 
            System.Console.WriteLine(currentdir + "/" + file.Name);
        }
        public void visit(Directory directory) { 
            System.Console.WriteLine(currentdir + "/" + directory.Name);
            String savedir = currentdir;
            currentdir = currentdir + "/" + directory.Name;
            foreach (Entry entry in directory.FileList)
            {
                entry.accept(this);
    //L3:
            }
            currentdir = savedir;
        }
    }


    public class FileTreatmentException : Exception {
        public FileTreatmentException() {
        }
        public FileTreatmentException(String msg) : base(msg){ }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            try {
                System.Console.WriteLine("Making root entries...");
                Directory rootdir = new Directory("root");
                Directory bindir = new Directory("bin");
                rootdir.add(bindir).add(new File("hanako"));
                bindir.add(new File("vi"));
             
                rootdir.accept(new ListVisitor());  
        //L4:
            } catch (FileTreatmentException e) {
                System.Console.Error.WriteLine(e.StackTrace);
            }
        }
    }
}
