//////////////////////////////////////////////////////////
//                                                      //
//  MM Factory Method                                   //
//  Written by Masaaki Mizuno, (c)2007                  //
//      for Learning Tree Course  252P                  //
//      also for K-State Course cis501                  //
//                                                      //
//////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace MMFactoryMethod
{
    interface Master
    {
        void doMyWork();
        Slave create();
    }
    interface Slave
    {
        string whoAreYou();
    }

    class MA : Master
    {
        public void doMyWork() { Console.WriteLine("I am Master A"); }
        public Slave create() { return new SA(); }
    }
    class MB : Master
    {
        public void doMyWork() { Console.WriteLine("Master B, here"); }
        public Slave create() { return new SB(); }
    }
    class MC : Master
    {
        public void doMyWork() { Console.WriteLine("This is Master C"); }
        public Slave create() { return new SC(); }
    }

    class SA : Slave
    {
        public string whoAreYou() { return "SA"; }
    }
    class SB : Slave
    {
        public string whoAreYou() { return "SB"; }
    }
    class SC : Slave
    {
        public string whoAreYou() { return "SC"; }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            Master m;
            m = new MA();
            //m = new MB();
            //m = new MC();

            m.doMyWork();
            Slave s = m.create();
            Console.WriteLine("I can create ojbects of " + s.whoAreYou());
        }
    }
}