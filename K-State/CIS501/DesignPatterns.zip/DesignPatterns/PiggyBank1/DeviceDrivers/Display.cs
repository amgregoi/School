﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DeviceDrivers
{
    public interface DisplayInterface
    {
        void DisplayAmount(decimal amount);
    }

    public class Display: TextBox, DisplayInterface
    {
        public void DisplayAmount(decimal amount)
        {
            Text = "\\" + amount;
        }
    }
}
