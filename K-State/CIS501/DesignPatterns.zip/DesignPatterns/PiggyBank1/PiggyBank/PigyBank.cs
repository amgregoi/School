﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DeviceDrivers;

namespace PiggyBank
{
    public partial class PigyBank : Form
    {
        DisplayInterface display;
        decimal currentAmount;
        public PigyBank()
        {
            InitializeComponent();
        }

        private void PigyBank_Load(object sender, EventArgs e)
        {
            display = dl_amountDiaplay;
            currentAmount = 0;
            dl_amountDiaplay.DisplayAmount(currentAmount);
        }

        

        private void bt_10Yen_Click(object sender, EventArgs e)
        {
            currentAmount += 10;
            dl_amountDiaplay.DisplayAmount(currentAmount);
        }

        private void bt_50Yen_Click(object sender, EventArgs e)
        {
            currentAmount += 50;
            dl_amountDiaplay.DisplayAmount(currentAmount);
        }

        private void bt_100Yen_Click(object sender, EventArgs e)
        {
            currentAmount += 100;
            dl_amountDiaplay.DisplayAmount(currentAmount);
        }

        private void bt_Clear_Click(object sender, EventArgs e)
        {
            currentAmount = 0;
            dl_amountDiaplay.DisplayAmount(currentAmount);
        }


    }
}
