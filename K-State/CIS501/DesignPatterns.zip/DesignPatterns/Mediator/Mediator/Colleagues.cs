﻿//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Mediator Pattern (Colleagues.cs)                                   //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Modified and ported to C# by Masaaki Mizuno, (c) 2007, 2010        //
//      for Learning Tree Course 252P                                   //
//      also for K-State Course cis501                                  //
//                                                                      //
//////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace Mediator
{
    public class ColleagueButton : LoginColleague
    {
        private LoginMediator loginMediator;
        Button btn;
        public ColleagueButton(LoginMediator loginMediator, Button btn)
        {
            this.btn = btn;
            this.loginMediator = loginMediator; 
        }

        public void setColleagueEnabled(Boolean enabled)
        {
            btn.Enabled = enabled;
        }

        public void btnClickHandler(object sender, EventArgs e)
        { 
            Application.Exit();
        }
    }

    public class ColleagueRadioButton: LoginColleague
    {
        private LoginMediator loginMediator;
        RadioButton rb;
        public ColleagueRadioButton(LoginMediator loginMediator, RadioButton rb)
        {
            this.loginMediator = loginMediator;
            this.rb = rb;
        }
        public Boolean Checked
        {
            set
            {
                rb.Checked = value;
            }
            get
            {
                return rb.Checked;
            }
        }
      
        public void setColleagueEnabled(Boolean enabled)
        {
            rb.Enabled = enabled;
        }

        public void rbCheckChangedHander(object sender, EventArgs e)
        {
            loginMediator.colleagueChanged(this);
        }
    }

    public class ColleagueTextBox : LoginColleague
    {
        private LoginMediator loginMediator;
        TextBox tb;
        public ColleagueTextBox(LoginMediator loginMediator, TextBox tb)
        {
            this.loginMediator = loginMediator;
            this.tb = tb;
        }

        public string Text
        {
            get
            {
                return tb.Text;
            }
        }

        public void setColleagueEnabled(Boolean enabled)
        {
            tb.Enabled = enabled;
            tb.BackColor = (enabled ? Color.White : Color.LightGray);
        }
        public void tbTextChangedHandler(object sender, EventArgs e)
        {
            loginMediator.colleagueChanged(this);
        }
    }
}
