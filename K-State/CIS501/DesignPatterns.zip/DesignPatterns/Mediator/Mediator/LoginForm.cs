﻿//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Mediator Pattern (LoginForm.cs)                                    //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Modified and ported to C# by Masaaki Mizuno, (c) 2007, 2010        //
//      for Learning Tree Course 252P                                   //
//      also for K-State Course cis501                                  //
//                                                                      //
//////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mediator
{
    public partial class LoginForm : Form, LoginMediator
    {
        ColleagueButton okButton, cancelButton;
        ColleagueRadioButton guestRadioButton, loginRadioButton;
        ColleagueTextBox usernameTextBox, passwordTextBox;
     
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            okButton = new ColleagueButton(this, bnOK);
            cancelButton = new ColleagueButton(this, bnCancel);
            guestRadioButton = new ColleagueRadioButton(this, rbGuest);
            loginRadioButton = new ColleagueRadioButton(this, rbLogin);
            usernameTextBox = new ColleagueTextBox(this, tbUsername);
            passwordTextBox = new ColleagueTextBox(this, tbPassword);

            //createColleagues();
            guestRadioButton.Checked = true;
            colleagueChanged(guestRadioButton);

            bnCancel.Click += new EventHandler(cancelButton.btnClickHandler);
            bnOK.Click += new EventHandler(okButton.btnClickHandler);
            rbLogin.CheckedChanged += new EventHandler(loginRadioButton.rbCheckChangedHander);
            rbGuest.CheckedChanged += new EventHandler(guestRadioButton.rbCheckChangedHander);
            tbUsername.TextChanged += new EventHandler(usernameTextBox.tbTextChangedHandler);
            tbPassword.TextChanged += new EventHandler(passwordTextBox.tbTextChangedHandler);
        }

        public void colleagueChanged(LoginColleague colleague)
        {
            if (guestRadioButton.Checked)
            { // Guest mode
                usernameTextBox.setColleagueEnabled(false);
                passwordTextBox.setColleagueEnabled(false);
                okButton.setColleagueEnabled(true);
            }
            else
            { // Login mode
                usernameTextBox.setColleagueEnabled(true);
                userpassChanged();
            }
        }

        private void userpassChanged()
        {
            if (usernameTextBox.Text.Length > 0)
            {
                passwordTextBox.setColleagueEnabled(true);
                if (passwordTextBox.Text.Length > 0)
                {
                    okButton.setColleagueEnabled(true);
                }
                else
                {
                    okButton.setColleagueEnabled(false);
                }
            }
            else
            {
                passwordTextBox.setColleagueEnabled(false);
                okButton.setColleagueEnabled(false);
            }
        }
    }
}
