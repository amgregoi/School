//////////////////////////////////////////////////////////
//                                                      //
//  MM Reflection                                       //
//  Written by Masaaki Mizuno, (c)2007                  //
//      for Learning Tree Course  252P                  //
//      also for K-State Course cis501                  //
//                                                      //
//////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace Reflection
{
    class A
    {
        public int a;
        public float b;
        public A()
        {
            a = 10;
            b = 3.14f;
        }

        public void doubleAB()
        {
            a *= 2;
            b *= 2;
        }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            //Type t = typeof(A);
            Type t = Type.GetType("Reflection.A");

            Console.WriteLine("**** List Type t's information ****");
            Console.WriteLine("Type Name:  " + t.Name);
            Console.WriteLine("Full Name:  " + t.FullName);
            Console.WriteLine("NameSpace:  " + t.Namespace);

            MemberInfo[] Members = t.GetMembers();
            foreach (MemberInfo member in Members)
            {
                Console.WriteLine(member.MemberType + "   " + member.Name);
            }

            Console.WriteLine("**** Create a new object with ActivateInstance ****");
            object obj = Activator.CreateInstance(t);

            FieldInfo[] Fields = t.GetFields();
            foreach (FieldInfo field in Fields)
            {
                Console.WriteLine(field.Name + " = " + field.GetValue(obj));
            }
            Console.WriteLine("**** Invoke doubleAB() ****");
            MethodInfo[] Methods = t.GetMethods();
            foreach (MethodInfo method in Methods)
            {
                if (method.Name == "doubleAB")
                    method.Invoke(obj, null);
            }

            Fields = t.GetFields();
            foreach (FieldInfo field in Fields)
            {
                Console.WriteLine(field.Name + " = " + field.GetValue(obj));
            }

        }
    }
}
