//////////////////////////////////////////////////////////////////
//  MM Delegate 2                                               //
//  Written by Masaaki Mizuno, (c) 2006                         //
//      for Learning Tree Course 252P                           //
//      also for K-State Course cis501                          //
//////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;

namespace MMDelegate2
{
    class A1
    {
        public int a = 13;
        public void f(){Console.WriteLine("A1's f()");}
    }

    class B1:A1
    {
        public int b = 7;
        public void g(){Console.WriteLine("B1's g()");}
    }

    class C1:A1
    {
        public int c = 99;
        public void h(){Console.WriteLine("C1's h()");}
    }

    interface BC
    {
    }

    class A2
    {
        public int a = 13;
        public BC bc;
        public void f() { Console.WriteLine("A2's f()"); }
    }

    class B2:BC
    {
        public int b = 7;
        public void g() { Console.WriteLine("B2's g()"); }
    }

    class C2:BC
    {
        public int c = 99;
        public void h() { Console.WriteLine("C2's h()"); }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            Console.WriteLine("******* A1, B1, C1 ************");
            A1 a1;
            Console.WriteLine("=== B1===");
            a1 = new B1();
            Console.WriteLine("B1's a = " + a1.a);
            a1.f();
            if (a1 is B1)
            {
                Console.WriteLine("B1's b = " + ((B1)a1).b);
                ((B1)a1).g();
            }
            else if (a1 is C1)
            {
                Console.WriteLine("C1's c = " + ((C1)a1).c);
                ((C1)a1).h();
            }

            Console.WriteLine("\n=== C1 ===");
            a1 = new C1();
            Console.WriteLine("C1's a = " + a1.a);
            a1.f();
            if (a1 is B1)
            {
                Console.WriteLine("B1's b = " + ((B1)a1).b);
                ((B1)a1).g();
            }
            else if (a1 is C1)
            {
                Console.WriteLine("C1's c = " + ((C1)a1).c);
                ((C1)a1).h();
            }


            Console.WriteLine("\n*************** A2, B2, C2 *************");
            A2 a2;
            Console.WriteLine("=== A2-B2 ===");
            a2 = new A2();
            a2.bc = new B2();
            Console.WriteLine("B2's a = " + a2.a);
            a2.f();
            if (a2.bc is B2)
            {
                Console.WriteLine("B2's b = " + ((B2)a2.bc).b);
                ((B2)a2.bc).g();
            }
            else if (a2.bc is C2)
            {
                Console.WriteLine("C2's c = " + ((C2)a2.bc).c);
                ((C2)a2.bc).h();
            }

            Console.WriteLine("\n=== A2-C2 ===");
            a2.bc = new C2();
            Console.WriteLine("C2's a = " + a2.a);
            a2.f();
            if (a2.bc is B2)
            {
                Console.WriteLine("B2's b = " + ((B2)a2.bc).b);
                ((B2)a2.bc).g();
            }
            else if (a2.bc is C2)
            {
                Console.WriteLine("C2's c = " + ((C2)a2.bc).c);
                ((C2)a2.bc).h();
            }
        }
    }
}