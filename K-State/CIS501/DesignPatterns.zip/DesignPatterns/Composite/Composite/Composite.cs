//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Composite Pattern                                                  //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Modified and Ported to C# by Masaaki Mizuno, (c) 2007, 2008        //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;

namespace Composite
{
    public abstract class Entry {
        public virtual Entry add(Entry entry) {  
            throw new FileTreatmentException();
        }

        public abstract void printList(string prefix);            
    }


    public class File : Entry {
        private string name;
        public File(string name) {
            this.name = name;
        }
        public override void printList(string prefix) {
            System.Console.WriteLine(prefix + "/" + name);
        }
    }

    public class Directory : Entry {
        private string name;        
        private List<Entry> directory = new List<Entry>();   
        public Directory(string name) {        
            this.name = name;
        }
        public override Entry add(Entry entry) {     
            directory.Add(entry);
            return this;
        }
        public override void printList(string prefix) { 
            System.Console.WriteLine(prefix + "/" + name);
            foreach(Entry entry in directory)
            {
                entry.printList(prefix + "/" + name);
    // L1:
            }
        }
    }

    public class FileTreatmentException : Exception {
        public FileTreatmentException() {}
        public FileTreatmentException(String msg) : base(msg){}
    }

    class Driver
    {
        static void Main(string[] args)
        {
            try {
                System.Console.WriteLine("Making root entries...");
                Directory rootdir = new Directory("root");
                Directory bindir = new Directory("bin");
                rootdir.add(bindir).add(new File("hanako"));
                bindir.add(new File("vi"));
      
                rootdir.printList("");
    // L2:
            } catch (FileTreatmentException e) {
                System.Console.Error.WriteLine(e.StackTrace);
            }
        }
    }
}
