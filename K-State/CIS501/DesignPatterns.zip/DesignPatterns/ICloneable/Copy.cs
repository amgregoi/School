//////////////////////////////////////////////////////////
//                                                      //
//  Deep/Shallow Copies                                 //
//  Written by Masaaki Mizuno, (c)2007                  //
//      for Learning Tree Course  252P                  //
//      also for K-State Course cis501                  //
//                                                      //
//////////////////////////////////////////////////////////
using System;

namespace Copy
{
	class Class0:ICloneable
	{
		public int i = 10;
		public double j = 3.14;

		public Class0()
		{
		}
		public Object Clone()
		{
			Class0 dst = new Class0();
            dst.i = this.i;
            dst.j = this.j;
            return dst;
		}

        public override string ToString()
        {
            return "   Class0: i = " + i + ",   j = " + j;
        }
	}
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1:ICloneable
	{
		public Class0 c0;
		public float f = 1.414f;

        public Class1()
        {
        }

        public Class1(Class0 c0)
        {
            this.c0 = c0;
        }

		public Object Clone()
		{
			Class1 dst = new Class1();

            dst.f = this.f;  
            dst.c0 = (Class0)((this.c0).Clone());   // deep copy
            //dst.c0 = this.c0;              // shallow copy
            return dst;
		}

        public override string ToString()
        {
            return "Class1: f = " + f + ",  " + c0;
        }
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			//
			// TODO: Add code to start application here
			//
			Class0 c0 = new Class0();

			Class1 c1a = new Class1(c0);

            Class1 c1b = (Class1)(c1a.Clone());

            c1a.c0.i = 200;
            Console.WriteLine(c1a);
            Console.WriteLine(c1b);
		}
	}
}
