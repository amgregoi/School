//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Adapter Pattern 1                                                  //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno, (c) 2007                           //
//      for Learning Tree Course 252P                                   //
//      also for K-State Course cis501                                  //
//                                                                      //
//////////////////////////////////////////////////////////////////////////  
using System;
using System.Collections.Generic;
using System.Text;

namespace Adapter1
{
    public class Banner {
        private string st;
        public Banner(string st) {
            this.st = st;
        }
        public void showWithParen() {
            System.Console.WriteLine("(" + st + ")");
        }
        public void showWithAster() {
            System.Console.WriteLine("*" + st + "*");
        }
    }


    public interface Print {
        void printWeak();
        void printStrong();
    }


    public class PrintBanner : Banner, Print {
        public PrintBanner(string st): base(st) {
        }
        public void printWeak() {
            showWithParen();
        }
        public void printStrong() {
            showWithAster();
        }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            Print p = new PrintBanner("Hello");
            p.printWeak();
            p.printStrong();
        }
    }
}
