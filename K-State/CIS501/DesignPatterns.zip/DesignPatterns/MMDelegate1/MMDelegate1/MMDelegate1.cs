//////////////////////////////////////////////////////////////////
//  MM Delegate 1                                               //
//  Written by Masaaki Mizuno, (c) 2004                         //
//      for Learning Tree Course, 123P, 252P                    //
//      also for K-State Course cis501                          //
//////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;

namespace MMDelegate1
{
    class A1 {
        int a = 13;
        public void f() {Console.WriteLine("A1's f(), a = " + a); }
    }

    class B1 : A1 {
        int b = 7;
        public void g() {Console.WriteLine("B1's g(), b = " + b); }
    }

    class A2 {
        int a = 13;
        public void f(){Console.WriteLine("A2's f(), a = "+a);}
    }

    class B2 {
        int b = 7;
        A2 ap = new A2();
        public void f() {ap.f();}
        public void g() {Console.WriteLine("B2's g(), b = "+b);}
    }

    class A3 {
        int a = 13;
        B3 bp = new B3();
        public void f() {Console.WriteLine("A3's f(), a = " + a);}
        public void g() {bp.g();}
    }

    class B3 {
        int b = 7;
        public void g(){Console.WriteLine("B3's g(), b = " + b);}
    }

    class Driver
    {
        static void Main(string[] args)
        {
            B1 b1p = new B1();
            B2 b2p = new B2();
            A3 a3p = new A3();

            Console.WriteLine("A1, B1");
            b1p.f();
            b1p.g();

            Console.WriteLine("\nA2, B2");
            b2p.f();
            b2p.g();

            Console.WriteLine("\nA3, B3");
            a3p.f();
            a3p.g();
        }
    }
}
