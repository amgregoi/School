//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Command Pattern (Command.cs)                                       //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Modified and ported to C# by Masaaki Mizuno, (c) 2007, 2010        //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Windows;
using System.Drawing;

namespace Command
{
    public interface Command
    {
        void execute();
        void unexecute();
    }

    public class MacroCommand : Command 
    {
        private Stack<Command> doList = new Stack<Command>();
        private Stack<Command> undoList = new Stack<Command>();
        public void execute() 
        {
            foreach(Command cmd in doList)
            {
                cmd.execute();
            }
        }

        public void unexecute() {}

        public void append(Command cmd) 
        {
            if (cmd != this) 
            {
                doList.Push(cmd); 
            }
        }

        public void undo() 
        {
            if (doList.Count != 0) 
            {
                Command cmd = doList.Pop();
                undoList.Push(cmd);
                cmd.unexecute();
                this.execute(); 
                // not to erase overlapped dots
            }
        }

        public void redo()
        {
            if (undoList.Count != 0)
            {
                Command cmd = undoList.Pop();
                doList.Push(cmd);
                cmd.execute();
            }
        }

        public void clear() 
        {
            doList.Clear();
            undoList.Clear();
        }

 	    public void undoListClear() 
        {
		    undoList.Clear();
	    }
    }

    public class DrawCommand : Command 
    {
        private static Color color = Color.Red;
        private static Color unColor = Color.White;
        private static DrawPanel drawPanel;
        private const int radius = 6;
        private Point position;

        public static DrawPanel DrawPanel { set { drawPanel = value; } }

        public DrawCommand( Point position) {
            this.position = position;
        }

        public void execute() {
            drawDot(new SolidBrush(color));
        }

        public void unexecute() {
            drawDot(new SolidBrush(unColor));
        }
        private void drawDot(SolidBrush myBrush) 
        {
            Graphics panelGraphics;
            panelGraphics = drawPanel.CreateGraphics();
            panelGraphics.FillEllipse(myBrush, 
                new Rectangle(position.X - radius, position.Y - radius, 
                    radius * 2, radius * 2));
            myBrush.Dispose();
            panelGraphics.Dispose();
        }
    }
}
