﻿//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Command Pattern  (DrawPanel.cs)                                    //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Modified and ported to C# by Masaaki Mizuno, (c) 2007, 2010        //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace Command
{
    public class DrawPanel
    {
        Panel pnl;
        private MacroCommand history;

        public DrawPanel(Panel pnl, MacroCommand history)
        {
            this.pnl = pnl;
            this.history = history;
        }

        public Graphics CreateGraphics()
        {
            return pnl.CreateGraphics();
        }

        public void Refresh()
        {
            pnl.Refresh();
        }

        public void pnlPaintHandler(object Sender, PaintEventArgs e)
        {
            history.execute();
        }
    }
}
