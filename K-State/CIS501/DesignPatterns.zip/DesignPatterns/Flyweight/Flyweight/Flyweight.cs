//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Flyweight Pattern                                                  //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Modified and Ported to C# by Masaaki Mizuno, (c) 2007, 2010        //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Flyweight
{
    public class BigChar {
        private char charname;
        private string fontdata;

        public BigChar(char charname) {
            this.charname = charname;
            try {
                StreamReader reader = new StreamReader(
                    new FileStream("../../big" + charname + ".txt", FileMode.Open, FileAccess.Read)
                );
                String line;
                StringBuilder buf = new StringBuilder();
                while ((line = reader.ReadLine()) != null) {
                    buf.Append(line);
                    buf.AppendLine();
                }
                reader.Close();
                this.fontdata = buf.ToString();
            } catch (IOException) {
                this.fontdata = charname + "?";
            }
        }

        public void print() {
            System.Console.Write(fontdata);
        }
    }

    public class BigCharFactory {
        private Dictionary<string, BigChar> pool = new Dictionary<string, BigChar>();

        public BigChar getBigChar(char charname) {
            BigChar bc;
            try
            {
                bc = pool["" + charname];
            }catch(KeyNotFoundException)
            {
                bc = new BigChar(charname); 
                pool.Add("" + charname, bc);
            }
            return bc;
        }
    }

    public class BigString {
        private BigChar[] bigchars;
        private BigCharFactory factory;

        public BigString(BigCharFactory factory, string st) {
            this.factory = factory;
            bigchars = new BigChar[st.Length];
            for (int i = 0; i < bigchars.Length; i++) {
                bigchars[i] = factory.getBigChar(st[i]);
            }
        }

        public void print() {
            for (int i = 0; i < bigchars.Length; i++) {
                bigchars[i].print();
            }
        }
    }


    class Driver
    {
        static void Main(string[] args)
        {
            if (args.Length == 0) 
            {
                System.Console.WriteLine("Usage: Flyweight digits");
                System.Console.WriteLine("Example: Flyweight 1212123");
                Environment.Exit(0);
            }
            BigCharFactory factory = new BigCharFactory();
            BigString bigString = new BigString(factory, args[0]);
            bigString.print();
        }
    }
}
