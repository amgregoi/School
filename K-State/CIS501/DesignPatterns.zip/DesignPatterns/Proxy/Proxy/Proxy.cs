//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Proxy Pattern                                                      //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno, (c) 2007                           //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Proxy
{
    public interface Printable {
        string PrinterName
        {
            get;
            set;
        }       
        void print(string st);        
    }

    public class Printer : Printable {
        private string name;
        public Printer() {
            heavyJob("Creating an instance of Printer");
        }
        public Printer(string name) { 
            this.name = name;
            heavyJob("Creating a Printer instance (" + name + ")");
        }
        public string PrinterName
        {  
            set
            {
                this.name = value;
            }
            get{
                return name;
            }
        }
        public void print(string st) {       
            System.Console.WriteLine("=== " + name + " ===");
            System.Console.WriteLine(st);
        }
        private void heavyJob(string msg) {     
            System.Console.Write(msg);
            for (int i = 0; i < 5; i++) {
                Thread.Sleep(1000);
                System.Console.Write(".");
            }
            System.Console.WriteLine("Done");
        }
    }

    public class PrinterProxy : Printable {
        private string name;   
        private Printer real; 
        public PrinterProxy() {
        }
        public PrinterProxy(string name) {   
            this.name = name;
        }
        public string PrinterName
        { 
            set
            {
                if (real != null) {
                    real.PrinterName= value;  // If a printer instance exists,
                } 				// set the name in the printer, too
                this.name = value;
            }
            get{
                return name;
            }
        }
        public void print(string st) {
            realize();
            real.print(st);
        }
        private void realize() { 
            if (real == null) {
                real = new Printer(name);
            }
        }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            Printable p = new Printer("Alice");
            //Printable p = new PrinterProxy("Alice");
            System.Console.WriteLine("The current name is " + p.PrinterName);
            p.PrinterName = "Bob";
            System.Console.WriteLine("The current name is " + p.PrinterName);
            p.print("Hello, world.");
        }
    }
}
