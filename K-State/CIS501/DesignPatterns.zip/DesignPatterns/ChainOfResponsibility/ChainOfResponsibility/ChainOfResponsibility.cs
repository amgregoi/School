//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Chain of Responsibility Pattern                                    //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno, (c) 2007                           //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;

namespace ChainOfResponsibility
{
    public class Trouble
    {
        private int number;    
        public Trouble(int number) {
            this.number = number;
        }
        public int getNumber() {   
            return number;
        }
        public override string ToString() {
            return "[Trouble " + number + "]";
        }
    }


    public abstract class Support {
        private string name; 
        private Support next;
        public Support(string name) {
            this.name = name;
        }
        public Support setNext(Support next) {
            this.next = next;
            return next;
        }
        public void support(Trouble trouble) {
            if (resolve(trouble)) {
                done(trouble);
            } else if (next != null) {
                next.support(trouble);
            } else {
                fail(trouble);
            }
        }
        public override string ToString() {         
            return "[" + name + "]";
        }
        protected abstract Boolean resolve(Trouble trouble); 
        protected void done(Trouble trouble) { 
            System.Console.WriteLine(trouble + " is resolved by " + this + ".");
        }
        protected void fail(Trouble trouble) {
            System.Console.WriteLine(trouble + " cannot be resolved.");
        }
    }

    public class NoSupport : Support {
        public NoSupport(String name):base(name) {}
        protected override Boolean resolve(Trouble trouble) {  
            return false; 
        }
    }


    public class LimitSupport : Support {
        private int limit;  
        public LimitSupport(String name, int limit) :base(name){ 
            this.limit = limit;
        }
        protected override Boolean resolve(Trouble trouble) {  
            if (trouble.getNumber() < limit) {
                return true;
            } else {
                return false;
            }
        }
    }


    public class OddSupport : Support {
        public OddSupport(String name) :base(name){ }
        protected override Boolean resolve(Trouble trouble) { 
            if (trouble.getNumber() % 2 == 1) {
                return true;
            } else {
                return false;
            }
        }
    }


    public class SpecialSupport : Support {
        private int number; 
        public SpecialSupport(String name, int number):base(name) {  
            this.number = number;
        }
        protected override Boolean resolve(Trouble trouble) {  
            if (trouble.getNumber() == number) {
                return true;
            } else {
                return false;
            }
        }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            Support alice   = new NoSupport("Alice");
            Support bob     = new LimitSupport("Bob", 100);
            Support charlie = new SpecialSupport("Charlie", 429);
            Support diana   = new LimitSupport("Diana", 200);
            Support elmo    = new OddSupport("Elmo");
            Support fred    = new LimitSupport("Fred", 300);
	        // make a chain
            alice.setNext(bob).setNext(charlie).setNext(diana).
		         setNext(elmo).setNext(fred);
            for (int i = 0; i < 500; i += 33) {
                alice.support(new Trouble(i));
            }
        }
    }
}
