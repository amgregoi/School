/////////////////////////////////////////////////////////////////////////////
//     2 Dimensional Array implementation of the Railroad Signal
//               M. Mizuno (c) 2004
//               Written for Learning Tree Course 223P, 2005
//
//      cl  railSignal1.c
/////////////////////////////////////////////////////////////////////////////
#include <stdio.h>

#define S1ON 0
#define S2ON 1
#define S1OFF 2
#define S2OFF 3

#define State00 0
#define State10 1
#define State11 2
#define State01 3
#define FatalError 4

typedef struct {
  int ns;
  void (*fp)();
} Entry;

void turnRed() {printf("### Signal is Red ###\n");}
void turnGreen() {printf("### Signal is Green ###\n");}
void siren() {printf("### Siren is on ###\n");}
void nop() {}

Entry STtable[5][4] = {
  {{State10, turnRed}, {State00, nop}, {State00, nop}, {State00, nop}},
  {{State10, nop}, {State11, nop}, {State10, nop}, {State10, nop}},
  {{State11, nop}, {State11, nop}, {State01, nop}, {State11, nop}},
  {{FatalError, siren}, {State01, nop}, {State01, nop}, {State00, turnGreen}},
  {{FatalError, nop}, {FatalError, nop}, {FatalError, nop}, {FatalError, nop}}
};


void printCurrentState(int cs) {
  static char *convArray[] = {"State00", "State10", "State11", "State01", "Fatal Error"};
  char *s = convArray[cs];
  printf("Current State : %s\n", s);
}

int main(){
  int cs; // cs: current state
  int si; // sensor input (int form)
  Entry entry;

  // initialize
  cs = State00;
  turnGreen();
  printCurrentState(cs);

  while (1) {
    printf("\n 0: S1ON\n 1: S2ON\n 2: S1OFF\n 3: S2OFF\n 4: DONE\nInput: ");
    scanf_s("%d", &si);
    if (si == 4) break;

	entry = STtable[cs][si];
	(*entry.fp)();
	cs = entry.ns;

    printCurrentState(cs);
  }
}
