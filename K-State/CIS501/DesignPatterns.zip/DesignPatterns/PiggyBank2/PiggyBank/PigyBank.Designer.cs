﻿namespace PiggyBank
{
    partial class PigyBank
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_10Yen = new System.Windows.Forms.Button();
            this.bt_50Yen = new System.Windows.Forms.Button();
            this.bt_100Yen = new System.Windows.Forms.Button();
            this.tb_Display = new System.Windows.Forms.TextBox();
            this.bt_Clear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt_10Yen
            // 
            this.bt_10Yen.Location = new System.Drawing.Point(102, 103);
            this.bt_10Yen.Name = "bt_10Yen";
            this.bt_10Yen.Size = new System.Drawing.Size(75, 23);
            this.bt_10Yen.TabIndex = 0;
            this.bt_10Yen.Text = "10Yen";
            this.bt_10Yen.UseVisualStyleBackColor = true;
            this.bt_10Yen.Click += new System.EventHandler(this.bt_10Yen_Click);
            // 
            // bt_50Yen
            // 
            this.bt_50Yen.Location = new System.Drawing.Point(102, 132);
            this.bt_50Yen.Name = "bt_50Yen";
            this.bt_50Yen.Size = new System.Drawing.Size(75, 23);
            this.bt_50Yen.TabIndex = 1;
            this.bt_50Yen.Text = "50Yen";
            this.bt_50Yen.UseVisualStyleBackColor = true;
            this.bt_50Yen.Click += new System.EventHandler(this.bt_50Yen_Click);
            // 
            // bt_100Yen
            // 
            this.bt_100Yen.Location = new System.Drawing.Point(102, 161);
            this.bt_100Yen.Name = "bt_100Yen";
            this.bt_100Yen.Size = new System.Drawing.Size(75, 23);
            this.bt_100Yen.TabIndex = 2;
            this.bt_100Yen.Text = "100Yen";
            this.bt_100Yen.UseVisualStyleBackColor = true;
            this.bt_100Yen.Click += new System.EventHandler(this.bt_100Yen_Click);
            // 
            // tb_Display
            // 
            this.tb_Display.Location = new System.Drawing.Point(91, 40);
            this.tb_Display.Name = "tb_Display";
            this.tb_Display.Size = new System.Drawing.Size(100, 20);
            this.tb_Display.TabIndex = 3;
            this.tb_Display.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // bt_Clear
            // 
            this.bt_Clear.Location = new System.Drawing.Point(102, 209);
            this.bt_Clear.Name = "bt_Clear";
            this.bt_Clear.Size = new System.Drawing.Size(75, 23);
            this.bt_Clear.TabIndex = 4;
            this.bt_Clear.Text = "Clear";
            this.bt_Clear.UseVisualStyleBackColor = true;
            this.bt_Clear.Click += new System.EventHandler(this.bt_Clear_Click);
            // 
            // PigyBank
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.bt_Clear);
            this.Controls.Add(this.tb_Display);
            this.Controls.Add(this.bt_100Yen);
            this.Controls.Add(this.bt_50Yen);
            this.Controls.Add(this.bt_10Yen);
            this.Name = "PigyBank";
            this.Text = "PigyBank";
            this.Load += new System.EventHandler(this.PigyBank_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_10Yen;
        private System.Windows.Forms.Button bt_50Yen;
        private System.Windows.Forms.Button bt_100Yen;
        private System.Windows.Forms.TextBox tb_Display;
        private System.Windows.Forms.Button bt_Clear;
    }
}

