﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PiggyBank
{
    interface DisplayInterface
    {
        void DisplayAmount(decimal amount);
    }

    class Display: DisplayInterface
    {
        TextBox textBox;
        public Display(TextBox textBox)
        {
            this.textBox = textBox;
        }

        public void DisplayAmount(decimal amount)
        {
            textBox.Text = "\\" + amount;
        }
    }
}
