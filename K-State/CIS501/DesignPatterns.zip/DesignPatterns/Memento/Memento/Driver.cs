//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Memento Pattern (Driver.cs)                                        //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno, (c) 2007                           //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Memento
{
    class Driver
    {
        static void Main(string[] args)
        {
            Gamer gamer = new Gamer(100);
            Memento memento = gamer.createMemento();
            //Memento memento = new Memento(100000);
            for (int i = 0; i < 100; i++)
            {
                System.Console.WriteLine("==== " + i);
                System.Console.WriteLine("Current State:" + gamer);

                gamer.bet();

                System.Console.WriteLine("I have $" + gamer.getMoney());

                if (gamer.getMoney() > memento.getMoney())
                {
                    System.Console.WriteLine(
              "    I have a lot of money. I will save the current state");
                    memento = gamer.createMemento();
                    //memento = new Memento(100000);
                }
                else if (gamer.getMoney() < memento.getMoney() / 2)
                {
                    System.Console.WriteLine(
              "    I lost too much.  I will restore the previous state");
                    gamer.restoreMemento(memento);
                }
                Thread.Sleep(1000);
                System.Console.WriteLine("");
            }
        }
    }
}
