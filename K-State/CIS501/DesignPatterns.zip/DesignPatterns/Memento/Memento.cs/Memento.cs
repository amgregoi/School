//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Memento Pattern  (Memento.cs)                                      //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno, (c) 2007                           //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;

namespace Memento
{
    public class FruitList : List<string>, ICloneable
    // this class is necessary since MemberwiseClone is a protected method
    {
        public Object Clone()
        {
            return this.MemberwiseClone();
        }

        public override string ToString()
        {
            StringBuilder names = new StringBuilder();
            foreach (string st in this)
            {
                names.Append(" '" + st + "',");
            }
            return names.ToString();
        }
    }


    public class Memento
    {
        private int money;
        private FruitList fruits;

        internal Memento(int money)
        {
            this.money = money;
            this.fruits = new FruitList();
        }
        public int getMoney()
        {
            return money;
        }
        internal void addFruit(String fruit)
        {
            fruits.Add(fruit);
        }
        public FruitList getFruits()
        {
            return (FruitList)fruits.Clone();
        }
    }

    public class Gamer
    {
        private int money;
        private FruitList fruits = new FruitList();
        private Random random = new Random();
        private static String[] fruitsname = {
            "Apple", "Grape", "Banana", "Orange",
        };
        public Gamer(int money)
        {
            this.money = money;
        }
        public int getMoney()
        {
            return money;
        }
        public void bet()
        {
            int dice = random.Next(6) + 1;
            if (dice == 1)
            {
                money += 100;
                System.Console.WriteLine("You got more money");
            }
            else if (dice == 2)
            {
                money /= 2;
                System.Console.WriteLine("You  lost a half of your money");
            }
            else if (dice == 6)
            {
                String f = getFruit();
                System.Console.WriteLine("You got a " + f);
                fruits.Add(f);
            }
            else
            {
                System.Console.WriteLine("Nothing happened");
            }
        }
        public Memento createMemento()
        {
            Memento m = new Memento(money);
            foreach (string f in fruits)
            {
                if (f.StartsWith("Delicious"))
                {
                    m.addFruit(f);
                }
            }
            return m;
        }
        public void restoreMemento(Memento memento)
        {
            this.money = memento.getMoney();
            this.fruits = memento.getFruits();          // (fixed 2001-11-02)
        }
        public override string ToString()
        {
            return "[money = " + money + ", fruits = " + fruits + "]";
        }
        private string getFruit()
        {
            string prefix = "";
            if (random.Next(2) == 1)
            {
                prefix = "Delicious ";
            }
            return prefix + fruitsname[random.Next(fruitsname.Length)];
        }
    }
}
