//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Prototype Pattern                                                  //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno, (c) 2007                           //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;

namespace ProtoType
{
    public interface Product {
        void use(String s);
        Product createClone();
    }

    public class Manager
    {
        private Dictionary<string, Product> showcase = 
            new Dictionary<string, Product>();
        public void register(string name, Product proto)
        {
            showcase.Add(name, proto);
        }
        public Product create(string protoname)
        {
            Product p = showcase[protoname];
            return p.createClone();
        }
    }

    public class MessageBox : Product {
        private char decochar;
        public MessageBox(char decochar) {
            this.decochar = decochar;
        }
        public void use(string s) {
            int length = s.Length;
            for (int i = 0; i < length + 4; i++) {
                System.Console.Write(decochar);
            }
            System.Console.WriteLine("");
            System.Console.WriteLine(decochar + " "  + s + " " + decochar);
            for (int i = 0; i < length + 4; i++) {
                System.Console.Write(decochar);
            }
            System.Console.WriteLine("");
        }
        public Product createClone() {
            Product p = null;
            p = (Product)MemberwiseClone();
            return p;
        }
    }

    public class UnderlinePen : Product {
        private char ulchar;
        public UnderlinePen(char ulchar) {
            this.ulchar = ulchar;
        }
        public void use(string s) {
            int length = s.Length;
            System.Console.WriteLine("\""  + s + "\"");
            System.Console.Write(" ");
            for (int i = 0; i < length; i++) {
                System.Console.Write(ulchar);
            }
            System.Console.WriteLine("");
        }
        public Product createClone() {
            Product p = null;
            p = (Product)MemberwiseClone();
            return p;
        }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            // Prepare
            Manager manager = new Manager();
            UnderlinePen upen = new UnderlinePen('~');
            MessageBox mbox = new MessageBox('*');
            MessageBox sbox = new MessageBox('/');
            manager.register("strong message", upen);
            manager.register("warning box", mbox);
            manager.register("slash box", sbox);

            // Create
            Product p1 = manager.create("strong message");
            p1.use("Hello, world.");
            Product p2 = manager.create("warning box");
            p2.use("Hello, world.");
            Product p3 = manager.create("slash box");
            p3.use("Hello, world.");
        }
    }
}
