﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace StrategyExercise
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<Strategy> strategies = new List<Strategy>();
        Strategy currentStrategy;
        private void Form1_Load(object sender, EventArgs e)
        {
            cbAlgSelector.Items.Add("Jayhawks Algorithm");
            cbAlgSelector.Items.Add("Widlcats Algorithm");
            strategies.Add(new Jayhawks());
            strategies.Add(new Wildcats());

            cbAlgSelector.SelectedIndex = 0;
            currentStrategy = strategies[0];
        }
                
        private void bnCaluclate_Click(object sender, EventArgs e)
        {
            int left, right, ans;
            left = right = 0;
            try
            {
                left = int.Parse(tbLeft.Text.Trim());
                right = int.Parse(tbRight.Text.Trim());
            }
            catch(Exception)
            {
                tbLeft.Text = "";
                tbRight.Text = "";
            }
            if((tbLeft.Text != "") && (tbRight.Text != ""))
            {
                lbAnswer.Text=""+ currentStrategy.add(left, right);
            }
        }

        private void cbAlgSelector_SelectedIndexChanged(object sender, EventArgs e)
        {
            tbLeft.Text = tbRight.Text = lbAnswer.Text = "";
            currentStrategy = strategies[cbAlgSelector.SelectedIndex];
        }
    }

    interface Strategy
    {
        int add(int left, int right);
    }

    class Jayhawks : Strategy
    {
        public int add(int left, int right)
        {
            int ans = left;
            for (int i = 0; i < right; i++)
            {
                ans++;
            }
            return ans;
        }
    }

    class Wildcats : Strategy
    {
        public int add(int left, int right)
        {
            return left + right;
        }
    }

}
