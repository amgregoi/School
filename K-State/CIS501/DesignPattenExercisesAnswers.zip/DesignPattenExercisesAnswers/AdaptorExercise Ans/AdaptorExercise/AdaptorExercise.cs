﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AdaptorExercise
{
    class NewInterface
    {
        public double mul(double x, double y)
        {
            return x * y;
        }

        public double div(double x, double y)
        {
            return x/y;
        }

        public double add(double x, double y)
        {
            return x + y;
        }

        public double sub(double x, double y)
        {
            return x - y;
        }
    }

    interface OldInterface
    {
        double ConvFarToCel(double far);
    }

    class adaptor : NewInterface, OldInterface
    {
        public double ConvFarToCel(double far)
        {
            return div(add(far, -32), 1.8);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            OldInterface oi;
            oi = new adaptor();
            Console.WriteLine(oi.ConvFarToCel(60.0));


        }
    }
}
