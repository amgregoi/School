using System;
using System.Collections.Generic;
using System.Text;

namespace Observer
{
    public interface Observer
    {
        void update();
    }

    public abstract class Observable
    {
        protected List<Observer> observers = new List<Observer>();
        public void addObserver(Observer observer)
        {
            observers.Add(observer);
        }
        public void deleteObserver(Observer observer)
        {
            observers.Remove(observer);
        }
        public void notifyObservers()
        {
            foreach (Observer o in observers)
            {
                o.update();
            }
        }
    }
    // IT IS OK IF A STUDENT COMBINES OBSERVABLE AND NUMBERHOLDER INTO ONE CLASS
 
    class NumberHolder: Observable
    {
        int num;
        public void putNumber(int i)
        {
            this.num = i;     
        }
        public int getNumber()
        {
            return num;
        }
    }

    class Graph: Observer
    {
        NumberHolder nh;
        public Graph(NumberHolder nh)
        {
            this.nh = nh;
        }
        public void update()
        {
            Console.Write("Graph Display: ");
            for(int i = 0; i < nh.getNumber(); i++) 
                Console.Write("*");
            Console.WriteLine();
        }
    }

    class Digit: Observer
    {
        NumberHolder nh;
        public Digit(NumberHolder nh)
        {
            this.nh = nh;
        }
        public void update()
        {
            Console.WriteLine("Digit Display : " + nh.getNumber());
        }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            NumberHolder nh = new NumberHolder();
            Graph g1 = new Graph(nh);
            nh.addObserver(g1);
            Digit d1 = new Digit(nh);
            nh.addObserver(d1);
            Graph g2 = new Graph(nh);
            nh.addObserver(g2);
            Graph g3 = new Graph(nh);
            nh.addObserver(g3);

            string s;
            int i;

            while (true)
            {
                Console.Write("\nInput Next Number: ");
                s = Console.ReadLine().Trim();
                if ((i = int.Parse(s)) <= 0) return;

                nh.putNumber(i);
                nh.notifyObservers();
                //g1.graphDisplay(nh);
                //d1.digitDisplay(nh);
                //g2.graphDisplay(nh);
                //g3.graphDisplay(nh);
            }
        }
    }
}
