using System;
using System.Collections.Generic;
using System.Text;

namespace TemplateMethodExercise
{
    class B: TemplateMethodClass 
    {
 
        protected override void f()
        {
            g2 = g2 - g1 + 2;
        }
    }
}
