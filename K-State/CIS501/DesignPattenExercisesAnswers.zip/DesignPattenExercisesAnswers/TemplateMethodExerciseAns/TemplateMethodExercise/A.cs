using System;
using System.Collections.Generic;
using System.Text;

namespace TemplateMethodExercise
{
    class A : TemplateMethodClass
    {
        protected override void f()
        {
            g1++;
        }
    }
}
