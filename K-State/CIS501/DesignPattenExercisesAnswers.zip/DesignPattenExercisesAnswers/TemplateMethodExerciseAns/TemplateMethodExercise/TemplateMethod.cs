using System;
using System.Collections.Generic;
using System.Text;

namespace TemplateMethodExercise
{
    abstract class TemplateMethodClass {
        public int g1 = 4;
        public int g2 = 0;

        abstract protected void f();

        public void trace(int p1, int p2) {
            if ((p1/3)*3 == p1) 
            {
	            g1++;
	            g2 += (p1 + p2);
                this.trace(p1-1, p2-1);  //L1:
                f();
	            g2 = g2 - p1 - p2;
            }else {
                if (((p1/3)*3+2) == p1) {
	                 g1 = g2 + 1;
	                 g1++;
	                 g2 = g2 + p1 + p2;
	                 this.trace(p1-1, p2+1); //L2:
                     g2 -= (g1 + 2);
                } else {
	                 g2 = g1 + 1;
	                 Console.WriteLine(p1 + "   " + p2 + "   " + g1 + 
                         "   " + g2);
	           }
           }
       }
    }


}
