//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Mediator Pattern                                                   //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno for CIS501, (c) 2007                //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Mediator
{
    public partial class LoginForm : Form, LoginMediator
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            createColleagues();
            rbGuest.Checked = true;
            colleagueChanged(rbGuest);
        }
        public void createColleagues()
        {
            rbGuest.setMediator(this);
            rbLogin.setMediator(this);
            tbUsername.setMediator(this);
            tbPassword.setMediator(this);
            btnOk.setMediator(this);
            btnCancel.setMediator(this);
            tbEmail.setMediator(this);
        }

        public void colleagueChanged(LoginColleague colleague)
        {
            if (rbGuest.Checked)
            { // Guest mode
                tbUsername.setColleagueEnabled(false);
                tbPassword.setColleagueEnabled(false);
                tbEmail.setColleagueEnabled(false);
                btnOk.setColleagueEnabled(true);
            }
            else
            { // Login mode
                tbUsername.setColleagueEnabled(true);
                userpassChanged();
            }
        }

        private void userpassChanged()
        {
            if (tbUsername.Text.Length > 0) 
            {
                tbPassword.setColleagueEnabled(true);
                if (tbPassword.Text.Length > 0)
                {
                    tbEmail.setColleagueEnabled(true);
                    if (tbEmail.Text.Length > 0)
                    {
                        btnOk.setColleagueEnabled(true);
                    }
                    else
                    {
                        btnOk.setColleagueEnabled(false);
                    }
                }
                else
                {
                    tbEmail.setColleagueEnabled(false);
                    btnOk.setColleagueEnabled(false);
                }
            }
            else
            {
                tbPassword.setColleagueEnabled(false);
                tbEmail.setColleagueEnabled(false);
                btnOk.setColleagueEnabled(false);
            }
        }
    }
}