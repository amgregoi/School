//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Mediator Pattern                                                   //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno for CIS501, (c) 2007                //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Mediator;

namespace MediatorComponent
{
    public partial class ColleagueRadioButton : RadioButton, LoginColleague
    {
        public ColleagueRadioButton()
        {
            InitializeComponent();
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            // TODO: Add custom paint code here

            // Calling the base class OnPaint
            base.OnPaint(pe);
        }
        private LoginMediator loginMediator;
        public void setMediator(LoginMediator loginMediator)
        {
            this.loginMediator = loginMediator;
        }
        public void setColleagueEnabled(Boolean enabled)
        {
            this.Enabled = enabled;
        }
        protected override void OnCheckedChanged(EventArgs e)
        {
            if (loginMediator != null) loginMediator.colleagueChanged(this);
            base.OnCheckedChanged(e);
        }
    }
}
