//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Mediator Pattern                                                   //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno for CIS501, (c) 2007                //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;

namespace Mediator
{
    public interface LoginColleague
    {
        void setMediator(LoginMediator mediator);
        void setColleagueEnabled(Boolean enabled);
    }
}
