//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Mediator Pattern                                                   //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Ported to C# by Masaaki Mizuno for CIS501, (c) 2007                //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Mediator;

namespace MediatorComponent
{
    public partial class ColleagueTextBox : TextBox, LoginColleague
    {
        public ColleagueTextBox()
        {
            InitializeComponent();
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            // TODO: Add custom paint code here

            // Calling the base class OnPaint
            base.OnPaint(pe);
        }
        private LoginMediator loginMediator;
        public void setMediator(LoginMediator loginMediator)
        {
            this.loginMediator = loginMediator;
        }
        public void setColleagueEnabled(Boolean enabled)
        {
            this.Enabled = enabled;
            this.BackColor = (enabled ? Color.White : Color.LightGray);
        }
        protected override void OnTextChanged(EventArgs e)
        {
            if (loginMediator != null) loginMediator.colleagueChanged(this);
            base.OnTextChanged(e);
        }
    }
}
