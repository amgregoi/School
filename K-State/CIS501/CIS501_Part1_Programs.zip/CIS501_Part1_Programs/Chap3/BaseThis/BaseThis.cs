using System;

namespace BaseThisNS
{
    //  1. execute as is
	class A
	{
        //public readonly int i;     // 4. uncomment this and comment the following line (do not undo Steps 1, 2
        public int i;
        //public A() { }          // 3. uncomment this (do not undo Step 2)
        //public A(int i) { this.i = i; }	 // 2. uncomment this

	}

	class B: A
	{
		public int j;
        //public B(int i, int j)  // 5. uncomment this method and comment the following method
        //    : base(i)
        //{
        //    this.j = j;
        //}

        public B(int i, int j)
        {
            this.i = i;
            this.j = j;
        }

        public B():this(1, 2)
        {
        }
	}

	/// <summary>
	///
	/// </summary>
	class BaseThis
	{
		[STAThread]
		static void Main(string[] args)
		{
            B bp = new B(1, 2);  
            //B bp = new B();
			Console.WriteLine(bp.i + "  "  + bp.j);
		}
	}
}
