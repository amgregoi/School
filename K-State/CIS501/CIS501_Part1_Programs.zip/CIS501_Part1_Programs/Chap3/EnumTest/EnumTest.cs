using System;

namespace EnumTest
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public enum TimeOfDay
	{
        Morning = 1,  // Can set an int value to each enum value 
                      // default is that the first one gets 0
                      // comment the above and uncomment the next line
        //Morning,
        Afternoon,    // if you do not specify a value, Afternoon gets 2, 
        Evening		  // and Evening gets 3
	}
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
        static readonly string[] convertToString = { "MORNING", "AFTERNOON", "EVENING" };
		[STAThread]
		static void Main(string[] args)
		{
            TimeOfDay timeOfDay =  TimeOfDay.Evening;
            Console.WriteLine(timeOfDay.ToString());  // ToString() can be omitted
                // with ToString(), you can convert enum value to string
            Console.WriteLine((int)timeOfDay);   // you can convert enum value to int
            Console.WriteLine(convertToString[(int)timeOfDay - 1]);  
                // with an array, you can easily convert int (enum) to string
                // "-1" because enum starts with 1 and array index start with 0
		}
	}
}
