﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StringBuilderNS
{
    class StringBuilderDriver
    {
        static void Main(string[] args)
        {
            string[] strings = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
            StringBuilder sb = new StringBuilder();

            foreach(string s in strings)
                sb.Append(s);
            Console.WriteLine(sb.ToString());
        }
    }
}
