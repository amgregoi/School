﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;  // include this name space

namespace DebugRelease
{
    class DebugReleaseTest
    {
        bool IfDirective = false;
        bool ConditionalAttribute = false;

        [Conditional("DEBUG")]
        void DebugConditionalMethod()
        {
            ConditionalAttribute = true;
        }

        public void Go()
        {
#if DEBUG
            IfDirective = true;
#endif
            DebugConditionalMethod();

            Console.WriteLine("IfDirective = " + IfDirective);
            Console.WriteLine("ConditionalAttribute = " + ConditionalAttribute);
        }
    }
    
    class DebugReleaseDriver
    {
        static void Main(string[] args)
        {
            DebugReleaseTest debugReleaseTest = new DebugReleaseTest();
            debugReleaseTest.Go();
        }
    }
}
