using System;

namespace consOrder
{
  class ClassA
  {
    public ClassA() 
    {
      Console.WriteLine("ClassA");
    }
  }
  class ClassB
  {
    public ClassB() 
    {
      Console.WriteLine("ClassB");
    }
  }
  class ClassC
  {
    public ClassC() 
    {
      Console.WriteLine("ClassC");
    }
  }
  class Class0
  {
    ClassA a = new ClassA();
    public Class0()
    {
      Console.WriteLine("Class0");
    }
  }
  class Class1:Class0
  {
    ClassB b = new ClassB();
    public Class1()
    {
      Console.WriteLine("Class1");
    }


  }
  class Class2:Class1
  {
    ClassC c = new ClassC();
    public Class2()
    {
      Console.WriteLine("Class2");
    }
    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main(string[] args)
    {
      //
      // TODO: Add code to start application here
      //
      Class2 p1= new Class2();
    }
  }
}
