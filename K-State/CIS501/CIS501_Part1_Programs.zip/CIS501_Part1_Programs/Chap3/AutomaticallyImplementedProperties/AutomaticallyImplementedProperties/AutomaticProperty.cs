﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutomaticallyImplementedProperties
{
    class Class1
    {
        public int I { get; private set; }
        public int J { get; set; }

        public Class1(int x, int y)
        {
            I = x;
            J = y;
        }
    }

    class AutomaticProperty
    {
        static void Main(string[] args)
        {
            Class1 c1 = new Class1(3, 10);
            Console.WriteLine(c1.I + "  " + c1.J);
            c1.J = 11;
            // You cannot do “c1.I = 8;”
            Console.WriteLine(c1.I + "  " + c1.J);
        }
    }
}
