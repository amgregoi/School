﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ListFind
{
    class ListEntry
    {
        string name;
        public ListEntry(string name) { this.name = name; }
        public string Name
        {
            get { return name; }
        }
        public override string ToString()
        {
            return name;
        }
    }
         
    class ListFind
    {
        static bool findJapan(ListEntry le)
        {
            return le.Name == "Japan";
        }

        static void Main(string[] args)
        {
            List<ListEntry> myList = new List<ListEntry>();
            myList.Add(new ListEntry("USA"));
            myList.Add(new ListEntry("Japan"));
            myList.Add(new ListEntry("Mexico"));

            Console.WriteLine("+++++++++ Original List ++++++++");
            foreach(ListEntry le in myList)
                Console.WriteLine(le);

            Console.WriteLine("\n++++++++ Find and Remove 'Japan' +++++++");
            //ListEntry myEntry = myList.Find(new Predicate<ListEntry>(findJapan));
            ////ListEntry myEntry = myList.Find(le => (le.Name == "Japan"));
            //Console.WriteLine(myEntry + " is found");
            //myList.Remove(myEntry);

            int index = myList.FindIndex(le => (le.Name == "Japan"));
            Console.WriteLine("Japan is at index " + index);
            myList.RemoveAt(index);

            Console.WriteLine("\n++++++++ The List after Removing 'Japan' ++++++");
            foreach (ListEntry le in myList)
                Console.WriteLine(le);

        }
    }
}
