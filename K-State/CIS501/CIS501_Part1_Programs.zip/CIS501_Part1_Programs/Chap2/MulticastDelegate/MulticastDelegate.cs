using System;

namespace MulticastDelegate
{
    delegate void MulticastDelegate(string t);

	class DelegateTest
	{
		public event MulticastDelegate operations;

		static void Main()
		{
			DelegateTest dt = new DelegateTest();
            MulticastDelegate md = new MulticastDelegate(printline);

			dt.operations += new MulticastDelegate(printline2);
            dt.operations += md;
			dt.operations += new MulticastDelegate(printline2);
			dt.operations("Hello World");

            md("Good Afternoon");

            dt.operations -= md;
            //dt.operations -= new CombiningDelegate(printline);
            //dt.operations -= printline;
            dt.operations("Good Bye");
		}

        static void printline(string t)
        {
            Console.WriteLine(t);
        }

		static void printline2(string t)
		{
         
			Console.WriteLine( t + "    " + t);
		}
	}
   }
