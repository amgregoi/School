using System;

namespace Delegate
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	delegate int IIMethod(int i);
	class Class0
	{
		int x;
		public Class0()
		{
			x = 10;
		}
		public int f1(int i)
		{
			return i + x;
		}
		public static int f2(int i)
		{
			return i*i;
		}
	}
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			//
			// TODO: Add code to start application here
			//
			Class0 c0 = new Class0();
			IIMethod ii1 = new IIMethod(c0.f1);
			IIMethod ii2 = new IIMethod(Class0.f2);
			Console.WriteLine("ii1(4) = " + ii1(4));
			Console.WriteLine("ii2(4) = " + ii2(4));
		}
	}
}
