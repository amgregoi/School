﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutomaticProperty
{
    class Class1
    {
        //public int i;
        //public int j;

        public int I { get; private set; }
        public int J { get; set; }

        public Class1(int x, int y)
        {
            I = x;
            J = y;
        }

        public override string ToString()
        {

            return "i = " + I + ", j = " + J;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Class1 c1 = new Class1(3, 10);

            Console.WriteLine(c1);
        }
    }
}
