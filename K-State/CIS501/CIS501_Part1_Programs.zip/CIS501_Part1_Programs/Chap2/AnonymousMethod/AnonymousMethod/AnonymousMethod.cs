﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnonymousMethod
{
    class A
    {
        // Rewrite the following program using AnonymousMethod
        // Then, rewrite it using a lambda expression
        public static string AddHello(string s)
        {
            return "Hello " + s;
        }

        delegate string MyDel(string s);
        static void Main()
        {
            MyDel del1 = AddHello;

            string x = del1("USA");
            Console.WriteLine(x);
        }
    }
}
