﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class Point
    {
        public int X;
        public int Y;
        public Point()
        {
            X = 1;
            Y = 2;
        }
        public Point(int x, int y) 
        {
            X = x;
            Y = y;
        }
    }


    class Program
    {
        static void Main()
        {
             Point p1 = new Point();
             Point p2 = new Point {X = 5, Y = 7};
             Point p3 = new Point(2, 3){X = 20, Y = 30};
             Console.WriteLine("{0}, {1}", p1.X, p1.Y);
             Console.WriteLine("{0}, {1}", p2.X, p2.Y);
             Console.WriteLine("{0}, {1}", p3.X, p3.Y);
        }
    }
}
