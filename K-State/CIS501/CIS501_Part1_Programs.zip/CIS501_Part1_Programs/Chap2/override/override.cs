using System;

namespace overridetest
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class0
	{
		public virtual void f()
		{
			Console.WriteLine("Class0's f()");
		}
	}
	
	class Class1:Class0 
	{
		public override /*new*/ void f() 
		{
			Console.WriteLine("Class1's f()");
		}
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			//
			// TODO: Add code to start application here
			//
			Class0 ptr0 = new Class1();
			ptr0.f();
		}
	}
	
}
