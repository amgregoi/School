using System;

namespace Delegate
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	delegate string SSMethod(string s);
	class Class0
	{
	    string x;
		public Class0()
		{
			x = "I love ";
		}
		public string f1(string s)
		{
			return x + s;
		}
		public static string f2(string s)
		{
			return "I like " + s;
		}
	}
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			//
			// TODO: Add code to start application here
			//

            // Draw memory image of execution of the following program
			Class0 c0 = new Class0();
			
            //Question1: by explicitely creating SSMehtod objects (ss1, ss2), print
            //   "I love USA"  (by stroing c0.f1) and "I like Japan" (by storing f2)
            SSMethod ss1, ss2;
            // Add your code

            Console.WriteLine(ss1("USA"));
            Console.WriteLine(ss2("Japan"));
            
            //Question2:  Using an anonymous method, print "I go to K-State" (where "K-State" can
            // be replaced by anything at invocation
            SSMethod ss3;
            // Add your code

            Console.WriteLine(ss3("K-State"));
            
            //Question3: transform the anonymous method to a lambda expression to print
            // "I go to KU"
            // Add your code


            Console.WriteLine(ss3("KU"));

            //Question4 (difficult): Using lambda expression with a captured variable in Class0,
            // print "I love kansas"
            // You need to add a method in Class0
            // Add your code

            Console.WriteLine(ss3("Kansas"));
		}
	}
}
