﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnonymousType
{
    class Other
    {
        static public string Name = "Steven Jobs";
    }

    class Program
    {
        static void Main()
         {
             string Major = "Computer Science";
             var student = new {Age = 19, Other.Name, Major};
                  // Name and Major become the 2nd an 3rd property names
                  //  The above statement is the same as
                  //  var student = new {Age = 19, Name = Other.Name, Major = Major};
             Console.WriteLine("{0},  Age  {1},   Major : {2}", 
                    student.Name, student.Age, student.Major);

             //student = 3;
          }
    }
}
