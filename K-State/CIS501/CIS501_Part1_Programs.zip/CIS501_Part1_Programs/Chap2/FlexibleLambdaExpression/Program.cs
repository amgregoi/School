﻿/////////////////////////////////////////////////////////////////
//  Written by Masaaki Mizuno (c) 2011                         //
//     for Learning Tree Course 423C                           //
/////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace FlexibleLambdaExpression
{
    class Program
    {
        static void Main(string[] args)
        {
            // Action is a .NET defined delegate
            //public delegate void Action()
            Action action;
            //ThreadStart action;    // This works, too

            action = (() => { print1("Hello!"); });
            action();

            action = (() => { print2("Hello", "USA!"); });
            action();

            action = (() => { print3("Hello, France!", 4); });
            action();
        }

        static void print1(string msg)
        {
            Console.WriteLine(msg);
        }

        static void print2(string msg1, string msg2)
        {
            Console.WriteLine(msg1 + ", " + msg2);
        }

        static void print3(string msg, int times)
        {
            for(int i = 0; i <= times; i++)
                Console.WriteLine(msg);
        }
    }
}
