﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CapturedVariables
{
    delegate void MyDel();
    class Program
    {
        static void Main(string[] args)
        {
            MyDel myDel1, myDel2;
            f(out myDel1, out myDel2);
           

            myDel1();
            myDel2();
            myDel1();
        }

        static void f(out MyDel myDel1, out MyDel myDel2)
        {
            int x = 5;
            myDel1 = delegate
            {
                Console.WriteLine("In myDel1, Value of x: " + x);
                x = 10;
            };

            myDel2 = delegate
            {
                Console.WriteLine("In myDel2, Value of x: " + x);
                x = 20;
            };
        }
    }
}
