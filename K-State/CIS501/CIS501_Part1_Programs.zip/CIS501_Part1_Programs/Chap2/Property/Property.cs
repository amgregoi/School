using System;

namespace PropertyNS
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Property
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		int i = 100;
        int z;

        public int Z
        {
            get { return z; }
            set { z = value; }
        }

        public int A { get; private set; }

		public int X
		{
			get
			{
				for (int j=0; j < 10; j++)  
					Console.WriteLine("Inside property X (get), i = " + i);
				return i;
			}
			
            set
			{
				Console.WriteLine("Inside property X (set): value = " + value);
				i = value * 3;
			}
		}

		[STAThread]
		static void Main(string[] args)
		{
			//
			// TODO: Add code to start application here
			//
			Property c1 = new Property();
			int y = c1.X;		// set break point here
			c1.X = 2;
			y = c1.X * 2;
            c1.A = 4;
            Console.WriteLine(c1.A);
		}
	}
}
