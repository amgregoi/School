using System;
using System.Collections.Generic;

namespace Shapes
{
	interface Shape
	{
		void draw();  // cannot even specify visibility (public,etc)
	}

	class Circle:Shape 
	{
		public Circle() 
		{
			Console.WriteLine("Circle was created");
		}
		public void draw()  // if Shape is an interface, "override" cannot be added
		{
			Console.WriteLine("Circle.draw()");
		}
	}

	class Triangle:Shape 
	{
		public Triangle() 
		{
			Console.WriteLine("Triangle was created");
		}
		public void draw()
		{
			Console.WriteLine("Triangle.draw()");
		}
	}

	class Square:Shape 
	{
		public Square() 
		{
			Console.WriteLine("Square was created");
		}
		public void draw()
		{
			Console.WriteLine("Squate.draw()");
		}
	}

	class RandomeShapeGenerator 
	{
		private static Random rand = new Random();
		public static Shape next() 
		{
			switch(rand.Next(0,3)) 
			{
				case 0: return new Circle();
				case 1: return new Square();
				case 2: return new Triangle();
				default: return null;
			}
		}
	}

	/// Summary description for Class1.
	/// </summary>
	class Shapes
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
            const int MAXOBJECTS = 9;
			//
			// TODO: Add code to start application here
			//
			List<Shape> shapes = new List<Shape>();
			Console.WriteLine("=========Create 9 Shapes=========");
			for (int i = 0; i < MAXOBJECTS; i++) shapes.Add(RandomeShapeGenerator.next());
			Console.WriteLine("=========Draw 9 Shapes==========");
			foreach (Shape s in shapes) s.draw();
		}
	}
}
