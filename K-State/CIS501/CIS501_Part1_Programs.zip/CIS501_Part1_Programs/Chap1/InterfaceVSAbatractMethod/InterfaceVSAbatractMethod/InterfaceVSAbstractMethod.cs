﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InterfaceVSAbatractMethod
{
    interface CInterface
    {
        void f();       // add public, add virtual
        int X { get; set; }
    }

    abstract class CAbstractClass
    {
        public int i = 3;  
        abstract public void g(); // remove public, add virtual
    }

    class ITest : CInterface
    {
        public  void f() { Console.WriteLine("This is f()"); } // add override
        public int X
        {
            get { Console.WriteLine("This is get of X"); return 4; }
            set { Console.WriteLine("This is set of X"); }
        }
    }

    class ACTest : CAbstractClass
    {
        public override void g() // remove override
        {
            Console.WriteLine("This is g()");
        }
    }



    class InterfaceVSAbstractMethod
    {
        static void Main(string[] args)
        {
            ITest iTest = new ITest();
            ACTest aCTest = new ACTest();
            iTest.f();
            iTest.X = 4;
            int m = iTest.X;

            aCTest.g();
            Console.WriteLine("aCtest.i =" + aCTest.i);
        }
    }
}
