using System;

namespace MemoryImage1
{
  /// <summary>
  /// Summary description for Class1.
  /// </summary>
  class RecurTest1
  {
    int ans;
    //int x;
    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    void fact(int i) 
    {
      int x;
      x = i - 1;

      if ((i == 0) ||(x == 0)) ans = 1;
      else 
      {
        this.fact(x);
        ans = (x+1)*ans;
      }
    }

    [STAThread]
    static void Main(string[] args)
    {
      //
      // TODO: Add code to start application here
      //
      RecurTest1 rt = new RecurTest1();
      rt.fact(3);
      Console.WriteLine("Anser = " + rt.ans);
    }
  }
}
