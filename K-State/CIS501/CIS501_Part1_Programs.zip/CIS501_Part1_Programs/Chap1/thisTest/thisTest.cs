using System;

namespace thisTest
{
	class A
	{
		public int i;
		public double d;
        public A()
        {
        }
		public void f(int x) 
		{
			this.i = i + x;
			d = this.d + 2*x;
		}
	}
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class thisTest
	{
		[STAThread]
		static void Main(string[] args)
		{
			A a1 = new A();
			A a2 = new A();
            int b = 10;
			a1.f(3);
			a2.f(5);
			Console.Out.WriteLine("a1.i = " + a1.i + " a1.d = " + a1.d);
			Console.Out.WriteLine("a2.i = " + a2.i + " a2.d = " + a2.d);
		}
	}
}
