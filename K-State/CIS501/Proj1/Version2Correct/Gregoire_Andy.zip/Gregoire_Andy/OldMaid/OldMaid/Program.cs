﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OldMaidLib;

namespace OldMaid
{
    class Program
    {
        static void Main(string[] args)
        {
            // Debug in computerPlayer.cs
            OldMaid om = new OldMaid();
            om.game();
        }
    }
}
