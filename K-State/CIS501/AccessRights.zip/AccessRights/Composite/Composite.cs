//////////////////////////////////////////////////////////////////////////
//                                                                      //
//   Composite Pattern                                                  //
//   By Hiroshi Yuki, (c) 2001                                          //
//   Modified and Ported to C# by Masaaki Mizuno, (c) 2007, 2008        //
//      for Learning Tree Course  252P                                  //
//      also for K-State Course cis501                                  //
//                                                                      //
////////////////////////////////////////////////////////////////////////// 
using System;
using System.Collections.Generic;
using System.Text;

namespace Composite
{
    public abstract class Entry {
        public virtual Entry add(Entry entry) {  
            throw new FileTreatmentException();
        }

        public abstract void ChangeAccessRights(string accessRights);            
    }


    public class File : Entry {
        private string name;
        private string accessRights;
        public File(string name) {
            this.name = name;
            accessRights = "R--";
        }
        public override void ChangeAccessRights(string accessRights) {
            //
            Console.WriteLine(name + ":  " + accessRights);
        }
    }

    public class Directory : Entry {
        private string name;
        private string accessRights;
        private List<Entry> directory = new List<Entry>();   
        public Directory(string name) {        
            this.name = name;
            this.accessRights = "R-X";
        }
        public override Entry add(Entry entry) {     
            directory.Add(entry);
            return this;
        }
        public override void ChangeAccessRights(string accessRights) {
        // also print directory name and its new access right
        }
    }

    public class FileTreatmentException : Exception {
        public FileTreatmentException() {}
        public FileTreatmentException(String msg) : base(msg){}
    }

    class Driver
    {
        static void Main(string[] args)
        {
            try {
                System.Console.WriteLine("Making root entries...");
                Directory rootdir = new Directory("root");
                Directory bindir = new Directory("bin");
                rootdir.add(bindir).add(new File("hanako"));
                bindir.add(new File("vi"));
      
                rootdir.ChangeAccessRights("RWX");
            } catch (FileTreatmentException e) {
                System.Console.Error.WriteLine(e.StackTrace);
            }
        }
    }
}
