﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AddClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        AddService addService = new AddService();

        private void bnAdd_Click(object sender, EventArgs e)
        {
            long x = 0;
            long y = 0;
            try
            {
                x = long.Parse(tbX.Text.Trim());
                y = long.Parse(tbY.Text.Trim());
            }
            catch (Exception)
            {
                tbX.Text = "";
                tbY.Text = "";
                tbAns.Text = "";
                return;
            }
            long ans = addService.Add(x, y);
            tbAns.Text = ans.ToString();
        }
    }
}
