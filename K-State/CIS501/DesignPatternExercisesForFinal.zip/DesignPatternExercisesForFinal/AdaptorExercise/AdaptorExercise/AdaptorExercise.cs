﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AdaptorExercise
{
    class NewInterface
    {
        public double mul(double x, double y)
        {
            return x * y;
        }

        public double div(double x, double y)
        {
            return x/y;
        }

        public double add(double x, double y)
        {
            return x + y;
        }

        public double sub(double x, double y)
        {
            return x - y;
        }
    }

    interface OldInterface
    {
        double ConvFahToCel(double far);
    }

    // Add an adaptor class to convert OldInterface to NewInterface

    class Program
    {
        static void Main(string[] args)
        {
            OldInterface oi;
            //oi = new XXX(); // instantiate the adaptor class
            //Console.WriteLine(oi.ConvFahToCel(60.0));
        }
    }
}
