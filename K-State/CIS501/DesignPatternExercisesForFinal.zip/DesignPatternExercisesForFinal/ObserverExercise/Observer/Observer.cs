using System;
using System.Collections.Generic;
using System.Text;

namespace Observer
{
    class NumberHolder
    {
        int num;
        public void putNumber(int i)
        {
            this.num = i;     
        }
        public int getNumber()
        {
            return num;
        }
    }

    class Graph
    {
        NumberHolder nh;
        public Graph(NumberHolder nh)
        {
            this.nh = nh;
        }
        public void graphDisplay()
        {
            Console.Write("Graph Display: ");
            for(int i = 0; i < nh.getNumber(); i++) Console.Write("*");
            Console.WriteLine();
        }
    }

    class Digit
    {
        NumberHolder nh;
        public Digit(NumberHolder nh) { this.nh = nh; }
        public void digitDisplay()
        {
            Console.WriteLine("Digit Display : " + nh.getNumber());
        }
    }

    class Driver
    {
        static void Main(string[] args)
        {
            NumberHolder nh = new NumberHolder();
            Graph g1 = new Graph(nh);
            Digit d1 = new Digit(nh);
            Graph g2 = new Graph(nh);
            Graph g3 = new Graph(nh);

            string s;
            int i;

            while (true)
            {
                Console.Write("\nInput Next Number: ");
                s = Console.ReadLine().Trim();
                if ((i = int.Parse(s)) <= 0) return;

                nh.putNumber(i);
                g1.graphDisplay();
                d1.digitDisplay();
                g2.graphDisplay();
                g3.graphDisplay();
            }
        }
    }
}
