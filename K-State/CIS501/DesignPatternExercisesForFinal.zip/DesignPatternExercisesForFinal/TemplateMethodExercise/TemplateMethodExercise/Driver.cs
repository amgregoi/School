﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TemplateMethodExercise
{
    class Driver
    {
        static void Main(string[] args)
        {
            A ap = new A();
            //B ap = new B();
            ap.trace(6, 4); // L3:
            Console.WriteLine(ap.g1 + "   " + ap.g2); ;
        }
    }
}
