﻿namespace StrategyExercise
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbAlgSelector = new System.Windows.Forms.ComboBox();
            this.tbLeft = new System.Windows.Forms.TextBox();
            this.tbRight = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbAnswer = new System.Windows.Forms.Label();
            this.bnCaluclate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cbAlgSelector
            // 
            this.cbAlgSelector.FormattingEnabled = true;
            this.cbAlgSelector.Location = new System.Drawing.Point(82, 35);
            this.cbAlgSelector.Name = "cbAlgSelector";
            this.cbAlgSelector.Size = new System.Drawing.Size(121, 21);
            this.cbAlgSelector.TabIndex = 0;
            this.cbAlgSelector.SelectedIndexChanged += new System.EventHandler(this.cbAlgSelector_SelectedIndexChanged);
            // 
            // tbLeft
            // 
            this.tbLeft.Location = new System.Drawing.Point(61, 94);
            this.tbLeft.Name = "tbLeft";
            this.tbLeft.Size = new System.Drawing.Size(54, 20);
            this.tbLeft.TabIndex = 1;
            // 
            // tbRight
            // 
            this.tbRight.Location = new System.Drawing.Point(165, 94);
            this.tbRight.Name = "tbRight";
            this.tbRight.Size = new System.Drawing.Size(53, 20);
            this.tbRight.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(135, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(13, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "+";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(99, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "= ";
            // 
            // lbAnswer
            // 
            this.lbAnswer.AutoSize = true;
            this.lbAnswer.Location = new System.Drawing.Point(135, 148);
            this.lbAnswer.Name = "lbAnswer";
            this.lbAnswer.Size = new System.Drawing.Size(0, 13);
            this.lbAnswer.TabIndex = 5;
            // 
            // bnCaluclate
            // 
            this.bnCaluclate.Location = new System.Drawing.Point(102, 199);
            this.bnCaluclate.Name = "bnCaluclate";
            this.bnCaluclate.Size = new System.Drawing.Size(75, 23);
            this.bnCaluclate.TabIndex = 6;
            this.bnCaluclate.Text = "Calculate\r\n";
            this.bnCaluclate.UseVisualStyleBackColor = true;
            this.bnCaluclate.Click += new System.EventHandler(this.bnCaluclate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.bnCaluclate);
            this.Controls.Add(this.lbAnswer);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbRight);
            this.Controls.Add(this.tbLeft);
            this.Controls.Add(this.cbAlgSelector);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbAlgSelector;
        private System.Windows.Forms.TextBox tbLeft;
        private System.Windows.Forms.TextBox tbRight;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbAnswer;
        private System.Windows.Forms.Button bnCaluclate;
    }
}

