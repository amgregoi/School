﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace StrategyExercise
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            cbAlgSelector.Items.Add("Jayhawks Algorithm");
            cbAlgSelector.Items.Add("Widlcats Algorithm");
            cbAlgSelector.SelectedIndex = 0;
            // This is a joke. I hope nobody is offended by this
        }
                
        private void bnCaluclate_Click(object sender, EventArgs e)
        {
            int left, right, ans;
            left = right = 0;
            try
            {
                left = int.Parse(tbLeft.Text.Trim());
                right = int.Parse(tbRight.Text.Trim());
            }
            catch(Exception)
            {
                tbLeft.Text = "";
                tbRight.Text = "";
            }
            if((tbLeft.Text != "") && (tbRight.Text != ""))
            {
                if (cbAlgSelector.SelectedIndex == 0)
                {
                    ans = left;
                    for (int i = 0; i < right; i++)
                    {
                        ans++;
                    }
                }
                else
                {
                    ans = left + right;
                }
                lbAnswer.Text = ""+ans;
            }
        }

        private void cbAlgSelector_SelectedIndexChanged(object sender, EventArgs e)
        {
            tbLeft.Text = tbRight.Text = lbAnswer.Text = "";
        }
    }
}
